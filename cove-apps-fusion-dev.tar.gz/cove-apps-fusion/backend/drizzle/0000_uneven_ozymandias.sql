CREATE TABLE "audit_events" (
	"event_id" text PRIMARY KEY NOT NULL,
	"event_kind" text NOT NULL,
	"event_time" timestamp with time zone NOT NULL,
	"actor_id" text NOT NULL,
	"outcome" text NOT NULL,
	"event_payload" jsonb NOT NULL,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "deployment_receipts" (
	"id" text PRIMARY KEY NOT NULL,
	"solution_id" text NOT NULL,
	"solution_name" text NOT NULL,
	"status" text NOT NULL,
	"actor_sub" text NOT NULL,
	"classification" text DEFAULT 'none' NOT NULL,
	"replica_count" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL,
	"solution_git_sha" char(40),
	"environment_id" text,
	"pinned_artifacts" jsonb,
	"dependency_check_results" jsonb,
	"pinned_positions_jsonb" jsonb,
	"teardown_tier_at_deploy" text,
	"snapshot_sha256" char(64),
	"snapshot_blob_ref" text,
	"final_logs_ref" text,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "env_variables" (
	"id" text PRIMARY KEY NOT NULL,
	"env_id" text NOT NULL,
	"name" text NOT NULL,
	"value_kind" text NOT NULL,
	"value" text,
	"secret_ref" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "environments" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"target_type" text NOT NULL,
	"variables_schema" jsonb,
	"trusted_for_active_checks" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "solution_edges" (
	"id" text PRIMARY KEY NOT NULL,
	"solution_id" text NOT NULL,
	"from_position_id" uuid NOT NULL,
	"to_position_id" uuid NOT NULL,
	"adapter_id" text NOT NULL,
	"adapter_git_sha" char(40) NOT NULL,
	"adapter_version" text,
	"adapter_config" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "solution_nodes" (
	"solution_id" text NOT NULL,
	"position_id" uuid NOT NULL,
	"node_kind" text NOT NULL,
	"node_git_sha" char(40) NOT NULL,
	"node_version" text,
	"node_config" jsonb,
	"position_x" real,
	"position_y" real,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL,
	CONSTRAINT "solution_nodes_solution_id_position_id_pk" PRIMARY KEY("solution_id","position_id")
);
--> statement-breakpoint
CREATE TABLE "solutions" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"version" text NOT NULL,
	"maturity" text NOT NULL,
	"description" text NOT NULL,
	"tenant_id" text DEFAULT 'gdit' NOT NULL,
	"graph" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "deployment_receipts" ADD CONSTRAINT "deployment_receipts_solution_id_solutions_id_fk" FOREIGN KEY ("solution_id") REFERENCES "public"."solutions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "env_variables" ADD CONSTRAINT "env_variables_env_id_environments_id_fk" FOREIGN KEY ("env_id") REFERENCES "public"."environments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "solution_edges" ADD CONSTRAINT "solution_edges_solution_id_solutions_id_fk" FOREIGN KEY ("solution_id") REFERENCES "public"."solutions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "solution_nodes" ADD CONSTRAINT "solution_nodes_solution_id_solutions_id_fk" FOREIGN KEY ("solution_id") REFERENCES "public"."solutions"("id") ON DELETE no action ON UPDATE no action;