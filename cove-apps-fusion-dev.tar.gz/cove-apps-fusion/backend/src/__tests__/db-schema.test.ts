import { describe, it, expect } from 'vitest'
import { text } from 'drizzle-orm/pg-core'
import {
  withTenant,
  solutions,
  deployments,
  solutionNodes,
  solutionEdges,
  environments,
  envVariables,
  auditEvents,
} from '../db/schema.js'

// ---------------------------------------------------------------------------
// withTenant helper — DECISION-0011
// ---------------------------------------------------------------------------
describe('withTenant helper', () => {
  it('adds tenantId to any columns object', () => {
    const result = withTenant({ foo: text('foo') })
    expect(result).toHaveProperty('tenantId')
    expect(result).toHaveProperty('foo')
  })

  it('preserves all original columns', () => {
    const result = withTenant({ a: text('a'), b: text('b') })
    expect(result).toHaveProperty('a')
    expect(result).toHaveProperty('b')
    expect(result).toHaveProperty('tenantId')
  })
})

// ---------------------------------------------------------------------------
// solutions table — DECISION-0011 (tenantId added)
// ---------------------------------------------------------------------------
describe('solutions table', () => {
  it('is defined', () => {
    expect(solutions).toBeDefined()
  })

  it('has tenantId column (DECISION-0011)', () => {
    expect(solutions.tenantId).toBeDefined()
  })

  it('has id and name columns', () => {
    expect(solutions.id).toBeDefined()
    expect(solutions.name).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// deployments table — DECISION-0018
// ---------------------------------------------------------------------------
describe('deployments table', () => {
  it('is defined', () => {
    expect(deployments).toBeDefined()
  })

  it('has tenantId column (DECISION-0011 applied to deployments)', () => {
    expect(deployments.tenantId).toBeDefined()
  })

  it('has solutionGitSha column (DECISION-0018)', () => {
    expect(deployments.solutionGitSha).toBeDefined()
  })

  it('has environmentId column (DECISION-0018)', () => {
    expect(deployments.environmentId).toBeDefined()
  })

  it('has startedAt and completedAt columns (DECISION-0018)', () => {
    expect(deployments.startedAt).toBeDefined()
    expect(deployments.completedAt).toBeDefined()
  })

  it('has snapshotSha256 column (DECISION-0018)', () => {
    expect(deployments.snapshotSha256).toBeDefined()
  })

  it('has pinnedArtifacts column (DECISION-0018)', () => {
    expect(deployments.pinnedArtifacts).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// solutionNodes table — DECISION-0017
// ---------------------------------------------------------------------------
describe('solutionNodes table', () => {
  it('is defined', () => {
    expect(solutionNodes).toBeDefined()
  })

  it('has tenantId column (security: multi-tenant isolation)', () => {
    expect(solutionNodes.tenantId).toBeDefined()
  })

  it('has nodeGitSha column (security: artifact pinning)', () => {
    expect(solutionNodes.nodeGitSha).toBeDefined()
  })

  it('has positionId column (DECISION-0017: stable across renames)', () => {
    expect(solutionNodes.positionId).toBeDefined()
  })

  it('has nodeKind column', () => {
    expect(solutionNodes.nodeKind).toBeDefined()
  })

  it('has nodeConfig column', () => {
    expect(solutionNodes.nodeConfig).toBeDefined()
  })

  it('has createdAt column', () => {
    expect(solutionNodes.createdAt).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// solutionEdges table — DECISION-0017
// ---------------------------------------------------------------------------
describe('solutionEdges table', () => {
  it('is defined', () => {
    expect(solutionEdges).toBeDefined()
  })

  it('has tenantId column (security: multi-tenant isolation)', () => {
    expect(solutionEdges.tenantId).toBeDefined()
  })

  it('has adapterGitSha column (security: artifact pinning)', () => {
    expect(solutionEdges.adapterGitSha).toBeDefined()
  })

  it('has fromPositionId and toPositionId columns (DECISION-0017)', () => {
    expect(solutionEdges.fromPositionId).toBeDefined()
    expect(solutionEdges.toPositionId).toBeDefined()
  })

  it('has adapterId column', () => {
    expect(solutionEdges.adapterId).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// environments table — DECISION-0019
// ---------------------------------------------------------------------------
describe('environments table', () => {
  it('is defined', () => {
    expect(environments).toBeDefined()
  })

  it('has tenantId column (security: multi-tenant isolation)', () => {
    expect(environments.tenantId).toBeDefined()
  })

  it('has targetType column (DECISION-0019)', () => {
    expect(environments.targetType).toBeDefined()
  })

  it('has trustedForActiveChecks column (DECISION-0019)', () => {
    expect(environments.trustedForActiveChecks).toBeDefined()
  })

  it('has variablesSchema column with schema_version hedge', () => {
    expect(environments.variablesSchema).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// envVariables table — DECISION-0019
// ---------------------------------------------------------------------------
describe('envVariables table', () => {
  it('is defined', () => {
    expect(envVariables).toBeDefined()
  })

  it('has tenantId column (security: multi-tenant isolation)', () => {
    expect(envVariables.tenantId).toBeDefined()
  })

  it('has valueKind column (XOR discriminant)', () => {
    expect(envVariables.valueKind).toBeDefined()
  })

  it('has value and secretRef columns (XOR pair — enforced at Zod layer)', () => {
    expect(envVariables.value).toBeDefined()
    expect(envVariables.secretRef).toBeDefined()
  })

  it('has envId reference column', () => {
    expect(envVariables.envId).toBeDefined()
  })
})

// ---------------------------------------------------------------------------
// auditEvents table — DECISION-0020
// ---------------------------------------------------------------------------
describe('auditEvents table', () => {
  it('is defined', () => {
    expect(auditEvents).toBeDefined()
  })

  it('has tenantId column (security: multi-tenant isolation)', () => {
    expect(auditEvents.tenantId).toBeDefined()
  })

  it('has eventPayload column (security: audit record integrity)', () => {
    expect(auditEvents.eventPayload).toBeDefined()
  })

  it('has eventKind column', () => {
    expect(auditEvents.eventKind).toBeDefined()
  })

  it('has outcome column with success/failure/unknown enum', () => {
    expect(auditEvents.outcome).toBeDefined()
  })

  it('has actorId column', () => {
    expect(auditEvents.actorId).toBeDefined()
  })

  it('has eventTime column', () => {
    expect(auditEvents.eventTime).toBeDefined()
  })

  it('has receivedAt column', () => {
    expect(auditEvents.receivedAt).toBeDefined()
  })
})
