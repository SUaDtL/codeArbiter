import {
  pgTable,
  text,
  timestamp,
  integer,
  jsonb,
  uuid,
  char,
  boolean,
  real,
  primaryKey,
} from 'drizzle-orm/pg-core'

// DECISION-0011: tenant_id on every solution-related table; 'gdit' default for S1 single-tenant
export function withTenant<T extends Record<string, unknown>>(columns: T) {
  return {
    ...columns,
    tenantId: text('tenant_id').notNull().default('gdit'),
  }
}

// classification: none — solutions catalog metadata is unclassified at S1
export const solutions = pgTable('solutions', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  version: text('version').notNull(),
  maturity: text('maturity', { enum: ['prototype', 'mvp', 'production'] }).notNull(),
  description: text('description').notNull(),
  tenantId: text('tenant_id').notNull().default('gdit'),
  // graph stored as JSONB — typed at application layer via Zod
  graph: jsonb('graph').notNull().$type<{ nodes: unknown[]; adapters: unknown[] }>(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

// classification: none — deployment records at S1 contain no CUI
// DECISION-0018: SQL table renamed to deployment_receipts; export kept for route compat
export const deployments = pgTable('deployment_receipts', {
  id: text('id').primaryKey(),
  solutionId: text('solution_id')
    .notNull()
    .references(() => solutions.id),
  solutionName: text('solution_name').notNull(),
  status: text('status', {
    enum: ['queued', 'provisioning', 'configuring', 'verifying', 'success', 'failed'],
  }).notNull(),
  actorSub: text('actor_sub').notNull(),
  // CONFIRM-12: provisional enum — shape TBD pending CONFIRM-02/CONFIRM-03; do not copy to new tables
  classification: text('classification', { enum: ['none', 'cui', 'secret_ref'] })
    .notNull()
    .default('none'),
  replicaCount: integer('replica_count').notNull().default(1),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  tenantId: text('tenant_id').notNull().default('gdit'),
  solutionGitSha: char('solution_git_sha', { length: 40 }),
  environmentId: text('environment_id'),
  pinnedArtifacts: jsonb('pinned_artifacts').$type<{
    pin_protocol_version: number
    nodes: unknown[]
    adapters: unknown[]
  }>(),
  dependencyCheckResults: jsonb('dependency_check_results').$type<unknown[]>(),
  pinnedPositionsJsonb: jsonb('pinned_positions_jsonb').$type<unknown[]>(),
  teardownTierAtDeploy: text('teardown_tier_at_deploy', {
    enum: ['clean', 'partial', 'manual'],
  }),
  snapshotSha256: char('snapshot_sha256', { length: 64 }),
  snapshotBlobRef: text('snapshot_blob_ref'),
  finalLogsRef: text('final_logs_ref'),
  startedAt: timestamp('started_at', { withTimezone: true }),
  completedAt: timestamp('completed_at', { withTimezone: true }),
})

// classification: none — DECISION-0017: relational split; position_id is stable across node-kind renames
export const solutionNodes = pgTable(
  'solution_nodes',
  withTenant({
    solutionId: text('solution_id').notNull().references(() => solutions.id),
    positionId: uuid('position_id').notNull(),
    nodeKind: text('node_kind').notNull(),
    nodeGitSha: char('node_git_sha', { length: 40 }).notNull(),
    nodeVersion: text('node_version'),
    nodeConfig: jsonb('node_config').$type<Record<string, unknown>>(),
    positionX: real('position_x'),
    positionY: real('position_y'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  }),
  (table) => [primaryKey({ columns: [table.solutionId, table.positionId] })],
)

// classification: none — DECISION-0017: directed adapter-mediated connection between position_ids
export const solutionEdges = pgTable(
  'solution_edges',
  withTenant({
    id: text('id').primaryKey(),
    solutionId: text('solution_id').notNull().references(() => solutions.id),
    fromPositionId: uuid('from_position_id').notNull(),
    toPositionId: uuid('to_position_id').notNull(),
    adapterId: text('adapter_id').notNull(),
    adapterGitSha: char('adapter_git_sha', { length: 40 }).notNull(),
    adapterVersion: text('adapter_version'),
    adapterConfig: jsonb('adapter_config').$type<Record<string, unknown>>(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  }),
)

// classification: none — DECISION-0019: environment profiles for deploy-wizard variable resolution
export const environments = pgTable(
  'environments',
  withTenant({
    id: text('id').primaryKey(),
    name: text('name').notNull(),
    targetType: text('target_type', {
      enum: ['aws', 'vmware', 'baremetal', 'hybrid'],
    }).notNull(),
    variablesSchema: jsonb('variables_schema').$type<{ schema_version: number }>(),
    trustedForActiveChecks: boolean('trusted_for_active_checks').notNull().default(false),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  }),
)

// classification: varies — DECISION-0019: value XOR secret_ref constraint enforced at Zod layer
export const envVariables = pgTable(
  'env_variables',
  withTenant({
    id: text('id').primaryKey(),
    envId: text('env_id').notNull().references(() => environments.id),
    name: text('name').notNull(),
    valueKind: text('value_kind', {
      enum: ['plain', 'reference', 'masked-default'],
    }).notNull(),
    value: text('value'),
    secretRef: text('secret_ref'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  }),
)

// classification: none — DECISION-0020: append-only; UPDATE/DELETE blocked at application layer
export const auditEvents = pgTable(
  'audit_events',
  withTenant({
    eventId: text('event_id').primaryKey(),
    eventKind: text('event_kind').notNull(),
    eventTime: timestamp('event_time', { withTimezone: true }).notNull(),
    actorId: text('actor_id').notNull(),
    outcome: text('outcome', { enum: ['success', 'failure', 'unknown'] }).notNull(),
    eventPayload: jsonb('event_payload').notNull().$type<Record<string, unknown>>(),
    receivedAt: timestamp('received_at', { withTimezone: true }).notNull().defaultNow(),
  }),
)
