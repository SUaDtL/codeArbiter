# Contributing to cove-apps-fusion

This guide covers how to contribute to this repo. For org-wide standards, see `cove-templates`. For project-internal rules (commits, security gates, TDD obligations), see [`CLAUDE.md`](./CLAUDE.md) — the project's single source of truth.

## Setting Up Locally

~~~bash
# Clone the repo
git clone https://gitea.cove.gdit/cove/cove-apps-fusion.git
cd cove-apps-fusion

# Install dependencies (hooks are installed automatically via the prepare script)
npm install

# Verify hooks are wired
ls .husky/

# Copy and populate environment variables
cp .env.example .env
~~~

### Git Hooks (Husky + lint-staged)

This project uses [Husky](https://typicode.github.io/husky/) for Git hooks and
[lint-staged](https://github.com/okonet/lint-staged) for staged-file linting.

```bash
# Install dependencies (hooks are installed automatically via the prepare script)
npm install

# Verify hooks are wired
ls .husky/
```

Hooks run on `pre-commit` (lint-staged: ESLint + tsc on staged files) and `pre-push`
(full `make ci` equivalent). Do not use `--no-verify` to skip them — see `CLAUDE.md §10`.

`make install-hooks` wires Husky hooks (equivalent to running `npm install`). Skipping hook setup means CI catches what your workstation should have caught — slower feedback, noisier CI runs.

If you contribute via Claude Code or another AI coding agent, `.claude/settings.json` governs the agent's bash and edit permissions. The committed defaults allowlist read-only Unix tools and restrict `git push` to non-destructive operations (force-push, push-to-`main`, and branch-delete remain blocked). Don't relax those without a CLAUDE.md §3 hard-rule review.

## Coding Standards

| Language | Formatter | Linter | Config File |
|---|---|---|---|
| TypeScript/JS | `prettier` (print width 100) | `eslint` + `tsc --noEmit` | `frontend/.prettierrc`, `backend/.prettierrc` |
| PowerShell | (none — manual style) | `PSScriptAnalyzer` | `PSScriptAnalyzerSettings.psd1` |
| Ansible | (none) | `ansible-lint` (moderate profile) | `.ansible-lint` |
| YAML/JSON | `prettier` (via lint-staged) | `check-yaml`, `check-json` | `.husky/` + `lint-staged` config |

General rules:
- Inline comments explain **why**, not **what**
- No hardcoded secrets, paths, or environment-specific values — parameterize everything
- Files end with a newline; no trailing whitespace — lint-staged enforces both

**Cross-references to CLAUDE.md (the source of truth):**
- Test-driven development obligations: [`CLAUDE.md` §9](./CLAUDE.md#9-tdd-contract). Every feature ships with a failing test written first.
- Stage-gated rules: [`CLAUDE.md` §1](./CLAUDE.md#1-project-purpose--current-stage). Some rules apply only at certain stages — check `.fusion/stage` and the `[Sn]` tags in `docs/`.
- Conflict-resolution hierarchy: [`CLAUDE.md` §0](./CLAUDE.md#0-conflict-resolution-hierarchy). Cite the level at which any non-obvious tradeoff was made in the PR description.
- Always-loaded hard rules: [`CLAUDE.md` §3](./CLAUDE.md#3-always-loaded-hard-rules). Things you cannot do regardless of context (FIPS, secrets, shell injection, direct `main` writes).

## Branch Hierarchy

This repo uses a **trunk-based-with-buffer** model:

| Branch | Role | PR target |
|---|---|---|
| `main` | Stable trunk. Production-grade history. Versioned via semver tags. | (only `dev` PRs at promotion time, plus `hotfix/*`) |
| `dev` | Less-stable integration buffer. Active feature work merges here. | `main` (at promotion time) |
| `<prefix>/<scope>` | Feature, fix, chore, docs, or arbiter work. Short-lived. | `dev` |

**Normal flow:** start by checking out `dev`. If picking up an existing branch, `git checkout <branch>` instead. New work always branches from `dev`. Commits accumulate on the work branch. PR the work branch into `dev`. Periodically — when `dev` represents a coherent stable point — open a PR `dev` → `main` and tag the resulting `main` commit per the Tag Naming section.

`main` PRs are reserved for promotion events and hotfixes; routine work never targets `main` directly.

## Branch Naming

This is the **v0.5 naming standard** (subject to refinement until v1.0; current as of 2026-05-07).

| Prefix | Use | Branches off | Example |
|---|---|---|---|
| `feature/` | New functionality | `dev` | `feature/add-reboot-handler` |
| `fix/` | Bug fix | `dev` | `fix/yum-lock-timeout` |
| `hotfix/` | Urgent production fix | `main` | `hotfix/cert-renewal` |
| `chore/` | Non-functional (deps, CI, lint) | `dev` | `chore/update-ansible-lint` |
| `docs/` | Documentation only | `dev` | `docs/add-rollback-steps` |
| `arbiter/` | Fusion-arbiter session output (decisions, evidence, variance) | `dev` | `arbiter/2026-05-07-area-1-stack` |

All lowercase, hyphens only, no underscores. Delete your branch after merging.

**Arbiter branches additionally follow the pattern `arbiter/YYYY-MM-DD-<scope>`** so sessions are time-orderable via `git branch --list 'arbiter/*'`. Scope is the area or focus of the arbitration session (e.g., `area-1-stack`, `area-3-state`, `cross-cutting-fips-review`).

`hotfix/` is the only prefix that branches off `main` directly. Hotfix PRs target `main`, and the same fix is also merged back into `dev` immediately after the hotfix lands so the integration branch stays in sync.

## Commit Messages

Commit message format is governed by [`CLAUDE.md` §10](./CLAUDE.md#10-commit-policy) and uses Conventional Commits:

```
type(scope): short imperative description — 72 chars max

Body explains WHY, not WHAT.
```

Valid types: `feat` `fix` `test` `refactor` `docs` `chore` `ci` `infra`
Valid scopes: `backend` `frontend` `ansible` `docs` `ci` `infra` `schemas` `agents`

`feat` and `fix` commits MUST update `[Unreleased]` in `CHANGELOG.md` in the same commit. `test`, `refactor`, `docs`, `chore`, `ci` commits do not.

## Tag Naming

Releases use [Semantic Versioning](https://semver.org/): `v<major>.<minor>.<patch>`. Release tags live on `main` only — never on `dev` or feature branches.

| Tag form | Use |
|---|---|
| `v0.5.0` | Standard release on `main` |
| `v0.5.0-rc.1`, `v0.5.0-rc.2` | Release candidates (cut from `dev`, tagged on `main` after promotion) |
| `v0.5.0-mvp1` | Stage-milestone-tagged release |
| `stage-2-promotion` (annotated, no version) | Stage promotion marker per `CLAUDE.md` §1; created with `git tag -a stage-2-promotion -m "<promotion notes>"` |

**Semver bump rules:**
- **Major** (`v1.x.x` → `v2.x.x`): breaking change to a FUSION contract (`definition.yaml` shape, solution manifest, audit-event schema), public API surface, or operator-facing CLI/config. Rare; warrants stage-review notes in the PR.
- **Minor** (`v0.5.x` → `v0.6.x`): backwards-compatible new functionality — new node/adapter kinds, new audit fields, additive schema changes.
- **Patch** (`v0.5.0` → `v0.5.1`): bug fixes, security fixes, dependency bumps with no behavior change.

Releases are signed; release tags MUST point at a CI-passing commit. Stage-promotion annotated tags are signed at S3+ per `docs/cicd.md`.

## Pull Request Process

1. Push your feature branch to Gitea.
2. Open a PR against `dev` (or `main` only for `hotfix/*` branches and `dev` → `main` promotions — see Branch Hierarchy). The PR checklist populates automatically.
3. **PR title format:** match the lead commit's Conventional Commits header — `type(scope): description`. Body uses the Gitea PR template.
4. Fill in the checklist — mark inapplicable items N/A with a note.
5. Request a review. CODEOWNERS will suggest appropriate reviewers.
6. Address feedback with new commits — do not force-push during review.
7. Once approved, merge via the Gitea UI and delete the branch.

### Code Review Expectations

Reviewers verify:
- Tests are present and meaningful (per `CLAUDE.md` §9 TDD obligations — failing test written first, happy + sad paths covered, audit-emit asserted where applicable).
- Conventional Commits format is followed; `feat`/`fix` commits include the `CHANGELOG.md` `[Unreleased]` update.
- Tradeoff is cited in the PR description if any non-obvious decision was made (per `CLAUDE.md` §0). CI label `tradeoff-cited` applies.
- No hardcoded secrets, paths, or environment-specific values.
- Stage-tagged rules are honored at the current `.fusion/stage` value.
- Subagents named in the PR description (e.g. `security-reviewer`, `migration-reviewer`) actually reviewed the relevant change classes per `CLAUDE.md` §5.

Self-merging your own PR is forbidden per `docs/cicd.md` (AC-5, separation of duties). Single-contributor moments still need a second pair of eyes — pair-review with a teammate or run an automated review pass before merging.

### dev → main Promotion

When `dev` represents a coherent stable point worth tagging:
1. Open a PR `dev` → `main`. Title: `chore(release): promote dev to v<X.Y.Z>`.
2. Body summarizes notable `feat`/`fix` entries since the last promotion (lift from `CHANGELOG.md [Unreleased]`).
3. CI runs the full non-bypass gate set against the merge commit, not against `dev` HEAD.
4. After merge, tag the resulting `main` commit per Tag Naming. Move `[Unreleased]` content into a versioned section in `CHANGELOG.md`.
5. Immediately merge `main` back into `dev` to keep the integration branch synchronized.

## ADR (Decision Record) Naming

Architecture decisions are recorded in `docs/decisions/` using the file pattern `<NNNN>-<kebab-case-summary>.md` with four-digit zero-padded numbering (e.g., `0004-adopt-nodejs-typescript-backend.md`). Index lives at `docs/decisions/README.md`. ADRs are append-only — once merged, never edited; supersession happens via a new ADR that references the prior one.

## Arbiter Output Naming

Files produced by the `fusion-arbiter` skill follow the pattern `docs/fusion-arbiter-<artifact>.md`:

| File | Lifecycle |
|---|---|
| `docs/fusion-arbiter-decisions.md` | Append-only with hash tracking (per `references/decision-log-format.md`) |
| `docs/fusion-arbiter-evidence.md` | Overwritten every full scan |
| `docs/fusion-arbiter-variance-report.md` | Overwritten every full scan |
| `docs/fusion-arbiter-readiness.md` | Overwritten every full scan |

Arbitration session work is committed on `arbiter/YYYY-MM-DD-<scope>` branches (see Branch Naming above) and PR'd to `dev` when the session ends.

## How cove-shared Modules Are Consumed (MVP1 — Stage 1)

This section's contract is MVP1-specific. At Stage 2+ the consumption model may shift to direct dependency on a versioned `cove-shared` registry; revisit at the next stage promotion.

1. Go to `cove-shared` in Gitea → Releases.
2. Download the release zip for the version you need.
3. Extract the module(s) you need into `src/` or `lib/`.
4. Pin the version in `solution.yaml` under the `dependencies` field.

Do NOT use `git submodule` or `pip install git+https://...`.
