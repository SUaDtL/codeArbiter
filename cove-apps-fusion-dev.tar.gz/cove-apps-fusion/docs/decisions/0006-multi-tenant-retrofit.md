# ADR-0006: Multi-Tenant Retrofit Prevention

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0011

## Context

The current `solutions` and `deployments` tables in `backend/src/db/schema.ts` have no `tenant_id` column. FUSION's architecture anticipates future SaaS or multi-agency deployment. Retrofitting `tenant_id` onto populated tables after data exists forces a migration with correctness risks and requires revisiting every OPA authorization decision that was implicitly cross-tenant.

## Decision

Add `tenant_id` (text, default `'gdit'`, NOT NULL) to `solutions`, `deployments`, and every future solution-related table via a single Drizzle helper `withTenant(table)` (DECISION-0011). The helper consistently adds the column, a FK to a future `tenants` table, and a composite index `(tenant_id, <primary key>)`. Every query touching solution-related tables MUST scope by `tenant_id`. Bypassing the helper on a new table is a CI-detectable convention violation. At MVP1, `'gdit'` is the only valid `tenant_id` value, enforced by check constraint or app-layer enum until the `tenants` table arrives.

## Consequences

- Zero functional change at MVP1: single-tenant operation is unchanged; the column is always `'gdit'`.
- Every future solution-related table inherits the convention by design rather than by memory.
- Every OPA authorization input includes `tenant_id` from day one, keeping the authorization model tenant-scoped when multi-tenancy activates.
- A Semgrep or ESLint rule flags any direct table reference in routes that bypasses a tenant-scoped repository helper.
- The `withTenant()` helper is the single evolution point; schema drift across tables is prevented structurally rather than by convention alone.
