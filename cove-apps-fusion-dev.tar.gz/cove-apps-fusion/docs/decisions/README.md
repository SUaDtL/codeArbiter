# Decision Log Index

Append-only. One file per decision. Supersede by adding a new file referencing
the prior one — never edit prior entries.

Format: `NNNN-short-slug.md`. Numbering is monotonic.

## Decisions

- [0001 — Adopt CLAUDE.md contract for `fusion-core`](0001-adopt-claude-md-contract.md)
- [0002 — Adopt `@xyflow/react@12` in place of `reactflow@11`](0002-adopt-xyflow-react-v12.md)
- [0003 — Adopt OCSF-aligned audit event schema with abstract emit interface](0003-adopt-ocsf-audit-schema.md)
- [0004 — Adopt Node.js/TypeScript for the backend (Z-API + Z-WORKER)](0004-adopt-nodejs-typescript-backend.md)
- [0005 — Worker execution architecture](0005-worker-execution-architecture.md)
- [0006 — Multi-tenant retrofit prevention](0006-multi-tenant-retrofit.md)
- [0007 — Sub-solution composition and git SHA pinning](0007-sub-solution-composition-and-gitsha-pinning.md)
- [0008 — Schema contracts for state tables and audit transport](0008-schema-contracts.md)
- [0009 — API enforcement pattern — schemas, authZ, and solution manifest](0009-api-enforcement-pattern.md)
- [0010 — Security posture — FIPS startup assertion, Zero Trust bootstrap, and trust-zone integrity](0010-security-posture.md)

## Review Cadence

This index + every linked ADR MUST be reviewed at every Stage promotion AND
every 12 weeks at minimum. (CM-3, PM-9)
