# ADR-0009: API Enforcement Pattern — Schemas, AuthZ, and Solution Manifest

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0021, DECISION-0025, DECISION-0026

## Context

The FUSION backend routes have no OPA authorization checks beyond authentication, no formal solution manifest JSON Schema, and no deployment-receipt JSON Schema. Routes use manual `safeParse`/`parse` inside handlers rather than Fastify's route-level `schema:` validation. This leaves AC-3 enforcement unenforced at the implementation layer and creates validation drift across every consumer of solution and receipt data.

## Decision

**Solution manifest schema (DECISION-0021):** Author `schemas/solution.schema.json` now, co-located with `schemas/node.schema.json` and `schemas/adapter.schema.json`. The schema encodes the relational shape from DECISION-0017 (`solution_nodes` + `solution_edges` with stable `position_id`), `tenant_id` (DECISION-0011), `environment_id` (DECISION-0019), `external_dependencies[]` (DECISION-0014), `sub_solutions[]`, `git_sha` (commit-pinned), and `metadata.schema_version`. This schema is the single validation source for the Gitea manifest, deploy-worker loader, UI loader, and SBOM exporter.

**Deployment-receipt schema (DECISION-0025):** Author `schemas/deployment-receipt.schema.json` co-located with the other schemas. Required fields include all consolidated snapshot fields from DECISION-0012, DECISION-0013, DECISION-0014, DECISION-0017, DECISION-0018: `solution_git_sha` (40-char hex), `teardown_tier_at_deploy`, `pinned_artifacts`, `snapshot_sha256` (64-char hex), `snapshot_signature` (cosign), `snapshot_blob_ref`, and `metadata.schema_version`. The receipt-emission code path validates the receipt against this schema before computing `snapshot_sha256` and signing.

**OPA authorization (DECISION-0026):** Build `backend/src/lib/authz/index.ts` exposing `authz.can(user, action, resource): Promise<{ allowed: boolean; reason? }>`. Wire `authz.can()` as a Fastify `preHandler` on every POST/PUT/DELETE route. Both allow and deny outcomes emit to Z-AUDIT (`authz.allowed` and `authz.denied`). OPA unreachable → fail closed: return 503 and emit `authz.denied` with `reason=engine_unreachable`. A `requireAuthz(action, resourceFn)` factory returns the preHandler; routes do not import OPA-specific types.

## Consequences

- Every consumer validates manifests and receipts against the same JSON Schema, eliminating ad-hoc parser drift.
- AC-3 enforcement at the API layer is no longer deferred; a route that forgets to register the `preHandler` is detectable by CI.
- The `authz.can()` helper is the single seam for a future engine swap (OPA → Cedar); routes are insulated from the engine implementation.
- The Zod route sweep (DECISION-0027) and the OPA preHandler sweep should land in a coordinated PR to avoid touching route files twice.
- External ATO assessors can reproduce the cosign signature check against `schemas/deployment-receipt.schema.json` without owning FUSION TypeScript types.
