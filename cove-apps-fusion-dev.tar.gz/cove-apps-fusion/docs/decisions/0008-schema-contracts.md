# ADR-0008: Schema Contracts for State Tables and Audit Transport

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0018, DECISION-0019, DECISION-0020

## Context

The scaffold's `deployments` table contains minimal fields that do not represent the receipt semantics required for audit-immutable, reproducible deployment records. No `environments` or `env_variables` tables exist. The audit transport choice (HTTP→Postgres vs. NATS JetStream) was left open in Doc 1 §3.8 pending arbitration.

## Decision

**Deployment receipts (DECISION-0018):** Rename `deployments` → `deployment_receipts` to express the append-only, point-in-time snapshot semantics. The table consolidates all upstream snapshot obligations: `tenant_id` (DECISION-0011), `pinned_artifacts` JSONB with `pin_protocol_version` (DECISION-0013), `teardown_capability_at_deploy_node/adapters` (DECISION-0012), `dependency_check_results` JSONB (DECISION-0014), `pinned_positions_jsonb` (DECISION-0017), plus artifact-required fields `solution_id`, `environment_id`, `started_at`, `completed_at`, `status`, `solution_age_status`, `pin_health_status`, `final_logs_ref`. The table is append-only by convention; DB-level WORM enforcement is deferred to the COMPLIANCE area arbitration addressing AU-9.

**Environment profiles (DECISION-0019):** Build `environments` and `env_variables` tables. The `environments` table includes `target_type` enum (`aws | vmware | baremetal | hybrid`), `variables_schema` JSONB with a `schema_version: 1` versioning hedge, and `trusted_for_active_checks` boolean. The `env_variables` table enforces a DB CHECK constraint: exactly one of `value` or `secret_ref` is set per row. `secret_ref` points at an AWS Secrets Manager ARN at MVP1; a `resolveSecretRef()` interface abstracts the resolver for future OpenBao swap. Every resolution emits a Z-AUDIT `secret.resolved` event.

**Audit transport (DECISION-0020):** Close the open transport decision in favor of S1 (HTTP→Postgres direct sink) for MVP1. The scaffold's existing `httpPost` implementation stands. S2 (NATS JetStream) transition is gated on Stage 2 promotion entry. The `audit_events` table is tenant-scoped via `withTenant()` and append-only by the same convention as deployment receipts. The `audit.emit()` interface remains abstract; no caller imports transport details.

## Consequences

- Approximately 2 routes and 3 test files require renaming from `deployments` to `deployment-receipts`; churn is small at S1 with no production data.
- The `(value IS NOT NULL) <> (secret_ref IS NOT NULL)` DB constraint prevents secrets from being accidentally stored as plaintext.
- The `variables_schema` version integer and `secret_ref` abstraction follow the MOSA evolvability pattern established by DECISION-0013.
- NATS JetStream remains the S2 transport; the interface-based design means the transition is a one-file swap without caller changes.
- A Semgrep rule must fail any `db.update(auditEvents)` or `db.delete(auditEvents)` call until DB-level WORM enforcement is applied.
