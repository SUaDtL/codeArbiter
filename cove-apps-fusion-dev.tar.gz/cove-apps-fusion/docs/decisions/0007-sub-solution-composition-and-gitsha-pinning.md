# ADR-0007: Sub-Solution Composition and Git SHA Pinning

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0012, DECISION-0013

## Context

FUSION must support two redeployment modes — logical reproduction (latest artifacts) and pinned reproduction (explicit artifact versions). The current schema stores `solutions.graph` as opaque JSONB with no pin model; nodes and adapters declare teardown as a free-form string rather than a machine-enforceable tier. Both gaps make publication gates, deployment-receipt audit trails, and reproducibility guarantees unimplementable at the schema layer.

## Decision

**Teardown capability tiers (DECISION-0012):** Add a required `teardown_capability` enum (`clean | partial | manual`) to both `schemas/node.schema.json` and `schemas/adapter.schema.json`. Both `teardown_capability` and `teardown_procedure` are required — the enum classifies the operational tier; the procedure documents the steps. The publication gate must block merge without this declaration and require elevated permission when `teardown_capability == "manual"`. Every deployment receipt MUST record `teardown_capability_at_deploy_time` for both node and adapters; historical receipts reflect the tier in force at deploy time, not the current node state.

**Pin metadata and monitoring (DECISION-0013):** Add four columns to `solutions` at MVP1: `pinned_artifacts` (JSONB), `solution_last_tested` (timestamptz), `solution_age_status` (enum `green | yellow | red`), `pin_health_status` (enum `healthy | degraded | unknown`). Every entry in `pinned_artifacts` JSONB MUST include a `pin_protocol_version` integer (start at `1`) to reserve the format-evolution lane. The pin-monitoring CI (V1.PIN.*) that computes age status is deferred to V1; MVP1 leaves these fields at default-unknown/default-green.

## Consequences

- `docs/domain.md` must be updated to reflect the tiered teardown model, resolving the existing conflict with Doc 1 §6.4.
- `make validate-definitions` and CI must enforce both `teardown_capability` presence and the elevated-permission rule for `manual` nodes.
- Pin columns added at MVP1 cost near-zero; skipping them would require migrating every existing solution row at V1 and creates an implicit vote against artifact archives.
- The `pin_protocol_version` hedge allows V2 entries (e.g., provenance attestations) to coexist with V1 entries without a full-table migration.
- Z-AUDIT gains a `deployment.teardown_capability` field populated on every deployment record.
