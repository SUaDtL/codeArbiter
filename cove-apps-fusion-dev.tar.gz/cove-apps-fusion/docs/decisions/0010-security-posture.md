# ADR-0010: Security Posture — FIPS Startup Assertion, Zero-Trust Bootstrap, and Trust-Zone Integrity

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0039, DECISION-0041, DECISION-0044

## Context

Three security posture gaps existed in the scaffold: (1) FIPS compliance was only checked at CI time, not on deployment hosts; (2) Zero Trust controls (Keycloak OIDC, OPA) were not running locally, leaving auth middleware unexercised and Z-AUDIT events without real identity metadata; (3) the frontend emitted audit events directly to the audit sink, bypassing Z-API and allowing any browser with `VITE_AUDIT_SINK_URL` to inject arbitrary audit records.

## Decision

**FIPS runtime assertion (DECISION-0039):** Add a FIPS startup check to `backend/src/main.ts` before server start. In `NODE_ENV=development`, log a warning if `require('crypto').getFips() !== 1`. In all other environments, throw and refuse to start. This satisfies SC-13 at runtime, not just on the CI host.

**Zero Trust bootstrap (DECISION-0041):** Add Keycloak and OPA to `docker-compose.yml`. Configure a FUSION development OIDC realm with bootstrap seed data, roles (`Solutions Engineer`, `Admin`), and one dev user. Remove `DEV_AUTH_BYPASS` as a default-on path — require real OIDC tokens in dev. This ensures audit events carry real identity metadata (`credential_id`, `trust_zone`, `policy_decision`) from the start of development. Identity management is the first Zero Trust control plane; data protection and governance controls (AC-16, SC-28) are next-priority work once identity is wired.

**Trust-zone integrity: frontend audit path (DECISION-0044):** Remove the direct `fetch(VITE_AUDIT_SINK_URL, ...)` call from `frontend/src/lib/audit/index.ts`. The frontend emits no audit events directly to Z-AUDIT. All user-initiated actions are audited at the Z-API layer when the corresponding API request is processed. Remove `VITE_AUDIT_SINK_URL` from frontend env config. Update `docs/architecture/trust-zones.md` to close the open question: Z-UI does not emit to Z-AUDIT directly.

## Consequences

- Dev contributors without FIPS-enabled OpenSSL receive a warning rather than a hard failure, preserving dev workability while protecting all non-development environments.
- Removing `DEV_AUTH_BYPASS` as a default-on path requires Keycloak to be running locally; `docker-compose.yml` must be authored to make `make up` operational.
- The browser-side audit injection vector (AU-9, AU-10 violation) is closed; the `emit()` function in the frontend becomes a no-op, and existing tests must assert no-op behavior.
- `security-reviewer` subagent must verify Keycloak + OPA wiring and confirm no other frontend→audit-sink paths exist.
- The `DEV_AUTH_BYPASS` flag may still exist at Stage 1 with a prominent startup warning; CONFIRM-11 in `docs/open-questions.md` governs the Stage 2 keep/remove decision.
