# ADR-0005: Worker Execution Architecture

**Date:** 2026-05-08
**Status:** Accepted
**Decided by:** Brennon Huff
**Arbiter references:** DECISION-0010, DECISION-0034

## Context

The FUSION Z-WORKER service must call worker implementations (Ansible, future alternatives) to execute deployment plans. Without an abstraction, Z-WORKER orchestration code couples directly to Ansible internals, making any future worker swap a codebase rewrite. Additionally, the subprocess execution model needed a security posture record before the first worker implementation sprint began.

## Decision

Define an `ExecutionWorker` interface in `backend/src/worker/types.ts` before any FUSION node is authored (DECISION-0010). The interface exposes only what Z-WORKER calls: `execute(plan): WorkerHandle`, `cancel(handle)`, `streamOutput(handle): AsyncIterable<OutputChunk>`, and capability discovery (`supportedNodeKinds`, `supportedAdapterKinds`). Concrete implementations (`AnsibleWorker`, `MockWorker`) live under `backend/src/worker/impl/`. The `MockWorker` is the second concrete consumer — it validates that the interface is not Ansible-shaped and serves all Z-WORKER unit tests. Z-WORKER holds a single `ExecutionWorker` selected by `WORKER_IMPL` config.

Subprocess invocations MUST use argv-array form only. `shell: true` is prohibited without exception (CLAUDE.md §3, SI-10). The staged sandbox model progresses from restricted-env at MVP1 to K8s Job at V1 graduation; ADR-0005 is the auditable record of that progression contract (DECISION-0034).

## Consequences

- `STACK.IAC.CONFIG-MGMT` (Ansible vs alternatives) becomes a worker-implementation swap rather than a codebase rewrite.
- `MockWorker` enables hermetic Z-WORKER unit tests with no real Ansible dependency.
- Every future worker implementation is measured against the `ExecutionWorker` interface; bypassing it is detectable.
- The `shell: true` prohibition is enforced by both CLAUDE.md §3 and a Semgrep rule (`dangerous-spawn-shell`); no ADR waiver can override it.
- V1 graduation to K8s Job must be captured in a follow-on implementation record when the worker sprint begins.
