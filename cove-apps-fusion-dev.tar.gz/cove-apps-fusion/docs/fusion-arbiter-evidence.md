# FUSION Arbiter — Evidence Index

> **ARBITER WORKING FILE** — Produced and rebuilt by the `/fusion-arbiter` skill on each
> scan. Not authoritative project documentation. For architecture decisions, cite
> `docs/fusion-arbiter-decisions.md` instead. Do not use this file as evidence in
> downstream design work.

**Generated:** 2026-05-08 (session continuation — Areas 6–12 scan)
**Scan basis:** decomposition docs at `docs/decomposition/01..03-*.md`; scaffold as of HEAD; ADRs 0001–0004; prior decisions DECISION-0001 through DECISION-0029.
**Working file** — overwritten on every full scan.

Format per category: **Decision ID → Artifact source / Stated position / Scaffold evidence / Variance status.**

Status legend per SKILL.md Stage 2:
- `concur` — both have evidence and they agree
- `divergent` — both have evidence and they disagree
- `scaffold-silent` — artifact has position, scaffold has no evidence
- `artifact-silent` — scaffold has implementation, artifact has no position
- `both-silent` — neither has evidence (informational only)
- `same-level-conflict` — two sources at the same authority level disagree (escalate per Stage 4)
- `open-decision-closure` — scaffold implements one of the artifact-listed alternatives for a known-open decision (per `references/known-open-decisions.md` standardized handling)
- `consistent-with-deferral` — artifact defers to a later phase and scaffold rightly has no implementation; not a variance

---

## AREAS 1–5 SUMMARY (resolved, DECISION-0001 through DECISION-0028)

All Stack, Pattern, State, Schema, and API categories were resolved on 2026-05-07. No remaining variances in these areas. Refer to `docs/fusion-arbiter-decisions.md` for individual decisions.

---

## AREA 6 — REPO

### REPO.GITEA.ORG
- **Artifact:** Doc 1 §3.7 — `FUSION_ORG` organization in Gitea
- **Scaffold:** No Gitea provisioning scripts or Terraform resources configuring `FUSION_ORG`. No IaC. `terraform/main.tf` has zero resources.
- **Status:** `scaffold-silent`

### REPO.GITEA.NODES
- **Artifact:** Doc 1 §3.7 — `fusion-nodes` repo under `FUSION_ORG`
- **Scaffold:** `fusion-nodes/` directory does NOT exist. No provisioning logic.
- **Status:** `scaffold-silent`

### REPO.GITEA.ADAPTERS
- **Artifact:** Doc 1 §3.7 — `fusion-adapters` repo under `FUSION_ORG`
- **Scaffold:** `fusion-adapters/` directory does NOT exist. No provisioning logic.
- **Status:** `scaffold-silent`

### REPO.GITEA.POLICIES
- **Artifact:** Doc 1 §3.7 — `fusion-policies` repo for OPA Rego
- **Scaffold:** No `fusion-policies/` directory. No provisioning logic.
- **Status:** `scaffold-silent`

### REPO.GITEA.SCHEMAS
- **Artifact:** Doc 1 §3.7 — `fusion-schemas` repo for OCSF + JSON Schema
- **Scaffold:** `schemas/` directory EXISTS with `node.schema.json`, `adapter.schema.json`, `audit-event.schema.json`. These schemas live in the monorepo, not a separate Gitea repo. No provisioning for a separate `fusion-schemas` Gitea repo.
- **Status:** `divergent` — artifact says separate Gitea repo; scaffold colocates schemas in monorepo

### REPO.GITEA.SOLUTIONS
- **Artifact:** Doc 1 §3.7 — per-solution repos under `solution-*` naming
- **Scaffold:** No `solution-*` directories. No provisioning logic. Consistent with Stage 1 (no solutions built yet).
- **Status:** `consistent-with-deferral` (no solutions exist yet)

### REPO.BRANCH-PROTECTION
- **Artifact:** Doc 1 §3.7 — no force push to main, PR-only merges
- **Scaffold:** `CODEOWNERS` enforces PR-based review for all paths. No Gitea API calls to configure branch protection rules. `CLAUDE.md §3` has hard rule against force-push to main.
- **Status:** `divergent` — policy documented and culturally enforced but no API-level automation for branch protection in Gitea

---

## AREA 7 — DEPLOY

### DEPLOY.HELM-CHART
- **Artifact:** Doc 1 §5, Doc 2 Phase 1 tasks — single Helm chart bundles entire FUSION
- **Scaffold:** No `helm/` directory. No `Chart.yaml`. Consistent with MVP1 pre-deployment phase.
- **Status:** `scaffold-silent`

### DEPLOY.SELF-CONTAINED
- **Artifact:** Doc 1 §6.1 — no external SaaS runtime dependencies (Ansible exception pending)
- **Scaffold:** `docker-compose.yml` bundles postgres, backend, audit-sink. Gitea, Keycloak, OPA missing from compose. No external SaaS dependencies visible.
- **Status:** `concur` (partially — D6 confirmed self-contained intent; missing services are known scaffold gaps, not external SaaS dependencies)

### DEPLOY.K3S-HOSTING
- **Artifact:** Doc 1 §5 LOCKED — K3s on EC2 in Cove.GDIT for MVP1
- **Scaffold:** `terraform/main.tf` has AWS provider config + `aws_region` variable. Zero compute resources defined. No K3s config.
- **Status:** `scaffold-silent`

### DEPLOY.AWS-TARGET
- **Artifact:** Doc 1 §5 LOCKED — OpenTofu AWS provider for MVP1
- **Scaffold:** `terraform/main.tf` uses `hashicorp/aws` provider (via OpenTofu). Provider block present, no resources.
- **Status:** `concur` (provider declared, resources deferred per plan)

### DEPLOY.SUBPROCESS-SANDBOX
- **Artifact:** Doc 1 §3.3, §6.1 — restricted env (MVP1) → K8s Job (V1); no `shell: true`
- **Scaffold:** No worker execution code yet. CLAUDE.md §3 hard rule against `shell: true`. No subprocess sandbox implementation.
- **Status:** `scaffold-silent`

---

## AREA 8 — CI

### CI.HUSKY-PRECOMMIT
- **Artifact:** Doc 2 Phase 1 / Doc 3 MVP1.CI.001 — pre-commit hooks via Husky
- **Scaffold:** `.pre-commit-config.yaml` EXISTS (Python-style pre-commit framework). `backend/package.json` has NO husky dependency. `Makefile` has `install-hooks` target that references `npx husky install` (or similar) but actual husky binary absent.
- **Status:** `divergent` — artifact says Husky (npm-based); scaffold uses Python pre-commit framework

### CI.LINT-STAGED
- **Artifact:** Doc 2 Phase 1 / Doc 3 MVP1.CI.002 — staged-file linting via lint-staged
- **Scaffold:** `backend/package.json` — no `lint-staged` dependency. `.pre-commit-config.yaml` handles staged-file linting via Python hooks. No `lint-staged` config file.
- **Status:** `divergent` — artifact says lint-staged (npm); scaffold has no lint-staged

### CI.VITEST
- **Artifact:** Doc 1 §5, Doc 3 MVP1.CI.003 — Vitest test framework
- **Scaffold:** `backend/package.json` has `vitest@3.1.2`; 21 tests green; `.gitea/workflows/ci-linux.yml` runs `npx vitest run --coverage`
- **Status:** `concur`

### CI.DRIZZLE-MIGRATIONS
- **Artifact:** Doc 3 MVP1.CI.004 — migration check in CI
- **Scaffold:** `backend/drizzle/` directory ABSENT. No `drizzle-kit` migration commands in CI pipeline. `ci-linux.yml` has no migration check step.
- **Status:** `scaffold-silent`

### CI.ZOD-ROUTE-COVERAGE
- **Artifact:** Doc 1 §3.2 — F-019 enforcement; every route must register Zod schemas
- **Scaffold:** No CI gate enforcing Zod route coverage. F-019 still in CHANGELOG `[Unreleased]`. Resolved via DECISION-0021 (adopt artifact position — add gate at next MVP1 sprint).
- **Status:** `scaffold-silent` (noted: DECISION-0021 commits to this)

### CI.OCSF-AUDIT-VALIDATION
- **Artifact:** Doc 1 §3.8 — OCSF schema validation hook
- **Scaffold:** `.gitea/workflows/ci-linux.yml` has `validate` job running `make validate-definitions`. No specific OCSF audit schema validation step visible. `schemas/audit-event.schema.json` exists but no CI validation against it.
- **Status:** `scaffold-silent`

### CI.SEMGREP-AUDIT-EMIT
- **Artifact:** Doc 1 §3.8 — Semgrep rule enforcing `audit.emit()` on every security-relevant action
- **Scaffold:** `.semgrep/` has `bare-fetch.yml` and `shell-injection.yml`. NO audit-emit enforcement rule. CLAUDE.md §5 references `audit-emitter` subagent but no CI Semgrep gate.
- **Status:** `scaffold-silent`

### CI.LICENSE-CHECK
- **Artifact:** Doc 2 Phase 1 — dependency license allowlist enforcement
- **Scaffold:** `.gitea/workflows/ci-linux.yml` has `license` job running `make license-scan`. `ALLOWED_LICENSES.md` exists.
- **Status:** `concur`

### CI.PIPELINE
- **Artifact:** Doc 2 Phase 1 — Gitea Actions or external CI
- **Scaffold:** `.gitea/workflows/ci-linux.yml` exists — comprehensive 10-job pipeline
- **Status:** `concur`

---

## AREA 9 — COMPLIANCE

### COMPLIANCE.FIPS-CAPABLE
- **Artifact:** Doc 1 §4, Doc 2 Phase 2+ — FIPS-compatible builds where applicable; ADR-0001 SC-13
- **Scaffold:** CI pipeline has `fips-check` job running `make fips-check`. No FIPS startup assertion in `backend/src/main.ts` (no `require('crypto').getFips()` check at boot). CI validates FIPS capability but server does not assert it at runtime.
- **Status:** `divergent` — CI gate present but no runtime assertion on server startup

### COMPLIANCE.STIG-IMAGES
- **Artifact:** Doc 1 §4 — STIG'd base images for nodes
- **Scaffold:** No `Dockerfile` in `fusion-nodes/` (directory doesn't exist). No STIG image references. Container scan job uses `trivy` in CI but no base image defined yet.
- **Status:** `scaffold-silent` (consistent with no nodes built yet — partial deferral)

### COMPLIANCE.NIST-800-53
- **Artifact:** Doc 1 §4, ADR-0003 — control mapping per audit spec
- **Scaffold:** `CODEOWNERS` cites NIST controls per section. `docs/security-controls.md` exists. ADR-0003 status: accepted.
- **Status:** `concur`

### COMPLIANCE.ZERO-TRUST
- **Artifact:** Doc 1 §4, §6 — Keycloak + OPA pattern, audit trail, ZT metadata fields in every audit event
- **Scaffold:** Keycloak + OPA pattern confirmed via DECISION-0001/0005. Audit schema has ZT fields (`trust_zone`, `credential_id`, `policy_decision`). `docker-compose.yml` missing Keycloak + OPA services. ZT cascade not fully wired at runtime.
- **Status:** `divergent` — schema and ADR level concur; runtime wiring (compose services) is incomplete

---

## AREA 10 — DOCS

### DOCS.ADR-CONVENTION
- **Artifact:** Doc 1 §7 — ADRs follow defined template
- **Scaffold:** `docs/decisions/` has ADR-0001 through ADR-0004 following consistent template. `docs/decisions/README.md` index exists.
- **Status:** `concur`

### DOCS.NODE-AUTHORING-GUIDE
- **Artifact:** Doc 1 §7 — contribution guide for nodes
- **Scaffold:** No `docs/contribution/` directory. No `node-authoring-guide.md` or similar. `fusion-nodes/` directory absent.
- **Status:** `scaffold-silent`

### DOCS.ADAPTER-AUTHORING-GUIDE
- **Artifact:** Doc 1 §7 — contribution guide for adapters
- **Scaffold:** No adapter authoring guide. No `fusion-adapters/` directory.
- **Status:** `scaffold-silent`

### DOCS.RUNBOOKS
- **Artifact:** Doc 1 §7 — operational runbooks for FUSION deployment
- **Scaffold:** `docs/runbook.md` exists (basic scaffold, minimal content). No playbook scripts (`deploy/playbooks/` referenced in CODEOWNERS has no `.yml` files yet).
- **Status:** `divergent` — runbook stub exists but is a placeholder; Ansible playbooks (`pre-check.yml`, `main.yml`, `verify.yml`) absent

---

## AREA 11 — ARTIFACT-SILENT (scaffold has implementation, artifact has no position)

### ARTIFACT-SILENT.AUTH-BYPASS-FLAG
- **Artifact:** No position on auth bypass mechanism for development
- **Scaffold:** `backend/src/middleware/auth.ts` has `DEV_AUTH_BYPASS` environment variable logic allowing full auth bypass when set
- **Status:** `artifact-silent` — security-relevant, needs documented policy for when bypass is permissible

### ARTIFACT-SILENT.SHORTCUT-PAYBACK-MARKERS
- **Artifact:** No position on technical debt markers
- **Scaffold:** CHANGELOG `[Unreleased]` and inline `TODO:` comments reference F-019, F-020, and other shortcut items
- **Status:** `artifact-silent` — not a security issue; informational

### ARTIFACT-SILENT.DEPLOYMENT-CLASSIFICATION-FIELD
- **Artifact:** No explicit position on deployment record classification metadata
- **Scaffold:** `backend/src/db/schema.ts` has `classification` field on `deployments` table
- **Status:** `artifact-silent` — schema choice with no artifact backing; data classification implications

### ARTIFACT-SILENT.UI-TO-AUDIT-DIRECT-PATH
- **Artifact:** Doc 1 §3.8 + `docs/architecture/trust-zones.md` — Z-UI is NOT authorized to write directly to Z-AUDIT; only Z-API and Z-WORKER feed Z-AUDIT
- **Scaffold:** `frontend/src/lib/audit.ts` calls `audit.emit()` from Z-UI context, bypassing Z-API; trust-zones.md flags this as an open question for Stage 2
- **Status:** `artifact-silent` (trust-zone violation) — **HIGHEST SECURITY PRIORITY**

---

## AREA 12 — SAME-LEVEL CONFLICTS

### SLC-1: STACK.AUTH.IDENTITY — Keycloak vs CONFIRM-01
- **Source A:** Doc 1 §5 LOCKED — Keycloak LOCKED as identity provider
- **Source B:** `docs/open-questions.md` CONFIRM-01 — OIDC provider still listed as open question
- **Authority level:** Both are accepted project documentation (Doc 1 artifact vs open-questions.md)
- **Status:** `same-level-conflict`
- **Note:** DECISION-0001 resolved Keycloak as the identity provider on 2026-05-07. This conflict predates that decision and is now superseded. Documented here for completeness; no new variance.
