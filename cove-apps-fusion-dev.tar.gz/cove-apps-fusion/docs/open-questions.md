# Open Confirmations

The agent MUST NOT guess answers to these. When a task touches one, surface
the `[CONFIRM-NN]` ID and stop.

| ID | Question | Blocks |
|---|---|---|
| ~~CONFIRM-01~~ | ~~OIDC provider for Stage 1–2~~ — **RESOLVED** by DECISION-0001 (2026-05-07): Keycloak locked. | closed |
| CONFIRM-02 | FIPS 199 categorization — confirm Moderate/Moderate/Moderate for FUSION control plane. | `docs/data-classification.md` |
| CONFIRM-03 | Specific CUI categories in scope (e.g., `CUI//SP-PRVCY`, `CUI//SP-CTI`). | `docs/data-classification.md` markings |
| CONFIRM-04 | Owner for R-01 (Ansible GPLv3 risk). | `docs/risks.md` |
| CONFIRM-05 | Audit sink technology (CloudWatch Logs + KMS + S3 object-lock? Splunk? Elastic with WORM?). | `docs/audit-spec.md` retention/integrity |
| CONFIRM-06 | Authorization boundary — does Cove.GDIT count as a single boundary, or are sub-VPCs separate? | `docs/architecture/trust-zones.md`, `docs/data-classification.md` egress |
| CONFIRM-07 | Private container registry choice for Stage 3+ mirroring (ECR? Harbor on K3s?). | `docs/dependency-policy.md` |
| CONFIRM-08 | Does NIST AI RMF apply? (Is the AI in the deploy path, or strictly the dev-time coding agent?) | Whether to add `docs/ai-governance.md` |
| CONFIRM-09 | Stage promotion authority — who signs off Stage 1→2, 2→3, 3→4. | CLAUDE.md §1 |
| CONFIRM-10 | Production deployment topology — Stage 3 and Stage 4 HA targets. | `docs/architecture/trust-zones.md` |
| CONFIRM-11 | `DEV_AUTH_BYPASS` flag — keep in some form or remove entirely at Stage 2? Keycloak will be locally available (DECISION-0041); assess whether a dev/debug bypass mechanism still has legitimate use, and if so what shape it should take (per-user flag? test-fixture JWTs only? time-limited token?). | `backend/src/middleware/auth.ts`, Stage 2 promotion gate |
| CONFIRM-12 | Deployment classification field — the `classification` column in the `deployments` table is provisional scaffolding. What classification metadata (if any) belongs on deployment records? What shape: free-text string, enum from `docs/data-classification.md`, structured object? How does it interact with CONFIRM-02 (FIPS 199 categorization) and CONFIRM-03 (CUI categories)? Who sets it — the deploying user, the solution manifest, or the environment profile? | `backend/src/db/schema.ts`, `docs/data-classification.md`, CONFIRM-02, CONFIRM-03 |
