# SV-1 — FUSION System Interface Description

> **Working diagram — not a formal DoDAF artifact.**
> Intended for engineering interview and technical overview decks. Answers: *what systems make up FUSION, what are their interfaces, and how are trust boundaries enforced?*
>
> **To export for slides:** paste the Mermaid block at [mermaid.live](https://mermaid.live) → Actions → Export as SVG or PNG.

---

## Diagram

```mermaid
graph LR
    subgraph ZUI["Z-UI  ·  Browser Zone  (untrusted)"]
        UI["React 18 + React Flow 12\nTypeScript SPA\nVite dev / production build"]
    end

    subgraph ZAUTHZ["Identity & Policy  (Z-AUTHZ)"]
        KC["Keycloak 24+\nOIDC · SAML\nDev realm bootstrap"]
        OPA["OPA Policy Engine\nRego · Bundle API\nDefault-deny posture"]
    end

    subgraph ZAPI["Z-API  ·  Trusted API Zone"]
        MW["Auth + Authz Middleware\nOIDC token validation\nOPA preHandler on every route"]
        API["Fastify 5  ·  Node.js 22\nTypeScript · Zod schemas\nDrizzle ORM"]
        GW["Graphile Worker\nPostgres-backed job queue\nAsync deployment runner"]
    end

    subgraph ZDATA["Z-DB  ·  Data Zone"]
        PG["PostgreSQL 16\nFIPS-compatible build\nDrizzle migrations"]
    end

    subgraph ZLIB["Z-LIBRARY  ·  Gitea Zone"]
        GIT["Gitea\nfusion-nodes repo\nfusion-adapters repo\nfusion-policies repo"]
    end

    subgraph ZWORKER["Z-WORKER  ·  Execution Zone"]
        EXEC["Execution Sandbox\nMVP1: restricted subprocess (no shell: true)\nV1: K8s Job"]
        BAOREF["OpenBao (V1)\nSecret resolution\nNever materializes secrets in DB"]
    end

    subgraph ZTARGET["Z-TARGET  ·  Infrastructure"]
        K3S["K3s on EC2\nCove.GDIT  (MVP1)\nOpenTofu-provisioned"]
    end

    subgraph ZAUDIT["Z-AUDIT  ·  Append-Only"]
        SINK["Audit Sink\nS1: HTTP POST (fail-open)\nS2: NATS JetStream (fail-closed)\nOCSF schema · NIST 800-53 mapped"]
    end

    UI -->|"HTTPS\n(all requests)"| MW
    MW -->|"OIDC token\nvalidation"| KC
    MW -->|"policy query\ndata.authz.allow"| OPA
    MW -->|"authenticated +\nauthorized request"| API
    API -->|"Drizzle ORM\nSQL over TLS"| PG
    API -->|"git clone · tag\nAPI calls (HTTP)"| GIT
    API -->|"enqueue\ndeployment job"| GW
    API -->|"audit.emit()\nHTTP POST"| SINK
    GW -->|"dispatch\njob payload"| EXEC
    EXEC -->|"provision resources\nOpenTofu apply"| K3S
    EXEC -->|"resolve secret_ref\n(V1)"| BAOREF
    EXEC -->|"audit.emit()\nHTTP POST"| SINK
```

---

## Trust Zone Summary

| Zone | Components | Who can call it | Defense-in-depth controls |
|---|---|---|---|
| **Z-UI** | React SPA | End user (browser) | OIDC tokens required for every API call; no direct DB or audit access |
| **Z-API** | Fastify + middleware | Z-UI only | OIDC validation + OPA authorization on every route; Zod schema validation; audit emit required |
| **Z-DB** | PostgreSQL | Z-API only (via Drizzle) | No direct external access; `tenant_id` on all solution tables; Drizzle migration gate |
| **Z-WORKER** | Graphile Worker + sandbox | Z-API (via job queue) | No `shell: true`; restricted env MVP1; K8s Job isolation V1; never stores raw secrets |
| **Z-TARGET** | K3s on EC2 | Z-WORKER only | OpenTofu-provisioned; Helm chart–deployed; NetworkPolicy default-deny |
| **Z-AUDIT** | Audit Sink | Z-API + Z-WORKER only | Append-only; Z-UI cannot write directly (DECISION-0044); OCSF schema enforced |
| **Z-AUTHZ** | Keycloak + OPA | Z-API (middleware) | Keycloak OIDC validates identity; OPA enforces policy; every auth decision logged |
| **Z-LIBRARY** | Gitea | Z-API | Branch protection enforced; no force-push; all artifacts git-SHA pinned |
| **Z-SECRETS** | OpenBao (V1) | Z-WORKER only | `secret_ref` pointers in DB; raw values never materialized in DB or logs |

---

## Interface Table

| From | To | Interface | Protocol | Notes |
|---|---|---|---|---|
| Z-UI | Z-API | REST API | HTTPS | All routes; OIDC Bearer token required |
| Z-API | Keycloak | Token validation | OIDC / JWKS | Every authenticated request; fail-closed |
| Z-API | OPA | Policy query | HTTP (`/v1/data`) | Every authorized action; fail-closed (deny on OPA unavailable) |
| Z-API | Z-DB | ORM queries | SQL over TCP | Drizzle; `tenant_id` scoping on solution tables |
| Z-API | Gitea | Repo operations | HTTP (Gitea API) | git clone, tag, webhook receipt |
| Z-API | Graphile Worker | Job enqueue | SQL (shared PG) | Worker reads jobs from same PostgreSQL instance |
| Z-API | Z-AUDIT | Event emit | HTTP POST | `audit.emit()` — S1 fail-open; S2 NATS fail-closed |
| Z-WORKER | Z-TARGET | Provisioning | OpenTofu / K8s API | `shell: false`; restricted env MVP1; K8s Job V1 |
| Z-WORKER | OpenBao | Secret resolution | Vault HTTP API | V1 only; `secret_ref` pointers resolved at deploy time |
| Z-WORKER | Z-AUDIT | Event emit | HTTP POST | Same interface as Z-API |

---

## Slide Narrative (Engineering Deck)

### Stack Choices Worth Talking About

**Fastify 5 over Express** — schema-driven serialization, native TypeScript generics on route types, plugin lifecycle maps cleanly to middleware concerns.

**Drizzle over Prisma** — SQL-first, no code generation step, migration files are plain SQL that the `migration-reviewer` can audit. Type safety without a hidden ORM runtime.

**React Flow 12** — canvas graph manipulation library for the solution topology editor. Handles drag-connect-pin workflow natively.

**OPA as the authorization engine** — policy-as-code, Rego, version-controlled alongside the application. Every `authz.can()` call is logged. Policy decisions are auditable.

**Graphile Worker over BullMQ / SQS** — Postgres-backed job queue; no additional infrastructure dependency at MVP1. Deployment jobs are durable, inspectable, and transactional with the main DB.

### The Zero Trust Decisions Made Early

Every API request passes through two gates before touching data: Keycloak (who are you?) and OPA (are you allowed to do this?). These aren't future-phase plans — they're in the `docker-compose.yml` from day one (DECISION-0041). The audit trail is OCSF-aligned and NIST 800-53–mapped, making the compliance story a byproduct of normal operation.

### What's Interesting to Build

- **Solution deployment wizard** — pre-flight validation of declared external dependencies before a deploy starts
- **Git-SHA pinning model** — solutions pin every referenced node and adapter at a specific commit; deployment receipts are immutable snapshots of exactly what was deployed
- **Execution sandbox graduation** — MVP1 uses a restricted subprocess model; V1 graduates to K8s Jobs with full namespace isolation. The `ExecutionWorker` interface abstracts this completely.
- **Reversal tier model** — nodes/adapters declare their teardown capability (`clean` / `partial` / `manual`), and the deployment receipt records what can be automatically reversed
- **OCSF audit trail** — every deployment, auth event, secret read, and schema migration produces a structured, schema-validated audit event

---

## Key Talking Points (30-second version)

> "FUSION's backend is Fastify 5 + Drizzle on Node.js 22. The architecture is organized around trust zones — Z-UI talks to Z-API, Z-API talks to the DB and dispatches jobs, workers execute deployments in sandboxed environments. Keycloak and OPA sit in the critical path of every request. Everything writes to an append-only OCSF audit trail. It's a clean, Zero Trust-from-day-one architecture on a modern TypeScript stack."
