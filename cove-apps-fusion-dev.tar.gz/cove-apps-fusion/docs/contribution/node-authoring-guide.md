# Node Authoring Guide

> **WIP STUB — expand at first node authoring sprint.** Created per DECISION-0042.
> The structure below is authoritative for node authors even at Stage 1.

## What is a Node?

A FUSION node is a reusable, deployable infrastructure component defined by a
`definition.yaml` in a directory under `fusion-nodes/<node-kind>/`. See `docs/domain.md`
for the full vocabulary.

## Required Files

```
fusion-nodes/<node-kind>/
├── definition.yaml          # validated against schemas/node.schema.json
├── README.md                # purpose, inputs, outputs, teardown notes
├── main.tf                  # OpenTofu resource definitions
├── ansible/
│   ├── pre-check.yml        # pre-flight assertions
│   ├── main.yml             # configuration tasks
│   └── verify.yml           # post-deploy verification
└── tests/
    └── definition.test.ts   # schema validation test (make validate-definitions)
```

## Required Fields in `definition.yaml`

| Field | Type | Notes |
|---|---|---|
| `kind` | `"node"` | literal |
| `name` | kebab-case string | must match directory name |
| `version` | semver | `MAJOR.MINOR.PATCH` |
| `variables_schema` | object | declares configurable inputs |
| `valid_connections` | string[] | node kinds this node can connect to |
| `criticality` | `critical_path` \| `non_critical` | drives publication gate |
| `teardown_capability` | `clean` \| `partial` \| `manual` | DECISION-0022; required |
| `teardown_procedure` | string | human-readable; required when `teardown_capability` is `manual` |

## Teardown Capability

Nodes MUST declare their teardown tier (DECISION-0022):

- **`clean`** — all provisioned resources are destroyed automatically (`terraform destroy` succeeds fully)
- **`partial`** — automated teardown removes most resources; operator must remove remnants manually
- **`manual`** — no automated teardown; full operator procedure required

Nodes with `manual` require elevated publish permission (see `docs/domain.md §6.4`).

## Schema Validation

Run `make validate-definitions` before opening a PR. The CI gate fails on any
`definition.yaml` that does not satisfy `schemas/node.schema.json`.

## TODO (expand at first node sprint)

- [ ] Document the `variables_schema` type system
- [ ] Add example `definition.yaml` for a real node
- [ ] Document the publish / promote workflow
- [ ] Document the pin-monitoring integration (DECISION-0013)
