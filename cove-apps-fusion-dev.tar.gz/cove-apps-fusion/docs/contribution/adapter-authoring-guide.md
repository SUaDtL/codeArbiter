# Adapter Authoring Guide

> **WIP STUB — expand at first node/adapter authoring sprint.** Created per DECISION-0042.
> The structure below is authoritative for adapter authors even at Stage 1.

## What is an Adapter?

A FUSION adapter defines the connection contract between two node kinds. It lives under
`fusion-adapters/<source-type>--<target-type>/` and is identified by the `<source>--<target>`
naming convention. See `docs/domain.md` for the full vocabulary.

## Required Files

```
fusion-adapters/<source-type>--<target-type>/
├── definition.yaml          # validated against schemas/adapter.schema.json
├── README.md                # what this adapter does, protocol, teardown notes
└── tests/
    └── definition.test.ts   # schema validation test (make validate-definitions)
```

## Required Fields in `definition.yaml`

| Field | Type | Notes |
|---|---|---|
| `kind` | `"adapter"` | literal |
| `name` | `<source>--<target>` | must match directory name |
| `version` | semver | `MAJOR.MINOR.PATCH` |
| `source_type` | kebab-case string | matches a node kind in `fusion-nodes/` |
| `target_type` | kebab-case string | matches a node kind in `fusion-nodes/` |
| `variables_schema` | object | declares configurable inputs |
| `priority_tier` | `1` \| `2` \| `3` | 1 = primary; 2 = alternate; 3 = fallback |
| `criticality` | `critical_path` \| `non_critical` | DECISION-0023 |
| `teardown_capability` | `clean` \| `partial` \| `manual` | DECISION-0023; required |

## adapter_kind Deferral

The `adapter_kind` enum is intentionally deferred until at least three real adapter
implementations exist (DECISION-0023). Do not add an `adapter_kind` field to
`definition.yaml` until that decision resolves.

## Schema Validation

Run `make validate-definitions` before opening a PR. The CI gate fails on any
`definition.yaml` that does not satisfy `schemas/adapter.schema.json`.

## TODO (expand at first adapter sprint)

- [ ] Document the `variables_schema` type system (shared with node guide)
- [ ] Add example `definition.yaml` for a real adapter
- [ ] Define the `adapter_kind` enum after three real examples exist (DECISION-0023 trigger)
- [ ] Document the pin-monitoring integration for adapter SHAs (DECISION-0013)
