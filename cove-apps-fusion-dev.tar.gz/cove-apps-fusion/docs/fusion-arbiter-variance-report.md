# FUSION Arbiter — Variance Report

> **ARBITER WORKING FILE** — Produced and rebuilt by the `/fusion-arbiter` skill on each
> scan. Not authoritative project documentation. For architecture decisions, cite
> `docs/fusion-arbiter-decisions.md` instead. Do not use this file as evidence in
> downstream design work.

**Generated:** 2026-05-08 (session continuation — Areas 6–12)
**Stage 3 deliverable** — overwritten on every full scan.
**Source evidence:** `docs/fusion-arbiter-evidence.md` (rebuilt 2026-05-08 against git HEAD).
**Prior decisions:** DECISION-0001 through DECISION-0029 (Areas 1–5 fully resolved; DECISION-0029 = bulk hash recalibration).
**Remaining variance count:** ~24 entries across Areas 6–12.
**Presentation order:** REPO → DEPLOY → CI → COMPLIANCE → DOCS → ARTIFACT-SILENT → SAME-LEVEL CONFLICTS.

SMARTS framework constraints applied per `references/smarts-framework.md`: cells start with `Strong | Adequate | Weak | Indifferent`, ≤25 words each, no hedging adverbs. Recommendation strength is `strong | moderate | tied`.

---

# AREA 6 — REPO

## Variance: REPO.GITEA.CLUSTER (ORG + NODES + ADAPTERS + POLICIES)

**Status:** scaffold-silent (clustered — all four share identical root cause and resolution path)

**Categories covered:** `REPO.GITEA.ORG`, `REPO.GITEA.NODES`, `REPO.GITEA.ADAPTERS`, `REPO.GITEA.POLICIES`

**Artifact position (Doc 1 §3.7):**
> `FUSION_ORG` organization in Gitea; `fusion-nodes`, `fusion-adapters`, and `fusion-policies` repos provisioned under it.

**Scaffold position:**
> None of these exist. `terraform/main.tf` declares the AWS provider but zero Gitea provisioning resources. No IaC scripts, no `gitea-cli` calls, no `docker-compose.yml` Gitea bootstrap.

**Why this matters:**
Without these repos, no nodes, adapters, or OPA policies can be version-controlled in Gitea. The git-SHA pinning model (STATE.GITSHA-PINNING, resolved as DECISION-0013) has no backing store. The entire solution lifecycle depends on this infrastructure.

**Options for resolution:**
1. **Adopt artifact position** — add Gitea org + repo provisioning to `docker-compose.yml` (dev) and Terraform/Helm (prod); tag as MVP1.INFRA sprint work
2. **Adopt scaffold position** — not viable; no scaffold position exists to adopt
3. **Defer with reason** — record as known pre-MVP1 gap; ticket in backlog; no immediate scaffold change required; accept variance until Gitea infra sprint

**SMARTS analysis:**

| Lens | Adopt artifact (provision now) | Defer (ticket + accept gap) |
|---|---|---|
| Scalable | Strong. Gitea repos are the foundation; every sprint after this needs them. | Adequate. Defer is safe while no nodes/adapters are authored. |
| Maintainable | Strong. Early provisioning keeps IaC coherent with intent from the start. | Adequate. Single ticket is lightweight. |
| Available | Indifferent. Dev-only gap at Stage 1. | Indifferent. |
| Reliable | Adequate. Compose + IaC provisioning is low-risk. | Adequate. No reliability impact while unused. |
| Testable | Adequate. Smoke test against `docker-compose up` confirms org/repo creation. | Weak. Gap is invisible until someone tries to author a node. |
| Securable | Adequate. Gitea bootstrap must set branch protection and access tokens — better done deliberately. | Adequate. No nodes = no secrets at risk yet. |

**Non-SMARTS consideration:** Doc 2 Phase 1 tasks include Gitea bootstrap. This variance is expected and consistent with build sequencing — not a design disagreement. Defer is the pragmatic choice at Stage 1.

**Recommendation:** Defer. **Strength: moderate.** No nodes or adapters exist yet; provisioning Gitea repos now is unblocked scaffolding work but not urgent until the first node authoring sprint. Record as a pre-MVP1 BLOCKS_S2 item.

**Awaiting user decision.**

---

## Variance: REPO.GITEA.SCHEMAS

**Status:** divergent

**Artifact position (Doc 1 §3.7):**
> `fusion-schemas` — separate Gitea repo housing OCSF and JSON Schema definitions, under `FUSION_ORG`.

**Scaffold position (`schemas/` in monorepo):**
> `schemas/node.schema.json`, `schemas/adapter.schema.json`, `schemas/audit-event.schema.json` — all in the monorepo root. No separate `fusion-schemas` Gitea repo.

**Why this matters:**
If schemas live in the monorepo, they are versioned alongside application code and cannot be pinned independently. The artifact model assumes external consumers (nodes, adapters, solutions in other repos) can reference a stable schema tag without coupling to the core app version. Colocating schemas in the monorepo creates implicit version coupling and breaks the separation the artifact expects.

**Options for resolution:**
1. **Adopt artifact position** — migrate `schemas/` to a standalone `fusion-schemas` Gitea repo; reference from monorepo via version pin or git submodule
2. **Adopt scaffold position** — keep schemas in monorepo; accept that schema versioning is coupled to app versioning; document the coupling
3. **Hybrid** — keep schemas in monorepo for MVP1; add a Gitea `fusion-schemas` mirror repo on export; promote to primary at V1 when external consumers exist
4. **Defer with reason** — no external consumers exist at Stage 1; colocated schemas are sufficient; revisit at Stage 2 promotion

**SMARTS analysis:**

| Lens | Adopt artifact (separate repo) | Adopt scaffold (monorepo) | Hybrid / Defer |
|---|---|---|---|
| Scalable | Strong. Separate repo allows independent versioning when V1 has multiple solution repos. | Weak. Coupling grows with every solution repo added. | Strong. Defers cost while preserving upgrade path. |
| Maintainable | Adequate. Extra repo adds sync overhead at Stage 1. | Strong. Single repo is simplest. | Strong. MVP1 stays simple; migration deferred to a clear trigger. |
| Available | Indifferent. No availability impact. | Indifferent. | Indifferent. |
| Reliable | Adequate. Schema-only repo reduces blast radius of app changes. | Adequate. Monorepo atomic commits keep schema + code in sync. | Adequate. |
| Testable | Adequate. CI can validate schema repo on its own cadence. | Strong. Schemas validated inline with app CI. | Adequate. |
| Securable | Indifferent. Schemas are non-secret. | Indifferent. | Indifferent. |

**Non-SMARTS consideration:** At Stage 1 there are zero external consumers of these schemas outside the monorepo. The cost of maintaining a separate repo now is pure overhead with no current beneficiary. The MOSA evolvability hedge (feedback memory) says: preserve the upgrade path cheaply.

**Recommendation:** Hybrid/Defer. **Strength: moderate.** Keep schemas in monorepo for MVP1. Record the migration trigger explicitly: "when the first `solution-*` repo in a separate Gitea org needs to reference schemas." Add a `# MIGRATE-TO-fusion-schemas` comment to `schemas/README.md`.

**Awaiting user decision.**

---

## Variance: REPO.BRANCH-PROTECTION

**Status:** divergent

**Artifact position (Doc 1 §3.7):**
> No force push to main, PR-only merges — enforced at Gitea repo level via branch protection rules.

**Scaffold position:**
> `CODEOWNERS` enforces PR-based review culturally. `CLAUDE.md §3` has a hard rule against force-push. No Gitea API configuration (no `gitea-cli` scripts, no Terraform Gitea provider resources) that sets branch protection at the API level.

**Why this matters:**
Cultural enforcement (CODEOWNERS + CLAUDE.md) is bypassed by anyone with direct push access. API-level branch protection in Gitea is the only reliable enforcement. This is a CM-3 control gap — without it, the branch protection policy cannot be audited or demonstrated to an assessor.

**Options for resolution:**
1. **Adopt artifact position** — add Gitea branch protection API calls to bootstrap scripts (Terraform Gitea provider or `gitea-cli`); enforce no-force-push + require-PR at API level
2. **Adopt scaffold position** — document cultural enforcement as sufficient at Stage 1; accept the CM-3 gap until Gitea is provisioned
3. **Defer with reason** — Gitea is not yet running (REPO.GITEA.CLUSTER unresolved); branch protection cannot be configured until Gitea exists; defer to same sprint as Gitea provisioning

**SMARTS analysis:**

| Lens | Adopt artifact (API enforcement) | Adopt scaffold (cultural only) | Defer to Gitea sprint |
|---|---|---|---|
| Scalable | Strong. API enforcement scales to all contributors automatically. | Weak. Cultural controls fail as team grows. | Strong. Bundles naturally with Gitea provisioning work. |
| Maintainable | Adequate. Gitea provider config is low maintenance. | Weak. Policy drift is silent. | Strong. No new work item; tagged onto existing. |
| Available | Indifferent. | Indifferent. | Indifferent. |
| Reliable | Strong. API-level = cannot be bypassed without intentional admin override. | Weak. Any dev with push access can bypass. | Adequate. Defers risk but bounds it. |
| Testable | Adequate. Integration test can assert API returns 403 on force-push. | Weak. No automated verification possible. | Adequate. |
| Securable | Strong. CM-3 satisfied; demonstrable to assessor. | Weak. CM-3 gap; fails audit trail requirements. | Adequate. Risk bounded to Stage 1 team-only period. |

**Recommendation:** Defer to Gitea provisioning sprint. **Strength: strong.** API enforcement is clearly correct long-term; defer is appropriate only because Gitea doesn't exist yet. This MUST be bundled with the Gitea bootstrap work, not left indefinitely open.

**Awaiting user decision.**

---

# AREA 7 — DEPLOY

## Variance: DEPLOY.HELM-CHART + DEPLOY.K3S-HOSTING (clustered)

**Status:** scaffold-silent (both)

**Artifact position (Doc 1 §5 LOCKED, Doc 2 Phase 1):**
> Single Helm chart bundles FUSION; deployed to K3s on EC2 in Cove.GDIT for MVP1. `helm/fusion/` directory expected.

**Scaffold position:**
> No `helm/` directory. No `Chart.yaml`. `terraform/main.tf` has AWS provider + region variable but zero compute resources. Consistent with pre-deployment Phase 1 tasks not yet started.

**Why this matters:**
Helm chart and K3s hosting are the delivery vehicle for MVP1. Without them, FUSION cannot be demonstrated end-to-end. These are expected gaps at Stage 1 but need explicit acknowledgment as BLOCKS_S2 items.

**Options for resolution:**
1. **Adopt artifact position** — begin Helm chart skeleton and Terraform K3s module as next sprint work; scope is explicit in Doc 2 Phase 1
2. **Defer with reason** — record as pre-MVP1 BLOCKS_S2; no Helm/IaC work until app scaffold is green
3. **N/A** — no scaffold position to adopt

**SMARTS analysis:**

| Lens | Adopt artifact (begin Helm sprint) | Defer (backlog ticket) |
|---|---|---|
| Scalable | Strong. Helm templating is the right unit at V1+. | Adequate. Deferral is safe while app is scaffold-only. |
| Maintainable | Adequate. Helm adds chart maintenance burden. | Strong. No chart to maintain. |
| Available | Indifferent. | Indifferent. |
| Reliable | Adequate. Helm + K3s is a known stack. | Adequate. |
| Testable | Adequate. `helm lint` + `helm template` are quick smoke tests. | Weak. No testable deployment until chart exists. |
| Securable | Adequate. Helm chart enables RBAC, NetworkPolicy, resource limits. | Weak. Deployment posture undefined until chart exists. |

**Recommendation:** Defer. **Strength: moderate.** These are sequenced correctly in Doc 2 Phase 1 — Helm sprint follows app scaffold completion. Record as BLOCKS_S2 pre-deployment work items.

**Awaiting user decision.**

---

## Variance: DEPLOY.SUBPROCESS-SANDBOX

**Status:** scaffold-silent

**Artifact position (Doc 1 §3.3, §6.1):**
> Worker execution runs in a restricted environment for MVP1 (restricted env with no `shell: true`); graduated to K8s Job at V1. No subprocess calls with `shell: true` ever.

**Scaffold position:**
> No worker execution code exists. `CLAUDE.md §3` has a hard rule against `shell: true`. No subprocess sandbox implementation — consistent with no workers built yet.

**Why this matters:**
The sandbox model determines security posture for every FUSION solution deployment. Getting the wrong model at MVP1 creates technical debt that's hard to undo (especially if solutions couple to subprocess behavior). The CLAUDE.md hard rule covers the worst case; the artifact's staged sandbox model is a design decision that needs to be captured before first worker implementation.

**Options for resolution:**
1. **Adopt artifact position** — document the staged model (restricted env → K8s Job) in an ADR before first worker implementation; no code change needed now
2. **Defer with reason** — no workers yet; defer until worker implementation sprint; add `[CONFIRM]` marker in docs

**SMARTS analysis:**

| Lens | Adopt artifact (ADR now) | Defer (accept gap) |
|---|---|---|
| Scalable | Strong. Early ADR shapes all worker implementations. | Weak. First implementer makes ad-hoc choice. |
| Maintainable | Strong. Decision is searchable and cited at implementation time. | Weak. Decision gets buried in commit messages. |
| Available | Indifferent. | Indifferent. |
| Reliable | Adequate. | Adequate. |
| Testable | Indifferent. ADR alone has no test impact. | Indifferent. |
| Securable | Strong. SI-10 compliance (no shell: true) is explicit policy before code exists. | Adequate. CLAUDE.md hard rule covers worst case. |

**Recommendation:** Adopt artifact position (ADR only). **Strength: moderate.** Write a brief ADR capturing the staged sandbox model and the `shell: true` prohibition before first worker implementation. Zero scaffold change needed now.

**Awaiting user decision.**

---

# AREA 8 — CI

## Variance: CI.HUSKY-PRECOMMIT + CI.LINT-STAGED (clustered)

**Status:** divergent (both)

**Artifact position (Doc 2 Phase 1, Doc 3 MVP1.CI.001–002):**
> Pre-commit hooks via Husky (npm-based); staged-file linting via lint-staged (npm-based).

**Scaffold position:**
> `.pre-commit-config.yaml` exists — Python-style pre-commit framework (not Husky). `backend/package.json` has no `husky` or `lint-staged` dependencies. `Makefile` has `install-hooks` target but Husky binary absent.

**Why this matters:**
The pre-commit framework achieves the same goal (run checks on staged files before commit) as Husky + lint-staged, but through a different mechanism. The pre-commit framework is language-agnostic and runs in its own virtualenv; Husky + lint-staged are npm-native and integrate with `package.json`. The two toolchains cannot coexist cleanly — choosing one defines the developer onboarding story.

**Options for resolution:**
1. **Adopt artifact position** — remove `.pre-commit-config.yaml`; install Husky + lint-staged as devDependencies; wire `prepare` script in `package.json`
2. **Adopt scaffold position** — keep `.pre-commit-config.yaml`; update Doc 2/Doc 3 references to reflect pre-commit framework as the chosen tool; remove Husky references from `Makefile`
3. **Hybrid** — keep both: pre-commit for Python-style hooks, Husky for npm-native hooks — adds complexity with no clear benefit

**SMARTS analysis:**

| Lens | Adopt artifact (Husky + lint-staged) | Adopt scaffold (pre-commit framework) |
|---|---|---|
| Scalable | Adequate. npm ecosystem; scales naturally with JS monorepo. | Adequate. Language-agnostic; scales to polyglot if needed. |
| Maintainable | Strong. Single package.json entry; `npm install` sets up dev env. | Adequate. Extra virtualenv step; separate config file. |
| Available | Indifferent. | Indifferent. |
| Reliable | Adequate. Husky is widely used; occasional node_modules issues. | Adequate. pre-commit is stable but requires Python installed. |
| Testable | Strong. Husky hooks run in same Node context; easy to test. | Adequate. Hooks run in isolation; harder to debug. |
| Securable | Adequate. Both enforce same checks; security impact identical. | Adequate. |

**Non-SMARTS consideration:** The FUSION stack is pure TypeScript/Node.js + minimal Python tooling. A Node-native hook system (Husky) keeps the "one ecosystem" principle — `npm install` configures everything. The pre-commit framework adds Python as a dev dependency, which is a footgun for contributors who don't have Python on PATH.

**Recommendation:** Adopt artifact position (Husky + lint-staged). **Strength: moderate.** The project is JS-native; Husky requires zero extra runtime dependencies. Remove `.pre-commit-config.yaml` and wire Husky + lint-staged in `package.json`.

**Awaiting user decision.**

---

## Variance: CI.DRIZZLE-MIGRATIONS

**Status:** scaffold-silent

**Artifact position (Doc 3 MVP1.CI.004):**
> Migration check in CI — verify that the schema and generated migrations are in sync; block PRs that modify schema without generating migrations.

**Scaffold position:**
> `backend/drizzle/` directory ABSENT. No `drizzle-kit generate` or `drizzle-kit check` in CI pipeline. Drizzle schema exists at `backend/src/db/schema.ts` but migrations have never been generated.

**Why this matters:**
Without migrations, the database schema exists only as Drizzle ORM declarations with no upgrade path. Any new deployment must `drizzle-kit push` (destructive) rather than `drizzle-kit migrate` (safe). The CI gate cannot be added until at least one migration exists.

**Options for resolution:**
1. **Adopt artifact position** — run `drizzle-kit generate` now against the current schema; commit the initial migration; add CI gate
2. **Defer with reason** — schema is still in flux during Stage 1; generate first migration when schema stabilizes; accept gap

**SMARTS analysis:**

| Lens | Generate now (adopt artifact) | Defer until schema stable |
|---|---|---|
| Scalable | Strong. First migration establishes the pattern all future migrations follow. | Adequate. Single migration later is just as valid. |
| Maintainable | Strong. Migration history is the source of truth for DB state. | Weak. `drizzle-kit push` history is lossy. |
| Available | Indifferent. | Indifferent. |
| Reliable | Strong. Repeatable DB setup from migrations; no `push` surprises. | Weak. `push` in CI can silently drop and recreate tables. |
| Testable | Strong. CI gate blocks schema-without-migration PRs. | Weak. No gate; schema drift silent until deploy. |
| Securable | Adequate. Migration review is a CM-3 control point. | Weak. Schema changes bypass review without a migration gate. |

**Recommendation:** Adopt artifact position. **Strength: strong.** Generate the initial migration now. Schema flux is a weak reason to defer — migrations are designed to handle schema evolution. The first migration commit triggers the `migration-reviewer` subagent (per CLAUDE.md §5) and establishes the CI gate.

**Awaiting user decision.**

---

## Variance: CI.ZOD-ROUTE-COVERAGE

**Status:** scaffold-silent

**Note:** DECISION-0021 (2026-05-07) already committed to adopting the artifact position (add CI gate for Zod route coverage). This variance is documented for completeness. No new decision required unless the user wishes to revisit DECISION-0021.

**Current state:** F-019 still in CHANGELOG `[Unreleased]`. Gate not yet implemented. Consistent with "adopt and implement in next sprint" resolution from DECISION-0021.

---

## Variance: CI.OCSF-AUDIT-VALIDATION

**Status:** scaffold-silent

**Artifact position (Doc 1 §3.8):**
> CI hook validates audit events emitted at runtime against the OCSF JSON Schema; blocks PRs that emit malformed events.

**Scaffold position:**
> `.gitea/workflows/ci-linux.yml` runs `make validate-definitions` (checks node/adapter YAML). No step validates audit events against `schemas/audit-event.schema.json`. The schema exists; the CI gate does not.

**Why this matters:**
OCSF audit event validation is a SCHEMA.AUDIT-EVENT compliance check (linked to ADR-0003 / NIST 800-53 AU-9). Without a CI gate, audit events can drift from schema silently — an ATO risk. The schema already exists; only the CI step is missing.

**Options for resolution:**
1. **Adopt artifact position** — add `make validate-audit-events` target and wire it into `ci-linux.yml`; the validator runs against emitted events in test output
2. **Defer with reason** — no audit events are being emitted in production yet (Stage 1); defer until first real audit emit
3. **Hybrid** — add schema validation for the `audit-event.schema.json` file itself (schema-on-schema) now; defer runtime event validation to Stage 2

**SMARTS analysis:**

| Lens | Add gate now | Defer | Hybrid (schema validation only) |
|---|---|---|---|
| Scalable | Strong. CI gate covers all future audit emits automatically. | Weak. Technical debt accumulates. | Adequate. Partial coverage is better than none. |
| Maintainable | Strong. Gate enforces schema discipline from day one. | Weak. Schema drift unchecked. | Adequate. |
| Available | Indifferent. | Indifferent. | Indifferent. |
| Reliable | Strong. No silent schema drift. | Weak. | Adequate. |
| Testable | Strong. CI is the test. | Weak. | Adequate. |
| Securable | Strong. AU-9 control satisfied; demonstrable. | Weak. AU-9 gap visible to assessor. | Adequate. |

**Recommendation:** Adopt artifact position. **Strength: moderate.** The schema exists; adding the CI gate is low effort. AU-9 compliance argues for sooner rather than later.

**Awaiting user decision.**

---

## Variance: CI.SEMGREP-AUDIT-EMIT

**Status:** scaffold-silent

**Artifact position (Doc 1 §3.8, CLAUDE.md §5):**
> Semgrep rule enforces that every security-relevant action calls `audit.emit()`. Blocks PRs that add auditable actions without the emit call.

**Scaffold position:**
> `.semgrep/` has `bare-fetch.yml` and `shell-injection.yml`. No audit-emit enforcement rule. CI pipeline runs Semgrep (`sast` job) but only with existing rules. The `audit-emitter` subagent (CLAUDE.md §5) is manual; no automated CI gate.

**Why this matters:**
Without a Semgrep rule, an agent or developer can add a deployment route, auth check, or secret read without an audit emit — and CI passes. The rule is the only scalable enforcement mechanism. At ATO time, AU-2/AU-3 requires demonstrable enforcement of audit coverage, not just manual convention.

**Options for resolution:**
1. **Adopt artifact position** — write `.semgrep/audit-emit.yml` rule; add to existing Semgrep CI job
2. **Defer with reason** — Semgrep rules require tuning; premature rule causes false positives; defer to Stage 2
3. **Hybrid** — add a pattern-based rule now covering the highest-risk entry points (deployments, auth, secret reads); refine at Stage 2

**SMARTS analysis:**

| Lens | Add Semgrep rule now | Defer | Hybrid (targeted rule) |
|---|---|---|---|
| Scalable | Strong. All future auditable actions caught automatically. | Weak. Manual convention breaks under scale. | Strong. Covers highest-risk paths; tunable. |
| Maintainable | Adequate. Rule needs maintenance as emit API evolves. | Strong. No extra maintenance. | Adequate. Smaller surface to maintain. |
| Available | Indifferent. | Indifferent. | Indifferent. |
| Reliable | Strong. False negatives caught at CI, not audit review. | Weak. False negatives invisible. | Adequate. |
| Testable | Strong. Semgrep rules have their own test framework. | Weak. | Adequate. |
| Securable | Strong. AU-2/AU-3 demonstrable; reduces assessor risk. | Weak. AU-2 gap. | Adequate. Partial AU-2 coverage. |

**Recommendation:** Hybrid (targeted rule). **Strength: moderate.** A broad rule at Stage 1 risks false positives that erode CI trust. A targeted rule covering `routes/deployments.ts`, `routes/auth.ts`, and `lib/secrets.ts` (highest-risk) provides real coverage with minimal false-positive risk.

**Awaiting user decision.**

---

# AREA 9 — COMPLIANCE

## Variance: COMPLIANCE.FIPS-CAPABLE

**Status:** divergent

**Artifact position (Doc 1 §4, ADR-0001 SC-13):**
> FIPS-compatible builds where applicable; server MUST assert FIPS mode at startup to fail fast if the system crypto provider is not FIPS-enabled.

**Scaffold position (`backend/src/main.ts`, `ci-linux.yml`):**
> CI has `fips-check` job running `make fips-check` (validates `node -e "require('crypto').getFips()"` and OpenSSL FIPS provider). `backend/src/main.ts` does NOT include a FIPS startup assertion — the server boots without checking whether it's running on a FIPS-capable system.

**Why this matters:**
A FIPS-capable build that doesn't assert FIPS mode at boot silently runs in non-FIPS mode on non-FIPS hosts. CI validation only catches this at pipeline time, not at deployment time. An adversarially misconfigured K3s node could run the server in non-FIPS mode without any indication. SC-13 requires both capability AND enforcement.

**Options for resolution:**
1. **Adopt artifact position** — add FIPS startup assertion to `backend/src/main.ts` (fail-fast if `require('crypto').getFips() !== 1` in non-dev environments)
2. **Adopt scaffold position** — rely on CI gate alone; document that FIPS is a build-time check, not runtime
3. **Hybrid** — log a warning in dev if FIPS is not active; throw in production/staging

**SMARTS analysis:**

| Lens | Runtime assertion (artifact) | CI-only (scaffold) | Hybrid (warn/throw by env) |
|---|---|---|---|
| Scalable | Strong. Assertion runs on every deployment host automatically. | Weak. CI only catches misconfig on the CI node. | Strong. Matches deployment reality. |
| Maintainable | Strong. Single assert in `main.ts`; easy to audit. | Adequate. | Adequate. |
| Available | Adequate. Hard fail in prod prevents starting on non-FIPS host — correct behavior. | Weak. Non-FIPS deployment goes unnoticed. | Strong. Dev unblocked; prod protected. |
| Reliable | Strong. Fail-fast is more reliable than silent mismatch. | Weak. | Strong. |
| Testable | Strong. Test by mocking `getFips()` return. | Weak. No test possible. | Strong. |
| Securable | Strong. SC-13 satisfied; demonstrable at ATO. | Weak. SC-13 gap without runtime enforcement. | Strong. |

**Recommendation:** Hybrid. **Strength: strong.** Add `if (process.env.NODE_ENV !== 'development' && require('crypto').getFips() !== 1) { throw new Error('FIPS mode required') }` to `main.ts`. Dev machines often lack FIPS-enabled OpenSSL; hard-failing there blocks developers unnecessarily.

**Awaiting user decision.**

---

## Variance: COMPLIANCE.STIG-IMAGES

**Status:** scaffold-silent

**Artifact position (Doc 1 §4):**
> STIG'd base images for nodes.

**Scaffold position:**
> No `fusion-nodes/` directory. No Dockerfile. Consistent with no nodes authored yet.

**Why this matters:**
STIG image requirement is a compliance posture decision, not an implementation detail. The decision about WHICH STIG'd base image to use (UBI9, Iron Bank, custom hardened) should be made before the first node is authored, since it constrains the Dockerfile base layer for all future nodes.

**Options for resolution:**
1. **Adopt artifact position** — select a STIG base image (e.g., IronBank UBI9 or Registry1) and document it in an ADR before first node is authored
2. **Defer with reason** — no nodes exist; defer base image selection to node authoring sprint
3. **Both-silent treatment** — consistent with Stage 1 deferral; record as BLOCKS_S2 item

**Recommendation:** Defer. **Strength: moderate.** No nodes exist; base image selection has no immediate implementation impact. Record as a required pre-work item before the first node authoring sprint. Tag as BLOCKS_S2.

**Awaiting user decision.**

---

## Variance: COMPLIANCE.ZERO-TRUST

**Status:** divergent

**Artifact position (Doc 1 §4, §6, ADR-0001):**
> Keycloak + OPA pattern fully wired; audit trail on every action; ZT metadata fields in every audit event; all trust zone transitions enforced at runtime.

**Scaffold position:**
> Schema and ADR level: `concur` — ZT fields exist in audit schema, Keycloak + OPA chosen. Runtime level: `divergent` — `docker-compose.yml` has postgres + backend + audit-sink but is MISSING Keycloak and OPA services. No running ZT enforcement at dev time.

**Why this matters:**
Zero Trust is an architectural posture, not just a schema choice. Without Keycloak and OPA running in `docker-compose.yml`, developers cannot test ZT enforcement locally. Auth middleware bypasses are the natural result (`DEV_AUTH_BYPASS` flag — see AREA 11). The gap between schema-level intention and runtime wiring is the most common place ZT compliance erodes.

**Options for resolution:**
1. **Adopt artifact position** — add Keycloak and OPA services to `docker-compose.yml`; configure OIDC realm bootstrap; remove DEV_AUTH_BYPASS as default-off
2. **Adopt scaffold position** — accept that dev uses bypass; ZT enforced only in deployed environments
3. **Defer with reason** — Keycloak + OPA setup is non-trivial; defer to dedicated infra sprint; document accepted gap

**SMARTS analysis:**

| Lens | Add to compose (artifact) | Bypass-in-dev (scaffold) | Defer (infra sprint) |
|---|---|---|---|
| Scalable | Strong. Local env mirrors prod; fewer integration surprises. | Weak. Bypass becomes institutional habit. | Adequate. Bundles with Gitea provisioning sprint. |
| Maintainable | Adequate. Compose service config needs maintenance as Keycloak upgrades. | Strong. No extra services to maintain. | Adequate. |
| Available | Adequate. Adds compose startup time. | Strong. Fast dev startup. | Adequate. |
| Reliable | Strong. Dev == prod configuration reduces drift. | Weak. Bypass masks auth middleware bugs. | Adequate. |
| Testable | Strong. Auth tests run against real Keycloak. | Weak. Auth middleware never exercised locally. | Adequate. |
| Securable | Strong. ZT posture verified from day one. | Weak. DEV_AUTH_BYPASS is an attack vector if mis-deployed. | Adequate. Bounded risk while team-only. |

**Recommendation:** Defer to infra sprint. **Strength: moderate.** Keycloak bootstrap config is non-trivial work that should be done once and done right. Bundle with the Gitea provisioning sprint (Area 6 cluster). The DEV_AUTH_BYPASS flag needs a documented policy (see AREA 11, ARTIFACT-SILENT.AUTH-BYPASS-FLAG) — that can be done now independently.

**Awaiting user decision.**

---

# AREA 10 — DOCS

## Variance: DOCS.NODE-AUTHORING-GUIDE + DOCS.ADAPTER-AUTHORING-GUIDE (clustered)

**Status:** scaffold-silent (both)

**Artifact position (Doc 1 §7):**
> Contribution guides for node and adapter authoring — covering schema requirements, CI validation, deployment expectations, and testing obligations.

**Scaffold position:**
> No `docs/contribution/` directory. No authoring guides. `fusion-nodes/` and `fusion-adapters/` directories do not exist.

**Why this matters:**
Without authoring guides, the first person to write a node or adapter must reverse-engineer the requirements from CLAUDE.md, docs/, and schemas/. This creates inconsistency and slows adoption — especially critical at the Stage 1→2 promotion where new contributors join.

**Options for resolution:**
1. **Adopt artifact position** — draft minimal authoring guides (stubs) covering the required sections; flesh out when first node/adapter is authored
2. **Defer with reason** — no nodes or adapters exist; guides can be written alongside first node authoring (docs-as-you-go)
3. **Hybrid** — create guide stubs now with "TODO: flesh out during first node sprint" markers; establishes the structure without requiring full content

**Recommendation:** Hybrid (stubs). **Strength: moderate.** Stub guides now with mandatory sections identified (schema, CI validation, test obligations, ADR references). Flesh out in the first node authoring sprint. This makes the authoring process discoverable without deferring all documentation work.

**Awaiting user decision.**

---

## Variance: DOCS.RUNBOOKS

**Status:** divergent

**Artifact position (Doc 1 §7):**
> Operational runbooks for FUSION deployment — covering deploy, rollback, scale, and incident response.

**Scaffold position:**
> `docs/runbook.md` exists but is a minimal placeholder. Ansible playbooks (`pre-check.yml`, `main.yml`, `verify.yml`) referenced in `CODEOWNERS` do not exist. No deploy/ directory with populated playbooks.

**Why this matters:**
A runbook stub without corresponding playbooks is documentation debt. The gap is expected at Stage 1 but should be tracked — especially because `CODEOWNERS` references paths that don't exist, which creates a false sense of coverage.

**Options for resolution:**
1. **Adopt artifact position** — write the Ansible playbooks and flesh out `runbook.md`
2. **Defer with reason** — no deployment infrastructure exists yet; runbooks can only be written once Helm + K3s + Ansible are in place
3. **Accept gap explicitly** — update `CODEOWNERS` to remove references to non-existent playbook paths; update `runbook.md` with explicit "WIP: pending infra sprint" marker

**Recommendation:** Accept gap explicitly (option 3). **Strength: moderate.** Remove the `CODEOWNERS` references to non-existent paths to eliminate false coverage signals. Add a `WIP: pending infra sprint` marker in `runbook.md`. Defer actual runbook authoring until deployment infrastructure exists.

**Awaiting user decision.**

---

# AREA 11 — ARTIFACT-SILENT

## Variance: ARTIFACT-SILENT.UI-TO-AUDIT-DIRECT-PATH

**Status:** artifact-silent — **SECURITY PRIORITY: HIGHEST**

**Scaffold position (`frontend/src/lib/audit.ts`, `docs/architecture/trust-zones.md`):**
> `frontend/src/lib/audit.ts` emits audit events directly from Z-UI. `docs/architecture/trust-zones.md` explicitly states Z-UI is NOT authorized to write to Z-AUDIT — only Z-API and Z-WORKER feed Z-AUDIT. The trust-zones doc flags this as an "open question for Stage 2 decision."

**Why this matters:**
This is a trust-zone boundary violation. Z-UI is an untrusted browser context. Accepting audit events directly from Z-UI means:
1. A browser compromise can inject false audit events
2. Audit trail integrity cannot be guaranteed (AU-9, AU-10)
3. At ATO time, this is a direct finding that blocks boundary approval
The trust-zones.md "open question" framing understates the severity — this is a documented architectural violation, not an open design question.

**Options for resolution:**
1. **Close the violation** — remove direct audit emit from `frontend/src/lib/audit.ts`; frontend user actions are captured when Z-API receives and processes the request; no separate frontend audit path
2. **Route through Z-API** — frontend sends user-interaction events to a dedicated Z-API endpoint (`POST /audit/frontend`) which validates and re-emits through the trusted audit pipeline; Z-API adds server-side trust fields
3. **Document as accepted risk** — update trust-zones.md to explicitly allow Z-UI→Z-AUDIT with documented risk acceptance and compensating controls; surface to S2 security review

**SMARTS analysis:**

| Lens | Close violation (option 1) | Route via Z-API (option 2) | Accept risk (option 3) |
|---|---|---|---|
| Scalable | Strong. Simplest; no frontend audit maintenance. | Adequate. Adds an endpoint per frontend event type. | Weak. Risk scales with feature count. |
| Maintainable | Strong. No frontend audit API surface to maintain. | Adequate. API endpoint needs maintenance. | Weak. Risk acceptance must be re-reviewed at every promotion. |
| Available | Adequate. Audit events are less complete (no click-stream audit). | Adequate. API must be available for frontend actions to audit. | Adequate. |
| Reliable | Strong. Audit trail integrity uncompromised. | Strong. Trust boundary maintained; validation possible. | Weak. Forged events silently corrupt audit trail. |
| Testable | Strong. Z-API audit tests cover all server-side actions. | Adequate. Z-API endpoint testable independently. | Weak. No test can verify client-side audit integrity. |
| Securable | Strong. AU-9, AU-10 satisfied. ZT boundary intact. | Strong. AU-9 satisfied via Z-API validation before emit. | Weak. AU-9 gap; ATO blocker. |

**Recommendation:** Close the violation (option 1). **Strength: strong.** Frontend user interactions are implicitly audited when Z-API processes the corresponding requests. There is no legitimate need for a separate frontend-direct audit path. Remove `frontend/src/lib/audit.ts` direct emit or redirect to Z-API.

**Awaiting user decision.**

---

## Variance: ARTIFACT-SILENT.AUTH-BYPASS-FLAG

**Status:** artifact-silent

**Scaffold position (`backend/src/middleware/auth.ts`):**
> `DEV_AUTH_BYPASS` environment variable — when set, the auth middleware passes all requests without OIDC validation.

**Why this matters:**
Auth bypass flags are a common source of accidental production exposure. Without a documented policy covering when the flag is permissible, how it is prevented from production use, and what replaces it (e.g., test fixtures), the flag is an uncontrolled risk surface.

**Options for resolution:**
1. **Document policy** — add a comment block in `auth.ts` and an entry in `docs/security-controls.md` specifying: (a) permissible only in `NODE_ENV=development`, (b) CI must assert flag is not set in deployed configs, (c) a test-fixture approach is the preferred alternative for integration tests
2. **Remove the flag** — use test fixtures (mock JWT tokens) instead of bypass; audit middleware tests pass regardless
3. **Defer** — flag is documented enough in code; no additional policy needed at Stage 1

**Recommendation:** Document policy (option 1). **Strength: moderate.** The flag itself is acceptable at Stage 1 — but without a policy, it's a ticking compliance finding. Documenting the boundary takes 10 minutes and prevents an ATO finding.

**Awaiting user decision.**

---

## Variance: ARTIFACT-SILENT.DEPLOYMENT-CLASSIFICATION-FIELD

**Status:** artifact-silent

**Scaffold position (`backend/src/db/schema.ts`):**
> `deployments` table has a `classification` column — no artifact position covers this field.

**Why this matters:**
Classification fields carry data classification implications (NIST 800-53 AC-16, SC-28). A field named `classification` with no artifact backing and no data classification tag (per `docs/data-classification.md`) is a gap that could become an ATO finding.

**Options for resolution:**
1. **Backfill artifact position** — add `classification` to the SCHEMA.SOLUTION-MANIFEST or a new SCHEMA category; tag per `docs/data-classification.md`
2. **Remove the field** — if not needed, remove it to reduce scope
3. **Document inline** — add a comment in schema.ts citing the classification level and relevant NIST control

**Recommendation:** Document inline (option 3) as immediate action; schedule artifact backfill if this field is load-bearing. **Strength: moderate.**

**Awaiting user decision.**

---

# AREA 12 — SAME-LEVEL CONFLICTS

## SLC-1: STACK.AUTH.IDENTITY — Keycloak vs CONFIRM-01

**Status:** RESOLVED by DECISION-0001 (2026-05-07)

DECISION-0001 recorded Keycloak as the locked identity provider. `docs/open-questions.md` CONFIRM-01 predates this decision and should be closed. No new variance — noting for completeness and to flag that CONFIRM-01 should be marked resolved.

**Action recommended (no decision required):** Update `docs/open-questions.md` to close CONFIRM-01 with a reference to DECISION-0001.

---

# END OF VARIANCE REPORT — Areas 6–12
