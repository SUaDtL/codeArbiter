# Build Guide — cove-apps-fusion

## Prerequisites

List everything required before building:

| Requirement | Version | Notes |
|---|---|---|
| Node.js | 22.x LTS | `node --version` |
| npm | >= 10 | bundled with Node.js 22 |
| Ansible | >= 2.15 | `ansible --version` |
| Husky (via npm) | auto-installed | Installed by `npm install` via `prepare` script (DECISION-0035) |
| Docker / Docker Compose | >= 24.x | `docker --version`; required for `make up` |

## Clone and Set Up

~~~bash
# Clone the repo
git clone https://gitea.cove.gdit/cove/cove-apps-fusion.git
cd cove-apps-fusion

# Install dependencies and pre-commit hooks
npm install
make install-hooks

# Copy environment variable template
cp .env.example .env
# Edit .env and fill in real values (never commit .env)
~~~

## Install Dependencies

~~~bash
# Node dependencies (installs both backend and frontend workspaces)
npm install

# Ansible collections (if applicable)
ansible-galaxy collection install -r requirements.yml
~~~

## Build Artifacts

~~~bash
# Describe the primary build command(s) here.
# Example for a Python wheel:
#   python -m build --wheel
#
# Example for an Ansible collection:
#   ansible-galaxy collection build
#
# Example for a tarball:
#   tar czf dist/cove-apps-fusion-$(git describe --tags).tar.gz --exclude='.git' .
~~~

## Run Tests

~~~bash
# Backend tests (Vitest + coverage ≥60%)
make backend-test

# Frontend tests (Vitest + coverage ≥60%)
make frontend-test

# Full CI suite (lint + typecheck + tests + security scans)
make ci
~~~

## Verify Pre-Commit Passes

~~~bash
pre-commit run --all-files
~~~

All hooks should pass before opening a PR.

## Known Build Issues

# YAML linting via ESLint plugins — no separate yamllint installation required


