# FUSION-CORE — PROJECT CONTEXT (LLM CONTEXT-PACK)

> **Navigation note:** This file is an LLM-optimized context blob intended for
> pasting into external prompts. For the canonical architectural overview, see
> `docs/diagrams/ov-1-operational-concept.md` (leadership view) and
> `docs/diagrams/sv-1-system-interfaces.md` (engineering view). Keep this file
> in sync with those diagrams when major architectural decisions are recorded.

> **Purpose.** Token-efficient context blob for pasting into a foreign LLM session (ChatGPT, Gemini, etc.) when leveraging that model's training/perspective on FUSION questions. Optimized for context:token value, not human readability. The repo's `CLAUDE.md` + `docs/` are authoritative — when in doubt, fetch from there.
>
> **Snapshot.** v0.5+ · 2026-05-07 · stage=1 · branch=dev · anchor-commit=`65d3457`

---

## ABBREV

`S1..S4`=stage tag · `ADR`=Architecture Decision Record · `F-NNN`=checkpoint finding · `R-NN`=risk · `CONFIRM-NN`=open question · `Z-*`=trust zone · `OCSF`=Open Cybersecurity Schema Framework · `ECS`=Elastic Common Schema · `MOSA`=Modular Open Systems Approach · `CUI`=Controlled Unclassified Information · `ATO`=Authorization To Operate · `RMF`=Risk Management Framework · `SBOM`=Software Bill of Materials · `DA`=Digital Accelerator · `BSL`=Business Source License · `SSPL`=Server Side Public License · `WORM`=Write Once Read Many · `IRSA`=IAM Roles for Service Accounts · `STIG`=Security Technical Implementation Guide · `POA&M`=Plan of Action & Milestones

---

## IDENTITY

- **Name:** FUSION (repo `fusion-core`).
- **Owner:** GDIT (General Dynamics IT) — defense systems integrator.
- **Maintainer:** Brennon Huff (solo at S1; arch+sec lead).
- **Purpose:** redeployable platform for GDIT Digital Accelerator (DA) solutions. Solves PoC-rot (primary), siloed DA development, late-bound Zero Trust.
- **IS:** deployment platform AND schema/contract that solutions MUST conform to.
- **IS NOT:** O&M tool, drift detector, monitoring system, multi-tenant SaaS. Operational contract ends at deployment-validation.
- **Posture:** Defense-grade. Targets: NIST 800-53 Rev. 5, 800-171 Rev. 3, 800-218, CMMC 2.0, FIPS 140-3, FedRAMP, DISA STIG, SLSA v1.0.
- **Conflict-resolution hierarchy** (CLAUDE.md §0): security/compliance > correctness/integrity > maintainability/reviewability > performance > developer-velocity.

---

## STAGES

Current=`1` (`.fusion/stage`).

| S | Name | Promotion trigger (any one) |
|---|---|---|
| 1 | Prototype | Internal team only; single-node K3s; no external users; no CUI |
| 2 | Internal MVP | First non-team GDIT user · OR · >15k LOC · OR · >5 contributors |
| 3 | Hardened Pilot | Customer-adjacent env · OR · CUI introduced · OR · >25 concurrent users · OR · external assessor named |
| 4 | ATO-Ready Production | ATO submission required · OR · multi-tenant · OR · FedRAMP boundary declared |

Coverage thresholds: S1≥60% · S2≥70% · S3≥85% · S4≥90% (vitest, enforced).
Stage-promotion authority: **CONFIRM-09 (unresolved)**.

---

## DOMAIN VOCABULARY (load-bearing — never redefine)

**Node** — self-contained deployable unit. Dir contract: `fusion-nodes/<name>/{definition.yaml, main.tf?, playbook.yml?, values.yaml?, README.md}`. `definition.yaml` MUST declare: `variables_schema`, `valid_connections`, `criticality` (`critical_path|non_critical`), `teardown_procedure`.

**Adapter** — typed A→B integration between two specific node types. NEVER "connector". Carries integration-handshake-only (domain join, API registration, service-account creation). Dir: `fusion-adapters/<src>--<tgt>/{definition.yaml, connect.yml, README.md}`. Declares: `source_type`, `target_type`, `variables_schema`, `priority_tier` (1=infra, 2=service, 3=post-integration). Compatibility enforced at canvas `onConnect`. Multi-adapter edges allowed. 3-tier priority is global across solution (R-02 simplification).

**Solution** — canvas of nodes wired by adapters. Tag `on-prem|cloud|hybrid`. MUST pin `git_sha` for every node and adapter at save.

**Validation:** `make validate-definitions` against `schemas/{node,adapter,solution}.schema.json`.

---

## TRUST ZONES (default-deny between zones; cross-zone via named auth interface; SC-7, SC-7(5), AC-4 — S2+)

```
Z-UI → Z-API → Z-DB
              → Z-SECRETS
              → Z-WORKER → Z-TARGET
Z-AUDIT (append-only; receives from all zones)
```

| Zone | Role | Inbound | Outbound |
|---|---|---|---|
| Z-UI | React canvas (Vite/RR) | browser TLS 1.3 | Z-API only |
| Z-API | Fastify control plane (Node 22) | Z-UI | Z-DB · Z-SECRETS · Z-WORKER · Z-AUDIT |
| Z-DB | Postgres | Z-API | none |
| Z-SECRETS | KMS / Secrets Manager | Z-API · Z-WORKER | none |
| Z-WORKER | Job execution (subprocess→Argo @S3+) | Z-API | Z-TARGET · Z-SECRETS · Z-AUDIT · allow-listed internet |
| Z-TARGET | Provisioned solution infra | Z-WORKER (deploy only) | varies |
| Z-AUDIT | Append-only audit sink | Z-API · Z-WORKER | none |

- mTLS @S3+ via service mesh (CONFIRM-06 or Linkerd default).
- NetworkPolicy: `deploy/k8s/netpol/`. `make netpol-check` validates every Pod selector covered.
- Egress allow-list: `deploy/egress-allowlist.yaml`. New entry requires CODEOWNER + ADR.
- **OPEN ISSUE (pre-S2 blocker):** frontend audit POSTs Z-UI → Z-AUDIT directly (F-005). `trust-zones.md` does not authorize this path. Decision required: route through Z-API relay OR amend trust-zones + egress-allowlist.

---

## STACK (pinned majors; lockfiles committed; Renovate auto-merge patch+green-CI only)

| Layer | Choice | Major | License | FIPS posture |
|---|---|---|---|---|
| OS (containers) | Red Hat UBI9 FIPS | 9.x | RH proprietary (free redist) | FIPS 140-3 OpenSSL provider |
| Runtime | Node.js LTS | 22 | MIT | UBI9 OpenSSL FIPS module |
| Frontend | React + @xyflow/react | 18 / 12 | MIT | n/a |
| Backend HTTP | Fastify | 5.x | MIT | per-route Zod validation |
| Validation | Zod | 3.x | MIT | shared FE/BE — schema → TS type |
| ORM | Drizzle | 0.x | Apache 2.0 | TS-native migrations |
| Auth tokens | jose | 5.x | MIT | OpenSSL FIPS |
| Job exec | child_process.spawn(shell:false)+ansible-playbook (S1-2) → Argo (S3+) | 2.17 / 3.5 | Apache 2.0 / GPLv3 (R-01) | — |
| IaC | OpenTofu | 1.8 | MPL 2.0 | (Hashi Terraform PROHIBITED — BSL) |
| Config Mgmt | Ansible-core | 2.17 | GPLv3 (R-01) | — |
| K8s deploy | Helm | 3.15 | Apache 2.0 | — |
| K8s | K3s | 1.30 | Apache 2.0 | — |
| VM first-boot | cloud-init | 24.x | Apache 2.0 / GPLv3 dual | — |
| Source control | Gitea (self-hosted on K3s; bundled per DECISION-0003) | 1.22 | MIT | — |
| Database | PostgreSQL | 16 | PostgreSQL | EBS encryption KMS CMK |
| Secrets | AWS Secrets Manager (FIPS endpoint) | — | — | FIPS 140-3 |
| Crypto provider | OpenSSL via UBI9 FIPS | 3.0 FIPS | Apache 2.0 | **FIPS 140-3 Cert #4985** |
| AuthN | OIDC (provider per CONFIRM-01) | — | — | — |
| Job queue | Graphile Worker (DECISION-0002) | — | MIT | Postgres-backed |
| Test runner | Vitest | 1.x | MIT | shared FE/BE |
| Lint | ESLint `@typescript-eslint/strict` | — | — | shared FE/BE |
| SAST | Semgrep (Node + frontend rulesets) | — | — | — |

### FIPS crypto allow-list

Approved: AES-256-GCM, AES-256-CBC + HMAC-SHA-384, RSA-3072+, ECDSA P-256/P-384, SHA-256/384/512, HKDF-SHA-384.
Prohibited: MD5, SHA-1, RC4, 3DES, any non-FIPS curve.
Verify: `node -e "require('crypto').getFips()"` MUST return `1`. `make fips-check`.

### Always-loaded hard rules (CLAUDE.md §3 — no exception)

- NO HashiCorp Terraform (BSL). Verify: `make license-scan`.
- NO crypto outside system FIPS provider (SC-13). Verify: `make fips-check`.
- NO `child_process.exec()` or `spawn({shell:true})` (SI-10). Verify: Semgrep `javascript.lang.security.audit.dangerous-spawn-shell`.
- NO raw secret in DB / repo / log / image / **LLM-prompt** (IA-5, SC-28, AC-21). Verify: `make secrets-scan`.
- NO direct write to `main`; NO force-push to `main` (CM-3).
- NO skip / disable / `continue-on-error` on CI gates (CM-3, CM-5).
- NO redefinition of node / adapter / solution.
- NO guessing CONFIRM-NN — surface and stop.
- NO silent reconcile of CLAUDE.md ↔ code conflicts.
- NO feature code before failing test (TDD §9).
- NO commit if vitest red.

---

## NIST 800-53 Rev. 5 control family hooks (selected)

`IA-2`/`IA-2(1,2,12)` authn/MFA stages/FIDO2/PIV · `IA-5(1)` secrets+rotation · `IA-8` federated authn · `IA-9` mTLS svc identity · `AC-3` RBAC · `AC-4` info flow · `AC-5` separation of duties · `AC-6` least privilege · `AC-16` data labeling · `AC-21` info sharing · `AU-2/3/5/9/11/12` audit minimum/fields/fail-closed/append-only/retention/coverage · `SC-7(/5)` zone egress · `SC-8(/1)` TLS/mTLS · `SC-12` key mgmt · `SC-13` FIPS crypto · `SC-28(/1)` rest encryption · `SC-39` process isolation · `CM-2` baseline · `CM-3` change control · `CM-5` access enforcement · `CM-6/7` hardening / least functionality · `SI-3` malicious code · `SI-7` integrity · `SI-10` input validation · `SR-3` supply origin · `SR-4` build integrity · `SR-11` component auth · `MP-3` media marking · `CA-5` POA&M · `CP-9/10` backup/restore.

---

## DATA CLASSIFICATION (FIPS 199 = Mod/Mod/Mod, pending CONFIRM-02)

| Class | Marking | At rest | In transit | Allowed egress |
|---|---|---|---|---|
| Public | none | optional | TLS 1.3 | any |
| Internal | INTERNAL | KMS CMK | TLS 1.3, mTLS @S3+ | within Cove.GDIT |
| CUI | `CUI//SP-PRIV` etc. (CONFIRM-03) | KMS CMK FIPS | TLS 1.3 mTLS, FIPS suites only | within authorization boundary |
| Secret-Ref | SECRET-REF | KMS CMK FIPS | TLS 1.3 mTLS | Z-SECRETS only |

CUI rules: never to non-allow-listed external (SC-7, AC-4); never in agent prompts/telemetry/error messages/stack traces (SC-7, MP-3); CUI Registry markings in UI @S3+; encrypted backups + quarterly restore @S3+ (CP-9, CP-10).

---

## DATA MODEL (Postgres — read-cache + draft state; UI MUST NOT read Git directly; promote-draft = Gitea PR)

```
nodes(id, name, type, version, git_sha, variables_schema, execution_worker,
      valid_connections, criticality, teardown_procedure, classification)
adapters(id, name, source_node_type, target_node_type, version, git_sha,
         variables_schema, priority_tier, criticality, classification)
solutions(id, name, version, git_sha, deployment_target, status, classification)
solution_nodes(solution_id, node_id, node_git_sha, position_x, position_y, variables_ref)
solution_edges(solution_id, source_node_id, target_node_id, adapter_id, adapter_git_sha)
environments(id, name, target_type, variables_schema, tenant_id)        -- DECISION-0019
env_variables(env_id, key, value | secret_ref, value_kind, classification, tenant_id)
                                                       -- CHECK: (value IS NOT NULL) <> (secret_ref IS NOT NULL)
                                                       -- secret_ref → AWS SM ARN (raw secrets PROHIBITED)
deployment_receipts(id, solution_id, solution_git_sha, started_at, completed_at,
                    status, snapshot_sha256, snapshot_signature, snapshot_blob_ref, classification)
                                                       -- IMMUTABLE: trigger denies UPDATE/DELETE; IAM-restricted role
audit_events(...)  -- separate sink; DECISION-0020: tenant-scoped, append-only, S1 transport=HTTP→PG
```

Rules: `env_variables.value_ref` MUST be Secrets Manager ARN (CHECK constraint); `deployment_receipts` immutable (Postgres trigger + IAM); `snapshot_blob_ref` → S3 object-lock @S3+; SHA-256 + cosign sig; migrations only via Drizzle (CODEOWNER review, CM-3); CUI/Secret-Ref columns tagged in `backend/src/db/schema.ts` @S2+.

---

## AUDIT (OCSF-aligned, ECS-named — ADR-0003)

Three streams — separate sinks, separate retention. **Never mix.**

| Stream | Sink | Retention | Integrity |
|---|---|---|---|
| App logs | stdout → Loki/CW | 30d S1 · 90d S2 · 1y S3+ | none |
| Metrics | OTel → Prometheus | 30d S1 · 1y S3+ | none |
| Audit events | append-only Z-AUDIT | 1y online + 6y archive S3+ | hash-chain S3+, WORM S4 |

- Sink technology: **CONFIRM-05 (open).** S1 ships with HTTP→Postgres direct sink (DECISION-0020). S2=NATS JetStream; S3=Kafka if env-native else NATS; S4=WORM+hash-chain.
- Authoritative schema: `schemas/audit-event.schema.json`. TS `AuditEvent` derived FROM schema (one-way: schema → types).
- **Required fields (always):** `ts` (ISO-8601 UTC ms), `event_id` (UUIDv7), `action` (verb.noun, max 64), `actor.id` (OIDC sub, max 256), `actor.type` (`user|service|agent`), `subject.type` (enum below), `subject.id` (max 256), `outcome` (`success|failure|denied`), `source.request_id`, `classification` (`none|cui|secret_ref`), `metadata.schema_version` ("1.0.0"), `metadata.product` ("fusion-core").
- **Required @S2+:** `environment` (`prototype|internal-mvp|hardened-pilot|production`), `class_uid` (OCSF), `severity_id` (1-5).
- **Conditional:** `git_sha` required for `deploy.*` and `signature.verify`.
- **subject.type enum:** `solution · node · adapter · secret_ref · role · schema · key · config`.
- **Action registry:**

| action | class_uid | sev | git_sha req'd |
|---|---|---|---|
| authn.success | 3001 | 1 | no |
| authn.failure | 3001 | 3 | no |
| authz.denied | 3002 | 3 | no |
| deploy.solution | 6001 | 2 | YES |
| teardown.solution | 6001 | 2 | YES |
| read.secret | 6002 | 2 | no |
| config.change | 6003 | 2 | no |
| role.change | 6003 | 3 | no |
| key.rotate | 6003 | 2 | no |
| schema.migrate | 6004 | 2 | no |
| signature.verify | 6004 | 2 | YES |

- **Emit interface:** ALL audit via `audit.emit(event)`. Direct sink calls prohibited (Semgrep `no-audit-events-in-app-logger`).
- **Auditable minimum (AU-2):** authn s/f, authz deny, secret read, deploy start/end, teardown, schema migrate, config change, role change, sig verify, key rotate.
- **Failure semantics:** emit failure → request fails closed @S3+; bounded local queue @S2; `reason` MUST NOT contain secrets/PII (backend blocklist scan); schema-validation-fail → 500 + app log (no recursive audit).

---

## ADRs (chronological; supersession via new ADR only)

| # | Title | Status | Tradeoff lvl | Notes |
|---|---|---|---|---|
| 0001 | CLAUDE.md contract | Accepted | L1 sec/comp | 17-item agent prohibitions; stage trajectory; FIPS S1+; SM S1+; SBOM S1+ |
| 0002 | @xyflow/react@12 | Accepted | L3 maint | replaces retired reactflow@11; MIT; risk R-06 |
| 0003 | OCSF audit schema + abstract emit interface | Accepted | L3 maint | OCSF struct + ECS naming; transport-agnostic emit; sink CONFIRM-05 |
| 0004 | Node.js/TS backend (Z-API + Z-WORKER) | Accepted | L3 maint | replaces FastAPI/Python; one registry/lockfile; Zod schemas FE↔BE; npm-mirror risk R-08 |

---

## OPEN CONFIRMATIONS (CONFIRM-NN — no guessing)

| ID | Question | Blocks |
|---|---|---|
| 01 | OIDC provider S1-2 (GDIT SSO / Keycloak / Cognito / other) | stack, sec controls |
| 02 | FIPS 199 categorization (Mod/Mod/Mod?) | data classification |
| 03 | CUI categories in scope | data class markings |
| 04 | Owner for R-01 (Ansible GPLv3) | risks |
| 05 | Audit sink tech (CW+S3 object-lock? Splunk? Elastic WORM?) | audit retention/integrity |
| 06 | Auth boundary (Cove.GDIT one boundary vs sub-VPCs separate?) | trust zones, data class |
| 07 | Private container registry S3+ (ECR? Harbor on K3s?) | dep policy |
| 08 | NIST AI RMF apply? (deploy-path AI vs dev-time agent only) | adds ai-governance.md |
| 09 | Stage promotion authority (sign-off) | CLAUDE.md §1 |
| 10 | Production deployment topology HA targets S3/S4 | trust zones |

---

## RISK REGISTER

| ID | Risk | Sev | Status | Owner | Closure | Mitigation |
|---|---|---|---|---|---|---|
| R-01 | Ansible GPLv3 redistribution risk | High | Open | CONFIRM-04 | S3 | Worker abstraction → swap to Salt/pyinfra/custom OR legal exception |
| R-02 | 3-tier adapter priority simplification | Medium | Open | Arch | S3 | Replace with Argo native DAG |
| R-03 | Single team is builder + first user | Low | Accepted | Team | n/a | Frustration is QA |
| R-04 | Internal vs multi-tenant retrofit cost | Medium | Open | Arch | S4 | tenant_id-ready isolation in data model |
| R-05 | Worker subprocess sandboxing weak | High | Open | Sec | S3 | gVisor/Firecracker; rootless @S2 |
| R-06 | @xyflow/react MIT not contractually guaranteed | Medium | Open | Arch | S2 | drop-in alt + license-scan tripwire |
| R-07 | audit.emit() transport semantic mismatch @S2 promotion | High | Open | Arch | S2 | failure-semantics test contract pre-swap; CONFIRM-05 unresolved |
| R-08 | npm mirror availability in classified/air-gap envs | Medium | Open | Arch | S3 | validate ≥1 named target env pre-S3 |

---

## ARBITRATION (in-progress; `fusion-arbiter` skill)

- **Authoritative artifacts:** `docs/decomposition/{01-architecture-breakdown,02-phased-build-plan,03-task-backlog}.md`.
- **Variance report:** `docs/fusion-arbiter-variance-report.md` — 42 entries (13 divergent · 24 scaffold-silent · 3 artifact-silent · 1 open-decision-closure · 1 same-level-conflict).
- **Decisions log:** `docs/fusion-arbiter-decisions.md` — append-only, 20 decisions accepted as of 2026-05-07.
- **Areas processed:** STACK · PATTERN · STATE done. **Remaining:** SCHEMA · API · REPO · DEPLOY · CI · COMPLIANCE · DOCS · ARTIFACT-SILENT · SAME-LEVEL-CONFLICTS.
- **Notable accepted decisions:**
  - 0001 STACK.BACKEND.VALIDATION — register Zod schemas on every Fastify route (close F-019); CI gate `CI.ZOD-ROUTE-COVERAGE` follow-on.
  - 0002 STACK.JOB-QUEUE — Graphile Worker (Postgres-backed) for Z-WORKER.
  - 0003 STACK.LIBRARY.GIT — bundle Gitea, configurable target via `GIT_PROVIDER`/`GIT_URL`/`GIT_TOKEN`, plus 5 evolvability conventions: single-module client, domain types at service boundary, webhook normalization at edge, provider-neutral env vars, audit `git.provider` tag.
  - 0010 — worker abstraction (MOSA pattern).
  - 0011 — `withTenant()` helper; tenant scoping infra.
  - 0018 — `deployment_receipts` immutable, FK to `environment_id`.
  - 0019 STATE.ENVIRONMENTS — `env_variables` CHECK (`value` XOR `secret_ref`); `schema_version` on `variables_schema`; abstract `secret_ref` resolver behind interface (AWS SM today, OpenBao later); every `secret.resolved` event emits to Z-AUDIT.
  - 0020 STATE.AUDIT-TRANSPORT — close OPEN; ship MVP1 at S1 (HTTP→Postgres direct sink); `audit_events` append-only + tenant-scoped; S2 transition gated on Stage 2 entry.

---

## CHECKPOINTS

- Stored in `docs/checkpoints/YYYY-MM-DD.md`. Latest: 2026-05-05.
- **Latest checkpoint posture: NOT promotion-ready. 12 BLOCKS_S2 findings.**
  - **Critical:** F-001 (no `authn.success`/`authn.failure` audit emit in `auth.ts`) · F-002 (audit emit tests missing required schema fields).
  - **High:** F-003 no JSON-Schema conformance test against `audit-event.schema.json` · F-004 backend audit bare `fetch()` · F-005 frontend Z-UI→Z-AUDIT direct (unauthorized path) · F-006 stale Python paths in agent docs (ADR-0004 violation) · F-007 `definitions.test.ts` absent + `validate-definitions` inline-Python (ADR-0004 violation) · F-008 `Step1Configure.tsx` untested · F-009 `Step4Monitor` failure-path untested · F-010 `docker-compose.yml` absent (`make up` exit 1) · F-011 `.semgrep/` absent (`make sast` aspirational) · F-012 `tools/agent_policy/` absent (no machine enforcement of CLAUDE.md §3).
- **Decision-challenger confidence ratings:** ADR-0001=2/5 · ADR-0002=3/5 · ADR-0003=2/5 · ADR-0004=3/5.

---

## CURRENT SCAFFOLD STATE (S1 Prototype)

- `backend/`: Fastify 5 + Zod + Drizzle. **21 tests green, ≥84% coverage.** Files: `app.ts`, `main.ts`, `common/http.ts`, `db/{index,schema}.ts`, `lib/audit/{index,types}.ts`, `middleware/auth.ts`, `routes/{deployments,health,solutions}.ts`, `schemas/{deployment,solution}.ts`, `__tests__/{audit,auth,definitions,deployments,health,http,solutions}.test.ts`.
- `frontend/`: React + Vite + Vitest. **83 tests green; auth + audit wired.** Pages: Catalog · SolutionDetail · DeployWizard (Step1-4) · AuditLog · AuthCallback. Lib: `audit/`, `auditQuery`, `auth/{AuthProvider,useAuth}`. Components: `graph/{SolutionGraph,FusionNodeCard,AdapterEdge}`, `layout/{AppShell,NavRail}`, `auth/AuthBypassBanner`.
- `fusion-nodes/`, `fusion-adapters/`: **ABSENT** — no nodes/adapters authored yet.
- `playbooks/`: only `site.yml` exists; `pre-check.yml` / `main.yml` / `verify.yml` ABSENT (F-025, F-041).
- `terraform/main.tf`: OpenTofu root, no resources yet.
- `docker-compose.yml`: ABSENT (F-010, blocks `make up`).
- `.semgrep/`: ABSENT (F-011, blocks SAST enforcement).
- `tools/agent_policy/`: ABSENT (F-012, blocks ADR-0001 CI gate).
- `src/`, `tests/`, `pyproject.toml`: removed per ADR-0004 — Python stack retired.
- CI workflow: `.gitea/workflows/ci-linux.yml` (NOT GitHub Actions — Gitea-hosted).

---

## CI/CD GATES

**Non-bypass** (CM-3, CM-5): `sast` · `secrets-scan` · `deps-scan` · `license-scan` · `container-scan` · `sbom` · `validate-definitions` · `fips-check`.

**Process rules:** no merge of own PRs (AC-5) · no push to `main` · signed commits · CODEOWNER review · branch protection + CODEOWNERS path-locked · conventional commits (`feat`|`fix`|`chore`|`docs`|`refactor`|`test`|`sec`|`ci`|`infra`); `sec:` triggers extra security review.

**Stage-gated thresholds:** unit cov advisory→≥70→≥85→≥90; SAST advisory→no-High→no-Med+→weekly-full; secrets enforce-all-stages + history-scan @S3+; deps advisory→no-High/Crit→14d-Med-SLA→7d-Med-SLA; container advisory→no-High/Crit→STIG-base→OpenSCAP; SBOM gen→attached→signed→shipped-to-customer; DAST off→weekly-baseline→per-release-baseline→per-release-active; pen-test off→off→annual→annual+post-major.

**Pre-push hook** (via `make install-hooks`): refuses push if local `make ci` not passed since last commit.

---

## TDD CONTRACT (CLAUDE.md §9)

1. Failing test first (`src/__tests__/<feature>.test.ts`).
2. Confirm failure-for-right-reason.
3. Minimum code to pass.
4. `npx vitest run` full suite green.
5. Refactor, keep green.
6. `npm run lint` zero errors.

**Required cases per feature:** happy path · invalid input (Zod 400/422) · boundary (empty/max/zero) · audit-event-emission test for any Z-AUDIT-touching action. Auth/Z-API features add: unauthenticated returns 401/403.

**Pre-commit gates:** vitest green + ≥60% cov @S1; ESLint zero errors; `tsc --noEmit` clean in changed package.

**FUSION-specific:**
- Every auditable action MUST have `audit.emit()` test asserting all required fields.
- Every new node/adapter/solution definition.yaml → `make validate-definitions` in CI OR schema assertion in `backend/src/__tests__/definitions.test.ts`.
- Cross-zone HTTP MUST go through `backend/src/common/http.ts`. Semgrep denies bare `fetch(` and `new Client(` outside that module.

---

## COMMIT POLICY (CLAUDE.md §10; Conventional Commits)

**Permitted only on:** explicit "commit" instruction OR "do X and commit it" after X complete & gates pass.

**Branch:** never `main` directly.
**Stage by name only** — never `git add -A` or `git add .`.
**One logical unit per commit.** CHANGELOG `[Unreleased]` entry required for `feat`/`fix`.

**Gates by classification:**

| Changed | Gates |
|---|---|
| backend src | `make backend-test` + `make backend-lint` |
| frontend src | `make frontend-test` + `make frontend-lint` |
| both | all four |
| docs/config only | (still) `make secrets-scan` |

`make secrets-scan` runs on all commits.

**Hard nevers (no override):** `git add -A`/`.` · `--no-verify` · `--no-gpg-sign` · force-push to `main` · commit to `main` · commit with red vitest · commit with secrets-scan findings · amend pushed commit.

**Co-author trailer:** `Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>`.

---

## AGENT POLICY — APPROVAL REQUIRED (`docs/agent-policy.md`)

Approval format: CODEOWNER comment in PR with literal `Approved by <name> for <action>`.

**Cannot without approval:** modify locked stack/zones · add new dep · add HashiCorp Terraform (HARD — no override) · open new egress · push/force-push to `main` · store raw secret · redefine domain · modify applied Drizzle migration · prod write · CI/CD/CODEOWNERS edit · IAM/KMS/SG edit · `backend/audit/` or audit-emit edit · audit table schema change · crypto-code touch · bypass §0 · CUI in prompt · resolve CONFIRM-NN by guessing.

---

## SUBAGENTS (`.claude/agents/`)

`backend-author` · `security-reviewer` · `schema-validator` · `dependency-reviewer` · `audit-emitter` · `migration-reviewer` · `architecture-drift-reviewer` · `standards-compliance-reviewer` · `trust-zone-reviewer` · `test-audit-reviewer` · `auth-crypto-reviewer` · `scaffold-completeness-reviewer` · `decision-challenger` · `finding-triage` · `checkpoint-aggregator` · `scout` · `grader` · `Explore` · `Plan`.

---

## SKILLS (user-invocable; `.claude/skills/`)

`fusion-arbiter` (architecture reconciliation) · `fusion-audit-emit` · `fusion-fips-crypto` · `fusion-secret-handling` · `fusion-node-author` · `fusion-stage-gating` · `checkpoint-review` · `pr-ready` · `promote-stage` · `new-node` · `new-adapter` · `add-dep` · `surface-conflict` · `simplify` · `review` · `security-review` · `init` · `update-config` · `keybindings-help` · `loop` · `schedule` · `fewer-permission-prompts` · `claude-api` · `claude-code-guide`.

---

## MAKE TARGETS (canonical)

`up` · `down` · `seed` · `backend-{dev,test,lint}` · `frontend-{dev,test,lint}` · `validate-definitions` · `layout-check` · `registry-check` · `netpol-check` · `sast` · `secrets-scan` · `deps-scan` · `license-scan` · `container-scan` · `sbom` · `sign` · `slsa-provenance` · `fips-check` · `dast` · `stig-check` · `deploy-{stage,prod}` · `teardown SOLUTION=<name>` · `ci` · `install-hooks` · `lockfile-check` · `deps-source-check`.

---

## DEPENDENCY POLICY

**Sources:** PyPI (Poetry hash-checked) · npm (lockfile integrity-checked) · public registries mirrored to private @S3+ · Gitea internal mirrors.

**Default-deny licenses:** GPL (any version, except Ansible-core under R-01 exception until S3) · AGPL · BSL · SSPL · Commons Clause · custom non-OSI. Allowed list: `ALLOWED_LICENSES.md`.

**New-dep workflow:** confirm not in tree → license check → release-date + 12mo cadence → PR with 4-field justification (name, version, license, transitive delta, maintenance signal) → `dependency-reviewer` subagent sign-off → CODEOWNER review.

---

## SECRETS POLICY (`docs/secrets-and-keys.md`)

- ALL secrets via AWS Secrets Manager (FIPS endpoint), IAM role/IRSA. (S1+)
- Never disk except tmpfs mode 0400 process-scoped.
- Never logs (use redactor allow-list).
- Never long-lived process env vars; per-request fetch + cache TTL ≤5min @S2+.
- Worker creds rotate per-deploy (one-time STS scoped to that deployment) @S2+.
- KMS CMKs only @S2+ (not AWS-managed keys).
- **NEVER include in LLM prompt** — LLM provider is out-of-boundary (SC-7, AC-21).

`.env`: PERMITTED for non-sensitive local-dev only (ports, log levels). Gitleaks-scanned. Always in `.gitignore`. Storing secrets/creds PROHIBITED at all stages including S1.

---

## FAILURE HANDLING

**User-facing classes (engineer-prompted):**

| Class | Trigger | Options |
|---|---|---|
| Critical-path | T1 adapter or `critical_path` node fails | full teardown / leave for inspection |
| Non-critical | T2/T3 fails, core healthy | retry / skip&continue / full teardown |
| Infra | OpenTofu fails pre-provision | retry / abort |

**Security-relevant (system, NOT user-prompted):**

| Class | Trigger | Required behavior |
|---|---|---|
| AuthN failure | token invalid/expired | audit `outcome=failure`, 401, NO retry |
| AuthZ denial | RBAC deny | audit `outcome=denied`, 403, NO retry |
| Secret-fetch fail | SM error | audit, fail closed, alert (PagerDuty @S3+) |
| Sig-verify fail | cosign / SBOM / receipt | audit, fail closed, halt deploy, alert |
| Audit-emit fail | Z-AUDIT unreachable | fail request closed @S3+; bounded local queue @S2 |

**Teardown:** every node MUST declare `teardown_procedure`. OpenTofu = `tofu destroy -auto-approve=false` operator confirm @S3+. Ansible state-in-instance = node-author owns play. `make validate-definitions` rejects nodes without it.

---

## ENVIRONMENT NOTES

- Workspace lives in cove@emergelabs **VPC1**.
- Internal services live in cove.gdit **VPC3**.
- Cross-VPC TLS requires **cove-DEV-CA** trusted in 7 places on Linux: system trust store, Node, Chrome NSS, Python, Docker, Firefox, Java.

---

## REFERENCES (when the foreign LLM needs to dig deeper, ask for any of these)

- Source of truth: `CLAUDE.md` (repo root).
- All docs: `docs/`.
- Decisions: `docs/decisions/000N-*.md`.
- Open questions: `docs/open-questions.md`.
- Risks: `docs/risks.md`.
- Trust zones: `docs/architecture/trust-zones.md`.
- Audit: `docs/audit-spec.md` + `schemas/audit-event.schema.json`.
- Domain: `docs/domain.md`.
- Glossary: `docs/glossary.md`.
- Arbiter: `docs/fusion-arbiter-{decisions,evidence,variance-report}.md`.
- Architectural artifacts (Doc 1-3): `docs/decomposition/`.
- Checkpoints: `docs/checkpoints/YYYY-MM-DD.md`.
- Stage tracker: `.fusion/stage`.

---

## CONTEXT-PACK MAINTENANCE (housing & cadence)

This file lives at `docs/project-context.md` so it is committed, version-controlled, reviewable, and copy-pastable.

**Refresh triggers** (refresh after any of these):

1. **Every checkpoint review** (currently ad-hoc; see `docs/checkpoints/`). Recommended: extend `.claude/skills/checkpoint-review/SKILL.md` to refresh this file as a final step.
2. **Every accepted ADR** (`docs/decisions/000N-*.md`).
3. **Every stage promotion** (S1→S2 etc.; CLAUDE.md §1).
4. **Every batch of accepted arbiter decisions** (`docs/fusion-arbiter-decisions.md`).
5. **Every change to `CLAUDE.md`** itself.

When refreshing, retain the `## ABBREV` block stable and update only the moving sections (snapshot header line, ADR table, OPEN CONFIRMATIONS status, RISK status, ARBITRATION decision count + remaining areas, CHECKPOINTS latest line, CURRENT SCAFFOLD STATE, anchor commit). The structural skeleton should not change without explicit user direction.
