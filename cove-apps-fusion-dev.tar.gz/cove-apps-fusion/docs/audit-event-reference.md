# FUSION Audit Event Reference

The Open Cybersecurity Schema Framework (OCSF) is a vendor-neutral, community-maintained schema standard for security telemetry. Per ADR-0003, FUSION adopts the OCSF structural skeleton (`metadata` block, `class_uid`, `category_uid`, `severity_id`, `activity_id` enum pattern) while retaining ECS-compatible dot-notation field names (`actor.*`, `subject.*`, `action`, `outcome`, `source.*`) that are already established across the codebase and Audit Log UI. Every action that touches authentication, authorization, secrets, deployment lifecycle, schema migrations, role changes, or key operations MUST call `audit.emit(event: AuditEvent)` — the sole application-level call site. At Stage 1 the implementation posts directly to the sink identified by `AUDIT_SINK_URL`; the interface is designed to be swapped for NATS JetStream at Stage 2 and Kafka at Stage 3+ without changing callers. All events land in Z-AUDIT, the append-only audit zone that receives from every other trust zone (Z-API, Z-WORKER, Z-UI). The authoritative schema is `schemas/audit-event.schema.json` (schema version `1.0.0`); the TypeScript type `AuditEvent` in `backend/src/lib/audit/types.ts` is hand-derived from it at Stage 1 and must be kept in sync.

---

## Required Fields (all events)

Every event sent to Z-AUDIT MUST include the following fields. Omitting any of them will fail JSON Schema validation.

| Field | Type | Constraints | Description |
|---|---|---|---|
| `ts` | `string` (date-time) | ISO-8601 UTC, millisecond precision | Timestamp of the event. Example: `2026-05-04T14:32:01.123Z` |
| `event_id` | `string` (uuid) | UUIDv7 — time-ordered, globally unique | Stable identifier for this event instance. Must not be reused. |
| `action` | `string` | Pattern `^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$`, max 64 chars | `verb.noun` identifying the auditable action. |
| `actor.id` | `string` | Max 256 chars | OIDC subject claim (`sub`) of the entity that triggered the action. |
| `actor.type` | `string` | Enum: `user`, `service`, `agent` | `user` = human via OIDC; `service` = machine identity; `agent` = AI coding agent. |
| `subject.type` | `string` | Enum: `solution`, `node`, `adapter`, `secret_ref`, `role`, `schema`, `key`, `config` | Resource type the action was performed on. |
| `subject.id` | `string` | Max 256 chars | Stable identifier of the subject resource. |
| `outcome` | `string` | Enum: `success`, `failure`, `denied` | Terminal result of the action. |
| `reason` | `string` | Max 512 chars; **required when `outcome` is `failure` or `denied`** | Human-readable explanation. MUST NOT contain secrets or PII. |
| `source.request_id` | `string` | Max 128 chars | `X-Request-ID` correlation ID — ties the audit event to application logs. |
| `classification` | `string` | Enum: `none`, `cui`, `secret_ref` | Data classification of the subject resource at the time of the action. |
| `metadata.schema_version` | `string` | Constant `"1.0.0"` | Semver of the audit schema. Consumers MUST reject events where the major version does not match. |
| `metadata.product` | `string` | Constant `"fusion-core"` | Identifies the emitting system. |

### Optional Fields (conditional or stage-gated)

| Field | Type | When present | Stage required |
|---|---|---|---|
| `actor.session_id` | `string` (max 128) | OIDC session available | any |
| `subject.name` | `string` (max 256) | Human-readable name at event time | any |
| `source.ip` | `string` | Caller IP as seen by Z-API | any |
| `source.user_agent` | `string` (max 512) | HTTP User-Agent of caller | any |
| `class_uid` | `integer` | OCSF class identifier | required at S2+ |
| `severity_id` | `integer` (1–5) | OCSF severity | required at S2+ |
| `git_sha` | `string` | 40-char hex SHA of artifact | required for `deploy.*` and `signature.verify` actions |
| `environment` | `string` | FUSION stage environment | required at S2+ |
| `metadata.emit_version` | `string` (max 64) | Version of the audit emit library | any |

> **Severity scale:** 1 = Informational, 2 = Low, 3 = Medium, 4 = High, 5 = Critical.

---

## Event Classes

The following classes are defined in `schemas/audit-event.schema.json` (`x-ocsf-class-map`) and `backend/src/lib/audit/types.ts` (`ClassUid`). They represent the complete set of OCSF class identifiers FUSION recognizes at schema version `1.0.0`.

---

### Authentication — class_uid: 3001

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet. The only current call to `audit.emit` is in `backend/src/__tests__/audit.test.ts`.

- **Trigger:** A principal attempts to authenticate to FUSION (success or failure).
- **Emitted by:** Z-API (authentication handler)
- **Actions covered:** `authn.success`, `authn.failure`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | OIDC `sub` of the authenticating principal; use `"anonymous"` if authentication did not complete |
  | `actor.type` | `user`, `service`, or `agent` |
  | `subject.type` | `role` or `config` (the OIDC session or identity config) |
  | `subject.id` | Identity provider client ID or session identifier |
  | `outcome` | `success` or `failure` |
  | `reason` | Required when `outcome` is `failure` — MUST NOT reveal credential details |
  | `classification` | `none` |

- **NIST 800-53 controls:** AU-2 (auditable events), AU-3 (content of records), IA-8 (identification and authentication)
- **Example payload (success):**
  ```json
  {
    "ts": "2026-05-08T10:15:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000001",
    "action": "authn.success",
    "class_uid": 3001,
    "severity_id": 1,
    "actor": { "id": "user|abc123", "type": "user", "session_id": "sess_xyz" },
    "subject": { "type": "config", "id": "oidc-client-fusion-core" },
    "outcome": "success",
    "source": { "request_id": "req-aaa-001", "ip": "10.0.1.5", "user_agent": "Mozilla/5.0" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```
- **Example payload (failure):**
  ```json
  {
    "ts": "2026-05-08T10:15:05.000Z",
    "event_id": "01960000-0000-7000-0000-000000000002",
    "action": "authn.failure",
    "class_uid": 3001,
    "severity_id": 3,
    "actor": { "id": "anonymous", "type": "user" },
    "subject": { "type": "config", "id": "oidc-client-fusion-core" },
    "outcome": "failure",
    "reason": "Token signature verification failed",
    "source": { "request_id": "req-aaa-002", "ip": "10.0.1.5" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

### Authorization — class_uid: 3002

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet.

- **Trigger:** A principal attempts to perform an action they are not authorized to perform.
- **Emitted by:** Z-API (authorization middleware)
- **Actions covered:** `authz.denied`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | OIDC `sub` of the authenticated principal that was denied |
  | `actor.type` | `user`, `service`, or `agent` |
  | `subject.type` | The resource type the access was denied on |
  | `subject.id` | Stable ID of the resource |
  | `outcome` | Always `denied` |
  | `reason` | Required — describe the denied permission, MUST NOT reveal policy internals that could aid privilege escalation |
  | `classification` | Classification of the resource that was accessed |

- **NIST 800-53 controls:** AU-2, AU-3, AC-3 (access enforcement), AC-6 (least privilege)
- **Example payload:**
  ```json
  {
    "ts": "2026-05-08T10:20:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000003",
    "action": "authz.denied",
    "class_uid": 3002,
    "severity_id": 3,
    "actor": { "id": "user|abc123", "type": "user", "session_id": "sess_xyz" },
    "subject": { "type": "solution", "id": "sol-prod-001", "name": "cove-analytics" },
    "outcome": "denied",
    "reason": "Role 'viewer' does not have deploy permission on solution",
    "source": { "request_id": "req-bbb-001", "ip": "10.0.1.5" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

### Application Activity — Deploy — class_uid: 6001

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet.

- **Trigger:** A solution, node, or adapter is deployed or torn down.
- **Emitted by:** Z-API (deploy endpoint) or Z-WORKER (async deployment runner)
- **Actions covered:** `deploy.solution`, `teardown.solution`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | OIDC `sub` of the user or service that initiated the deployment |
  | `subject.type` | `solution`, `node`, or `adapter` |
  | `subject.id` | Stable ID of the deployed artifact |
  | `subject.name` | Human-readable name at deploy time |
  | `git_sha` | **Required** — full 40-char SHA of the artifact being deployed or torn down |
  | `outcome` | `success` or `failure` |
  | `reason` | Required when `outcome` is `failure` |
  | `classification` | Classification of the artifact |

- **NIST 800-53 controls:** AU-2, AU-3, CM-2 (baseline configuration), CM-3 (configuration change control), SI-7 (software integrity)
- **Example payload (deploy success):**
  ```json
  {
    "ts": "2026-05-08T11:00:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000004",
    "action": "deploy.solution",
    "class_uid": 6001,
    "severity_id": 2,
    "actor": { "id": "user|abc123", "type": "user" },
    "subject": { "type": "solution", "id": "sol-001", "name": "cove-analytics" },
    "outcome": "success",
    "git_sha": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
    "source": { "request_id": "req-ccc-001" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```
- **Example payload (teardown failure):**
  ```json
  {
    "ts": "2026-05-08T11:05:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000005",
    "action": "teardown.solution",
    "class_uid": 6001,
    "severity_id": 3,
    "actor": { "id": "service|deployer", "type": "service" },
    "subject": { "type": "solution", "id": "sol-001", "name": "cove-analytics" },
    "outcome": "failure",
    "reason": "K3s namespace removal timed out after 300s",
    "git_sha": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
    "source": { "request_id": "req-ccc-002" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

### Application Activity — Secret — class_uid: 6002

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet.

- **Trigger:** A secret reference is read from AWS Secrets Manager (or the configured secrets backend).
- **Emitted by:** Z-API or Z-WORKER (any component that calls the secrets layer)
- **Actions covered:** `read.secret`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | OIDC `sub` or service identity that requested the secret |
  | `subject.type` | Always `secret_ref` |
  | `subject.id` | ARN or logical name of the secret reference — MUST NOT be the secret value |
  | `outcome` | `success`, `failure`, or `denied` |
  | `reason` | Required when `outcome` is `failure` or `denied` |
  | `classification` | `secret_ref` |

- **NIST 800-53 controls:** AU-2, AU-3, AU-9, IA-5 (authenticator management), SC-28 (protection of information at rest), AC-21 (information sharing)
- **Example payload:**
  ```json
  {
    "ts": "2026-05-08T11:10:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000006",
    "action": "read.secret",
    "class_uid": 6002,
    "severity_id": 2,
    "actor": { "id": "service|fusion-core", "type": "service" },
    "subject": { "type": "secret_ref", "id": "arn:aws:secretsmanager:us-east-1:123456789012:secret:fusion/db-password" },
    "outcome": "success",
    "source": { "request_id": "req-ddd-001" },
    "classification": "secret_ref",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

### Application Activity — Config — class_uid: 6003

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet.

- **Trigger:** A configuration value is changed, a role assignment is modified, or a cryptographic key is rotated.
- **Emitted by:** Z-API (admin/config endpoints)
- **Actions covered:** `config.change`, `role.change`, `key.rotate`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | OIDC `sub` of the administrator performing the change |
  | `subject.type` | `config` for `config.change`; `role` for `role.change`; `key` for `key.rotate` |
  | `subject.id` | Stable identifier of the config key, role ID, or key ID |
  | `subject.name` | Human-readable name of the changed resource |
  | `outcome` | `success` or `failure` |
  | `reason` | Required when `outcome` is `failure` |
  | `classification` | Classification of the config/role/key resource |

- **NIST 800-53 controls:** AU-2, AU-3, CM-3 (configuration change control), AC-2 (account management), IA-3 (device identification), SC-12 (cryptographic key establishment)
- **Example payload (role change):**
  ```json
  {
    "ts": "2026-05-08T11:15:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000007",
    "action": "role.change",
    "class_uid": 6003,
    "severity_id": 3,
    "actor": { "id": "user|admin001", "type": "user" },
    "subject": { "type": "role", "id": "role-deployer", "name": "deployer" },
    "outcome": "success",
    "source": { "request_id": "req-eee-001" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```
- **Example payload (key rotation):**
  ```json
  {
    "ts": "2026-05-08T11:20:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000008",
    "action": "key.rotate",
    "class_uid": 6003,
    "severity_id": 3,
    "actor": { "id": "service|key-manager", "type": "service" },
    "subject": { "type": "key", "id": "kms://alias/fusion-signing-key", "name": "fusion-signing-key" },
    "outcome": "success",
    "source": { "request_id": "req-eee-002" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

### Application Activity — Schema — class_uid: 6004

> **[PLANNED]** — defined in `types.ts` and `schemas/audit-event.schema.json`. No production call site exists yet.

- **Trigger:** A database schema migration is applied, or a deployment artifact's signature is verified.
- **Emitted by:** Z-API (migration runner) or Z-WORKER (deployment signature verification)
- **Actions covered:** `schema.migrate`, `signature.verify`
- **Required fields (in addition to base):**

  | Field | Value guidance |
  |---|---|
  | `actor.id` | Service identity that ran the migration or verification |
  | `subject.type` | `schema` for `schema.migrate`; `solution`, `node`, or `adapter` for `signature.verify` |
  | `subject.id` | Migration ID or artifact identifier |
  | `git_sha` | **Required for `signature.verify`** — SHA of the artifact being verified |
  | `outcome` | `success` or `failure` |
  | `reason` | Required when `outcome` is `failure` |
  | `classification` | `none` for schema migrations; classification of the artifact for signature verification |

- **NIST 800-53 controls:** AU-2, AU-3, CM-3 (configuration change control), SI-7 (software, firmware, and information integrity), SA-10 (developer configuration management)
- **Example payload (schema migration):**
  ```json
  {
    "ts": "2026-05-08T11:25:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000009",
    "action": "schema.migrate",
    "class_uid": 6004,
    "severity_id": 2,
    "actor": { "id": "service|fusion-core", "type": "service" },
    "subject": { "type": "schema", "id": "migration-0004-add-audit-table", "name": "Add audit table" },
    "outcome": "success",
    "source": { "request_id": "req-fff-001" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```
- **Example payload (signature verification failure):**
  ```json
  {
    "ts": "2026-05-08T11:30:00.000Z",
    "event_id": "01960000-0000-7000-0000-000000000010",
    "action": "signature.verify",
    "class_uid": 6004,
    "severity_id": 4,
    "actor": { "id": "service|deployer", "type": "service" },
    "subject": { "type": "solution", "id": "sol-001", "name": "cove-analytics" },
    "outcome": "failure",
    "reason": "cosign signature bundle not found for digest sha256:abc123",
    "git_sha": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2",
    "source": { "request_id": "req-fff-002" },
    "classification": "none",
    "environment": "prototype",
    "metadata": { "schema_version": "1.0.0", "product": "fusion-core" }
  }
  ```

---

## Planned Events (not yet implemented)

All six event classes are currently [PLANNED]. The `audit.emit()` function exists and is tested in `backend/src/__tests__/audit.test.ts`, but no production code path calls it yet. The table below summarizes what is expected when each class is wired:

| class_uid | Class name | Planned actions | Expected emitter | Blocking on |
|---|---|---|---|---|
| 3001 | Authentication | `authn.success`, `authn.failure` | Z-API auth handler | Authentication routes not yet authored |
| 3002 | Authorization | `authz.denied` | Z-API authz middleware | Authorization middleware not yet authored |
| 6001 | Deploy | `deploy.solution`, `teardown.solution` | Z-API deploy endpoint / Z-WORKER | Deploy routes and worker not yet authored |
| 6002 | Secret | `read.secret` | Z-API or Z-WORKER secrets layer | Secrets integration not yet authored |
| 6003 | Config | `config.change`, `role.change`, `key.rotate` | Z-API admin endpoints | Admin routes not yet authored |
| 6004 | Schema | `schema.migrate`, `signature.verify` | Migration runner / Z-WORKER | Migration runner not yet authored; signature verification not yet wired |

When a new call site is added, the implementing author MUST:
1. Confirm the correct `class_uid` from this document.
2. Confirm `subject.type` matches one of the allowed enum values in `schemas/audit-event.schema.json`.
3. Add a test asserting `audit.emit` was called with the correct `action` and `outcome` fields (see `CLAUDE.md` §9 — FUSION-Specific Test Obligations).
4. For `deploy.*` and `signature.verify` actions, assert that `git_sha` is present and a valid 40-character hex string.

---

## Schema Version History

| Version | Date | Change | ADR |
|---|---|---|---|
| `1.0.0` | 2026-05-04 | Initial schema — OCSF-aligned, 6 class_uid values, ECS-compatible field names | ADR-0003 |

Breaking changes (major version bump) require a new ADR entry before the schema file may be modified.

---

## References

- `schemas/audit-event.schema.json` — JSON Schema source of truth (schema version `1.0.0`)
- `backend/src/lib/audit/types.ts` — TypeScript types derived from the JSON Schema (Stage 1 hand-maintained)
- `backend/src/lib/audit/index.ts` — `audit.emit()` implementation
- `docs/decisions/0003-adopt-ocsf-audit-schema.md` — ADR governing schema standard, transport, and versioning
- `docs/audit-spec.md` — required auditable event minimum set (AU-2)
- OCSF specification: https://schema.ocsf.io
