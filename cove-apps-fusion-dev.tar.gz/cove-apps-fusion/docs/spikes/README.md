# FUSION Spikes Index

Research investigations scoped to specific architectural uncertainties. Each spike
produces a structured report before any implementation begins. All owners are
`[TBD — assign before sprint planning]` at Stage 1.

| # | Title | Key Question | Blocker for |
|---|---|---|---|
| 01 | [Git Provider Abstraction](spike-01-git-provider-abstraction.md) | Can FUSION abstract across Gitea, GitHub Enterprise, GitLab without re-architecture? | Stage 2 / first non-Gitea customer |
| 02 | [Subprocess Isolation](spike-02-subprocess-isolation.md) | What sandboxing approach satisfies SI-10 for the MVP1 execution worker? | First deployment job |
| 03 | [OpenBao Integration](spike-03-openbao-integration.md) | How does FUSION resolve `secret_ref` pointers at deploy time without materializing secrets? | V1 secret-aware deployments |
| 04 | [OPA Policy Bundle Structure](spike-04-opa-policy-bundle-structure.md) | What is the correct OPA bundle layout for multi-tenant, multi-action Rego? | Full authz implementation |
| 05 | [OpenTelemetry Stack](spike-05-opentelemetry-stack.md) | Which OTel collector/backend integrates with FUSION's OCSF audit trail at V1? | V1 observability |
| 06 | [Pin Health Monitoring](spike-06-pin-health-monitoring.md) | How should FUSION detect and surface stale git SHA pins in deployed solutions? | Pin-with-monitoring (DECISION-0013) |

## Adding a Spike

1. Create `docs/spikes/spike-NN-<kebab-title>.md` following the structure of any existing spike.
2. Add a row to the table above.
3. Assign an owner before the relevant sprint planning session.
