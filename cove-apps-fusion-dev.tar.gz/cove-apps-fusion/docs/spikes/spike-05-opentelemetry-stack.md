# Spike 5: OpenTelemetry Stack

**Time-box:** 1-2 weeks (40-80 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** V1.OBSERVE.001 (Bundle Loki in FUSION Helm chart); V1.OBSERVE.002 (Bundle Grafana); V1.OBSERVE.003 (Bundle Prometheus); V1.OBSERVE.004 (Configure Pino to emit JSON logs to Loki); V1.OBSERVE.005 (Standard Grafana dashboards); V1.OBSERVE.006 (Graduate audit transport to S2 / NATS)

## Context

DECISION-0009 (STACK.OBSERVABILITY.METRICS) adopted the OpenTelemetry SDK at MVP1 with a `/metrics` endpoint and audit-trace correlation. The MVP1 scope is: logs to stdout, `/metrics` endpoint exposed (no scraper), OTel `trace_id` and `span_id` plumbed into every Z-AUDIT event. Bundled Loki, Prometheus, and Grafana were explicitly deferred to V1+.

V1.OBSERVE.001-005 in the task backlog represent the full observability stack bundling work. However, the integration details — how the OTel SDK collector configuration, Loki log shipping, Prometheus scrape config, and Grafana dashboard provisioning compose in a K3s Helm deployment — have not been designed. The V1.OBSERVE tasks are assigned fixed effort estimates (6-16 hours each), but these estimates assume the integration mechanics are understood. The spike investigates the full stack integration to validate or revise those estimates and to surface any architectural decisions required before work begins.

The task backlog also includes V1.OBSERVE.006: graduating the audit transport from S1 (HTTP to Postgres) to S2 (NATS JetStream). This depends on the same observability infrastructure and shares the OTel instrumentation layer. The spike should assess whether the NATS transport and the Loki/Prometheus stack share any deployment ordering dependencies.

## Questions to Answer

1. What is the correct Helm subchart composition for bundling Loki, Prometheus, and Grafana alongside FUSION services — should FUSION use upstream community Helm charts as dependencies (with values overrides) or author minimal charts from scratch?
2. How does the OTel SDK collector at the FUSION service layer integrate with Prometheus scraping — does the `/metrics` endpoint established at MVP1 remain the scrape target, or should an OTel Collector sidecar be introduced at V1?
3. How should Pino JSON log output be shipped to Loki — via Promtail DaemonSet, Loki's push API directly from the application, or via an OTel log exporter? What are the label and stream configuration requirements?
4. What persistent storage configuration is required for Loki and Prometheus in K3s — PersistentVolumeClaim size, storage class, and retention policy?
5. How are Grafana dashboards provisioned — ConfigMap-based provisioning (GitOps-friendly), Grafana's API at startup, or manual import? What is the dashboard update workflow?
6. What is the relationship between OTel `trace_id` / `span_id` fields in Z-AUDIT events (per DECISION-0009) and Grafana's trace correlation feature — can Grafana link audit log entries to traces without additional configuration?
7. What does the NATS JetStream deployment look like in the Helm chart, and what are the ordering dependencies relative to the audit Postgres sink and the Loki/Prometheus stack?
8. Are there security or trust-zone implications for the observability stack endpoints (Loki push API, Prometheus `/metrics`, Grafana UI) that require authentication at Stage 1 or Stage 2?

## Success Criteria

By the end of this spike:

- A working observability stack (Loki + Prometheus + Grafana) is deployed via Helm subcharts in a K3s environment, with FUSION service logs flowing to Loki and metrics flowing to Prometheus.
- Grafana dashboards are provisioned via ConfigMap (or the chosen provisioning method) and display FUSION service health, audit event volumes, and deployment metrics.
- The Pino-to-Loki log shipping path is validated end-to-end.
- The OTel trace correlation with Grafana is assessed: whether Z-AUDIT `trace_id` fields link to Grafana traces without additional work.
- An ADR is drafted covering: subchart composition model, log shipping approach, dashboard provisioning model, persistent storage configuration, and NATS ordering dependencies.
- Revised effort estimates for V1.OBSERVE.001-006 are produced based on prototype learnings.

## Suggested Approach

1. Review the current FUSION Helm chart skeleton (`helm/fusion/`) to understand the subchart structure established in DECISION-0006. Identify where Loki, Prometheus, and Grafana subcharts would attach.
2. Evaluate upstream Helm charts: `grafana/loki`, `prometheus-community/prometheus`, `grafana/grafana`. For each, assess: chart stability, default values alignment with FUSION needs, and whether FUSION's values overlay is sufficient or whether custom templates are required.
3. Deploy Loki in K3s via the upstream chart. Confirm persistent volume creation. Test log ingestion via Promtail DaemonSet against FUSION service stdout output.
4. Deploy Prometheus in K3s. Confirm the `/metrics` endpoint from FUSION's MVP1 OTel setup is scraped. Validate that standard Fastify and Node.js metrics appear in Prometheus.
5. Deploy Grafana in K3s. Configure Loki and Prometheus data sources. Provision a minimal dashboard via ConfigMap. Confirm the dashboard displays data.
6. Test trace correlation: emit a Z-AUDIT event with `trace.id` populated, find it in Loki, and attempt to navigate to the corresponding trace in Grafana Tempo (if available) or document what additional infrastructure would be needed.
7. Prototype NATS JetStream deployment as a Helm subchart. Confirm it can receive audit events from the FUSION `audit.emit()` path. Document the startup ordering requirement relative to Z-API.
8. Assess the security posture of all exposed endpoints: document which require authentication and at which stage.

## Expected Output

- A working observability stack prototype in K3s (spike branch, not production-merged) with all three services (Loki, Prometheus, Grafana) deployed via Helm subcharts.
- An ADR covering: subchart model, log shipping approach, dashboard provisioning, persistent storage, NATS ordering, and security posture of observability endpoints.
- Revised effort estimates for V1.OBSERVE.001-006.
- Documentation of any changes required to the existing MVP1 OTel instrumentation to support the V1 stack.

## Risks

- Upstream Helm chart versions for Loki, Prometheus, and Grafana may not be pinned in FUSION's dependency policy, requiring SBOM and license validation before they can be adopted (per `docs/dependency-policy.md`). This could add time before the spike can produce a working deployment.
- Persistent volume configuration in K3s (using the local-path provisioner) differs from production EKS storage classes, meaning the prototype storage configuration may not transfer directly to the production Helm chart values.
- Promtail DaemonSet log shipping requires RBAC permissions to read pod logs from the K3s API — if the cluster RBAC policy is restrictive, Promtail may not be able to collect logs from all FUSION pods.
- The NATS JetStream integration (V1.OBSERVE.006) adds a startup ordering dependency: if NATS is not healthy when Z-API starts, audit event emission may fail. The fail-closed vs. fail-open behavior at NATS startup must be resolved before V1.OBSERVE.006 can be implemented.
- Grafana trace correlation requires a Tempo or Jaeger backend to store traces. If no trace backend is bundled in V1, the `trace_id` fields in Z-AUDIT events will be visible in logs but will not link to traces in Grafana — reducing the correlation benefit established in DECISION-0009.
