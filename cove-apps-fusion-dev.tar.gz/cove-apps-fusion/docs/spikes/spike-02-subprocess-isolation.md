# Spike 2: Subprocess Isolation

**Time-box:** 3-5 days (24-40 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** V1.SPIKE.002 (Worker Abstraction Interface Validation); V1.EXEC.001 (Replace subprocess execution with K8s Job execution); V1.EXEC.002 (Argo Workflows for orchestration)

## Context

At MVP1, Z-WORKER executes deployment workloads (Ansible, and future alternatives) as local subprocesses. DECISION-0010 established the `ExecutionWorker` interface and the `MockWorker` pattern to insulate Z-WORKER orchestration from any specific execution backend. However, local subprocess execution carries known limitations: credential management requires injecting secrets into the subprocess environment, output streaming relies on stdout/stderr piping within the same process namespace, and failure isolation is limited — a runaway subprocess can affect Z-WORKER's own stability.

V1.SPIKE.003 in the task backlog calls for investigating K8s Job-based subprocess sandboxing as the V1 execution model. This spike must complete before V1.EXEC.001 can be scoped or started. The spike is framed as "K8s Job-Based Subprocess Sandboxing" in the task backlog and addresses how deployment workloads would move from local subprocess execution to Kubernetes Jobs, with particular attention to credential injection, state passing, and output streaming.

A parallel concern is V1.SPIKE.002 (Worker Abstraction Interface Validation): the `ExecutionWorker` interface defined at MVP1 needs validation that it can accommodate K8s Job dispatch without requiring interface surgery. Both spikes share the question of whether the interface abstraction is sufficiently provider-neutral.

## Questions to Answer

1. Does the `ExecutionWorker` interface (from DECISION-0010 / `backend/src/worker/types.ts`) need modification to support K8s Job dispatch, or is it already appropriately abstract?
2. How should deployment credentials (AWS IAM credentials, Ansible inventory secrets) be injected into a K8s Job without passing them through environment variables in the Job spec (which would expose them in the K8s API server)?
3. What is the output streaming model for K8s Jobs — K8s log streaming API, a Job-side WebSocket, or another approach — and how does it integrate with the existing `streamOutput(handle): AsyncIterable<OutputChunk>` interface contract?
4. How is execution state (plan input, partial progress, error classification) passed into and out of a K8s Job, given that Jobs are ephemeral?
5. What constraints does K3s (the MVP1 hosting environment) impose on Job scheduling, resource limits, and namespace isolation compared to enterprise Kubernetes?
6. What is the credential model for Z-WORKER to submit Jobs to the K8s API — in-cluster service account, or external kubeconfig?
7. Can Pyinfra (the alternative worker considered in V1.SPIKE.002) be run inside the same K8s Job container as Ansible, or does it require a separate Job image? What does this mean for the worker interface's `supportedNodeKinds` / `supportedAdapterKinds` capability discovery?
8. What is the failure and cancellation model for K8s Jobs — how does `cancel(handle)` translate to a Job deletion, and does Job deletion guarantee cleanup of provisioned infrastructure or only the workload pod?

## Success Criteria

By the end of this spike:

- A working prototype of one MVP1 node deploying via a K8s Job exists in a K3s environment.
- The credential injection model for the K8s Job is documented and reviewed against FUSION security requirements (no secret in Job spec, no secret in log output).
- The output streaming model is validated end-to-end (Job log lines reaching the `AsyncIterable<OutputChunk>` consumer in Z-WORKER).
- An ADR is drafted documenting the chosen credential/state/streaming model and any constraints identified.
- Any required changes to the `ExecutionWorker` interface are identified and documented (interface changes require updating DECISION-0010).

## Suggested Approach

1. Stand up a local K3s environment (or use the existing Cove.GDIT lab EC2 K3s instance). Confirm `kubectl` and the K8s Jobs API are accessible from within the cluster.
2. Author a minimal K8s Job manifest that runs an Ansible playbook against a mock target. Confirm the Job completes and log output is retrievable via the K8s log streaming API.
3. Evaluate credential injection options: Kubernetes Secrets mounted as files (preferred — avoids env var exposure), Vault/OpenBao Agent sidecar injection (deferred to V1.SECRETS), or IAM roles for service accounts (IRSA on EKS; not available on bare K3s). Document the MVP1-viable option.
4. Implement a prototype `K8sJobWorker` class that implements the `ExecutionWorker` interface. Confirm all interface methods (`execute`, `cancel`, `streamOutput`, capability discovery) can be satisfied by the K8s Jobs API.
5. Run the prototype against the same test fixtures used by `MockWorker` to validate the interface is not Ansible-shaped (per DECISION-0010's second-consumer validation pattern).
6. Evaluate Pyinfra inside the same Job image. Document whether it requires a different base image or only different entrypoint configuration.
7. Stress-test cancellation: delete the Job mid-execution and observe whether the workload pod terminates and whether any side effects (partially provisioned resources) are observable.
8. Document all findings in an ADR draft.

## Expected Output

- A working prototype: one FUSION node deploying via K8s Job in a K3s environment (code in a spike branch, not production-merged).
- An ADR documenting: credential injection model, state-passing approach, output streaming approach, cancellation semantics, and any K3s-specific constraints.
- A written assessment of whether the `ExecutionWorker` interface requires changes and, if so, what the proposed change is.
- An estimate of the implementation effort for V1.EXEC.001 based on prototype learnings.

## Risks

- K3s-specific networking or RBAC constraints may make the K8s Jobs approach more complex than it appears in a full Kubernetes environment, requiring workarounds that complicate the V1 implementation.
- Secret injection without Vault/OpenBao (deferred to V1.SECRETS) may force a K8s Secrets approach that requires RBAC policy changes not yet modeled in the FUSION Helm chart.
- The `ExecutionWorker` interface may turn out to be Ansible-shaped in ways not visible until K8s Job dispatch is attempted — interface surgery would ripple into MVP1 code that has already been written.
- Output streaming via the K8s log streaming API may introduce latency or buffering behavior that diverges from the current subprocess pipe model, affecting the frontend deployment log experience.
- If Argo Workflows is anticipated (V1.EXEC.002), the prototype should avoid encoding assumptions that Argo would need to undo — but assessing that requires knowledge of Argo's Job model that may not be available during this spike.
