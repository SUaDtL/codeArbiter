# Spike 1: Git Provider Abstraction

**Time-box:** 3-5 days (24-40 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** Stage 2 promotion review; first customer engagement requiring a non-Gitea Git provider; re-evaluation of DECISION-0004 (STACK.LIBRARY.GIT-PROVIDER-ABSTRACTION)

## Context

DECISION-0003 adopted Gitea as the bundled Git provider for MVP1 and established five evolvability-groundwork conventions (single-module client, semantic domain types, webhook normalization at the edge, provider-neutral env-var naming, and provider audit tag) to keep future provider swaps tractable without committing to a multi-provider abstraction now.

DECISION-0004 explicitly deferred the multi-provider abstraction (`GitProvider` interface, provider-selection UI, multi-provider adapters) until either a customer signals a non-Gitea requirement or Stage 2 promotion is reached. The deferral was made because building an abstraction against one concrete implementation risks encoding Gitea-specific assumptions into the interface shape — a known anti-pattern. Webhook signature schemes, branch-protection contracts, and audit-event payload shapes differ materially across providers (Gitea shared-secret header, GitHub HMAC-SHA-256, GitLab token header).

This spike investigates what the `GitProvider` abstraction interface should look like when that trigger fires, so the design work is done before sprint planning must commit to it.

## Questions to Answer

1. Do the five evolvability-groundwork conventions from DECISION-0003 (single-module client, domain types at service boundary, webhook normalization, provider-neutral env vars, provider audit tag) provide sufficient seams for a clean provider swap, or do gaps exist in the current module structure?
2. What is the correct shape of a `GitProvider` interface that can support Gitea, GitHub Enterprise, and GitLab without leaking provider-specific types into callers?
3. How should webhook signature verification be handled in a multi-provider model — provider-specific verifier per normalizer, or a unified verification abstraction?
4. What is the audit normalization contract for provider-specific webhook payloads — which fields are mandatory in the domain event regardless of provider, and which are provider-specific extensions?
5. Can branch-protection contract unification (Gitea API vs. GitHub branch-protection rules vs. GitLab merge-request approvals) be expressed in a single `GitProvider` interface operation, or does it require per-provider policy configuration?
6. What is the estimated port effort to add a second provider (e.g., GitHub Enterprise) behind the abstraction once the groundwork conventions are in place, versus without them?
7. Are there security or trust-zone implications to adding provider selection as a runtime configuration (versus build-time selection)?

## Success Criteria

By the end of this spike:

- A concrete interface shape for `GitProvider` is documented and validated against at least two provider APIs (Gitea and one of GitHub Enterprise or GitLab).
- The adequacy of the five groundwork conventions from DECISION-0003 is evaluated — either confirmed sufficient or specific gaps are identified and remediation steps are proposed.
- The webhook signature verification approach for a multi-provider model is decided.
- An ADR is drafted (or the existing DECISION-0004 entry is annotated) capturing the chosen abstraction shape, its rationale, and any interface evolution triggers.

## Suggested Approach

1. Review the five evolvability-groundwork conventions established in DECISION-0003 against the current `backend/src/library/git-client.ts` implementation. Map each convention to its concrete seam in the module structure.
2. Survey Gitea API documentation for webhook payload shape and signature verification scheme. Do the same for GitHub Enterprise (webhook secret + HMAC-SHA-256) and GitLab (X-Gitlab-Token header or signature).
3. Prototype a `GitProvider` TypeScript interface with the operations already required by MVP1 code: repository creation, branch creation, webhook normalization, and the branch-protection operations called by sync logic. Keep the interface to operations actually exercised — do not design ahead of usage.
4. Implement a lightweight `GitHubEnterpriseProvider` stub (or a `GitLabProvider` stub) against the proposed interface. Document every place where a Gitea-specific assumption surfaced and how the interface shape had to change to accommodate it.
5. Evaluate the webhook normalization seam: can a `normalizeWebhook(provider: string, raw: unknown): DomainWebhookEvent` function handle both Gitea and GitHub payloads cleanly, or does each provider need its own normalizer registered by provider tag?
6. Review the audit provider-tag convention (`git.provider: "gitea"`) — confirm it is sufficient for multi-provider audit correlation or identify additional fields required.
7. Produce an interface shape document and annotate DECISION-0004 with the findings.

## Expected Output

- A draft `GitProvider` TypeScript interface (file path: `backend/src/library/git-provider.ts` or equivalent) ready for review — not production code, but interface-validated against two providers.
- A short written assessment of whether the five groundwork conventions from DECISION-0003 are sufficient seams for the swap.
- An updated or new ADR (or annotation to DECISION-0004) capturing the chosen interface shape, webhook normalization approach, and remaining open questions.
- Estimated port effort for adding a second provider with the abstraction in place.

## Risks

- The spike may reveal that the groundwork conventions require retrofitting in existing MVP1 code before the abstraction is viable — this would expand scope beyond investigation into remediation work.
- GitHub Enterprise and GitLab webhook signature schemes may require platform-specific secret-handling paths that intersect with FIPS cryptography requirements (HMAC-SHA-256 must use the FIPS provider) — this could block the design until `docs/security-controls.md` and `docs/secrets-and-keys.md` are consulted.
- If the spike is deferred past Stage 2 promotion, the first customer with a non-Gitea requirement may arrive before the interface shape is ready, forcing a rushed design under delivery pressure.
- The interface shape is only validated by a stub implementation during the spike. Correctness of the abstraction will not be confirmed until a full second-provider implementation is built.
