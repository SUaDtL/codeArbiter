
# Spike 3: OpenBao Integration

**Time-box:** 1-2 weeks (40-80 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** V1.SECRETS.001 (Bundle OpenBao in FUSION Helm chart); V1.SECRETS.002 (OpenBao client in Z-API); V1.SECRETS.003 (Migrate environment profile secrets to OpenBao); V1.SECRETS.004 (IAM role-based AWS credentials); V1.SECRETS.005 (Secret rotation policies)

## Context

At MVP1, FUSION's `secret_ref` values point at AWS Secrets Manager ARNs. The `resolveSecretRef()` helper in `backend/src/secrets/resolver.ts` calls AWS Secrets Manager today. DECISION-0019 (PATTERN.ENVIRONMENT-PROFILE) established the `secret_ref` interface as an abstraction boundary, explicitly noting that after OpenBao is bundled at V1+, the ref shape may extend — and that the abstract `secret_ref` resolver is designed to accommodate a future OpenBao implementation via a swap of the resolver body.

V1.SECRETS.001 through V1.SECRETS.005 form the full OpenBao integration work, but none of these tasks can be scoped or started until the integration mechanics are understood. Key unknowns include: how OpenBao is packaged in a Helm subchart alongside FUSION services, how auto-unseal is configured in the K3s environment, how the `secret_ref` path format changes when pointing at OpenBao versus AWS Secrets Manager, and how secret rotation policies interact with the existing audit event obligations.

This spike investigates the OpenBao deployment model, API surface, and integration contract so that V1.SECRETS.001-005 can be refined into implementable tasks with accurate effort estimates.

## Questions to Answer

1. What is the correct Helm packaging model for OpenBao — subchart within `helm/fusion/` or a standalone chart dependency — and what are the persistent storage requirements in K3s?
2. What auto-unseal mechanism is viable for the Cove.GDIT K3s environment: AWS KMS auto-unseal (requires IAM), Transit auto-unseal (requires another Vault/Bao instance), or manual unseal with operator intervention at startup?
3. How should the `secret_ref` path format be structured for OpenBao paths — is there a breaking change from the current AWS Secrets Manager ARN format, and how should the resolver distinguish between the two during a migration period?
4. What authentication method should Z-API use to authenticate to OpenBao: Kubernetes auth (service account JWT), AppRole, or another method compatible with K3s service accounts?
5. What Vault/OpenBao policy model should FUSION adopt — one policy per service, one policy per secret kind, or a role-per-deployment model that grants scoped access to environment-specific secrets?
6. What does secret rotation look like for OpenBao-managed credentials — does OpenBao handle rotation natively (dynamic secrets), or does FUSION need to implement rotation scripts and call the OpenBao API?
7. What audit events must be emitted when a secret is read via OpenBao, and does OpenBao's own audit log satisfy the Z-AUDIT obligation or must FUSION emit its own events in addition?
8. What are the FIPS 140-3 implications of running OpenBao in the FUSION environment — does OpenBao use a FIPS-approved cryptographic provider, and if not, what mitigations are required?

## Success Criteria

By the end of this spike:

- OpenBao is deployed in a K3s environment via a Helm subchart and survives a restart (auto-unseal validated or manual unseal procedure documented).
- Z-API can authenticate to OpenBao using the chosen auth method and read a test secret, with a Z-AUDIT event emitted for the read.
- The `secret_ref` path format for OpenBao is defined and documented, including how the resolver distinguishes OpenBao refs from AWS Secrets Manager ARNs during the migration period.
- The FIPS posture of OpenBao in the FUSION environment is assessed and any gaps are documented.
- An ADR is drafted covering the deployment model, auth method, policy model, rotation approach, and audit obligations.

## Suggested Approach

1. Review the OpenBao project documentation and the FUSION `docs/secrets-and-keys.md` requirements to identify all constraints before touching any code.
2. Author a minimal Helm subchart for OpenBao with persistent volume configuration for K3s. Deploy it in the lab environment and confirm the instance reaches a sealed state.
3. Evaluate auto-unseal options in the Cove.GDIT K3s environment. If AWS KMS is available via the EC2 instance role, test KMS auto-unseal. Document the result and fall-back options.
4. Configure the Kubernetes auth method in OpenBao. Create a policy granting read access to a test secret path. From a pod using a K3s service account, authenticate and read the secret. Confirm Z-AUDIT event emission.
5. Test the `resolveSecretRef()` resolver with an OpenBao path (swap the body as described in DECISION-0019's implementation note). Confirm the resolver returns the correct secret value and emits the audit event. Confirm the existing AWS Secrets Manager path still works.
6. Define the `secret_ref` path format convention: propose a URI scheme that distinguishes providers (e.g., `bao://path/to/secret` vs. `asm://arn:aws:secretsmanager:...`) and document it for inclusion in `docs/secrets-and-keys.md`.
7. Assess the FIPS posture: determine what cryptographic provider OpenBao uses by default and whether it can be configured to use only FIPS-approved primitives. Document findings for the security reviewer.
8. Prototype a secret rotation trigger for one credential type. Confirm that rotation emits the expected audit event.

## Expected Output

- A working OpenBao Helm subchart prototype (spike branch, not production-merged) that deploys in K3s with auto-unseal configured or documented.
- A defined `secret_ref` path format convention for OpenBao paths, ready for inclusion in `docs/secrets-and-keys.md`.
- An ADR draft covering: Helm packaging model, auto-unseal approach, Z-API auth method, policy model, rotation approach, audit obligations, and FIPS assessment.
- Refined effort estimates for V1.SECRETS.001-005 based on prototype learnings.

## Risks

- Auto-unseal via AWS KMS requires the EC2 instance role to have KMS permissions — if these are not available in the Cove.GDIT lab environment, auto-unseal may not be achievable without operator intervention at startup, which affects the production deployment model.
- OpenBao may not have a FIPS-validated cryptographic provider, which could require a compensating control or a blocker escalation before OpenBao can be used in a CUI environment (Stage 3+).
- The Kubernetes auth method in K3s uses a different service account token format from standard Kubernetes, which may require K3s-specific configuration that is not documented in the OpenBao auth method documentation.
- The migration from AWS Secrets Manager to OpenBao for existing MVP1 `secret_ref` values requires careful path-format design — a poorly chosen format may force a second migration at Stage 3.
- The audit obligation for secret reads (Z-AUDIT `secret.resolved` event) may interact with OpenBao's own audit sink configuration in ways that produce duplicate or missing audit records.
