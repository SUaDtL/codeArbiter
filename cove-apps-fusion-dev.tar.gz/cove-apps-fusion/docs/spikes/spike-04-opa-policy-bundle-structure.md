# Spike 4: OPA Policy Bundle Structure

**Time-box:** 1-2 weeks (40-80 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** V1.AUTH.001 (DA group management UI); V1.AUTH.002 (DA-aligned access policies); V1.AUTH.003 (Environment-scoped OPA policies); V1.AUTH.004 (OKTA federation in Keycloak)

## Context

DECISION-0007 (STACK.AUTH.AUTHORIZATION) adopted OPA as the authorization engine with a phased policy build: MVP1 ships one bundle (a default-deny policy for Z-API write routes), and V1 expands to per-DA group policies, environment-scoped policies, and cross-DA access grants. The `authz.can()` helper and the Fastify `preHandler` wiring (DECISION-0026) are in place from MVP1, but all V1 policy surface expansion depends on a clear bundle structure that has not yet been designed.

V1.SPIKE.004 in the task backlog calls for a spike to define the policy bundle template: file organization, package naming conventions, test patterns, and the integration approach between the bundle and Fastify. The spike must also document the policy update flow (how bundles are updated without restarting the Fastify server) and how policy decisions integrate with the Z-AUDIT audit trail.

Additionally, the task backlog notes at MVP1.AUTH context that "Spike 4 validates the bundle structure. MVP1 uses a simplified version; full structure follows post-spike." This means the MVP1 simplified policy exists but its organization may not scale to the V1 multi-DA, multi-environment policy surface — the spike determines whether it does or requires restructuring.

## Questions to Answer

1. What is the correct OPA package namespace hierarchy for FUSION policies — should packages be organized by resource type (`authz.solutions`, `authz.nodes`), by DA (`authz.da.<name>`), by operation (`authz.write`, `authz.deploy`), or some other scheme?
2. How should policy files be organized within the bundle directory — one file per resource type, one file per DA, or a flat structure with named rules?
3. What is the policy update flow: does OPA poll a bundle endpoint (OPA bundle API), does FUSION restart OPA on policy change, or does FUSION use the OPA REST API to load updated policies? What are the availability implications for each approach?
4. How do per-DA group memberships (stored in the FUSION DB) flow into OPA policy decisions — as input data in the `authz.can()` call, as a data bundle loaded alongside the policy bundle, or via OPA's external data mechanism?
5. What is the test pattern for Rego policies in the FUSION codebase — where do `.rego` test files live, how are they run in CI, and what coverage obligation applies?
6. How should OPA policy decisions integrate with Z-AUDIT — should every `authz.can()` call emit a Z-AUDIT event, only denials, or only denials for auditable operations? What fields does the event require?
7. What is the rollout model for policy changes in production — canary evaluation, policy simulation (OPA's `explain` mode), or a separate staging bundle? Is a policy rollback mechanism needed?
8. Can the MVP1 simplified bundle be refactored into the V1 structure non-destructively, or does the V1 structure require a breaking change to package naming that would invalidate existing `authz.can()` call sites?

## Success Criteria

By the end of this spike:

- A concrete policy bundle template is defined: directory structure, package naming convention, and at least one example policy per major resource type (solution, node, adapter, environment).
- OPA test patterns are validated and a test fixture for the CI pipeline is demonstrated.
- The policy update flow is chosen and its availability implications are documented.
- The DA group data integration approach (how group membership flows into policy input or data) is decided.
- The Z-AUDIT integration for policy decisions is specified — what events are emitted and with what fields.
- An ADR is drafted covering all of the above.

## Suggested Approach

1. Review the existing MVP1 OPA bundle (`authz.can()` helper implementation and any existing `.rego` files) to understand the current package namespace and rule structure.
2. Survey OPA documentation for bundle organization best practices, especially for multi-tenant access control models with external group data.
3. Design a package namespace hierarchy that accommodates: resource-type-scoped rules, DA-scoped rules, environment-scoped rules, and future tenant-scoped rules (per DECISION-0011's multi-tenant hedge). Validate that the hierarchy is parseable by OPA's module system without conflicts.
4. Write three example policies: (a) default-deny for all Z-API write routes, (b) DA membership gate for node/adapter access, (c) environment-scoped deploy gate. Confirm each policy passes `opa test` with test cases covering allow and deny paths.
5. Evaluate the policy update flow. Prototype the OPA bundle API polling approach (OPA fetches from a configured bundle endpoint on a poll interval) and confirm that a policy update does not drop in-flight `authz.can()` calls.
6. Define the DA group data input contract: document the exact JSON shape of the `input` object passed to OPA from the `authz.can()` helper, including group membership data sourced from the FUSION DB.
7. Draft the Z-AUDIT integration: identify which `authz.can()` outcomes require audit events, define the event fields (at minimum: `action`, `outcome`, `subject`, `resource`, `policy_package`), and confirm alignment with `docs/audit-spec.md`.
8. Evaluate whether the MVP1 bundle can be migrated to the V1 structure without changing the `authz.can()` call signature. Document any breaking changes.

## Expected Output

- A policy bundle template: directory structure and at least three example policies with passing OPA tests.
- An ADR documenting: package namespace convention, policy update flow, DA group data integration approach, Z-AUDIT integration spec, and rollout/rollback model.
- A CI test pattern for Rego policies that can be incorporated into the FUSION pipeline.
- Assessment of whether the MVP1 bundle requires restructuring and, if so, a migration plan.

## Risks

- The DA group data integration approach (passing group membership into OPA input versus using OPA's external data bundle mechanism) has performance implications at scale — choosing the wrong approach at V1 may require a disruptive rewrite at Stage 3.
- OPA bundle polling introduces a configuration endpoint that must be secured; if the bundle endpoint is not authenticated, policy files could be replaced by an attacker. The security design of the bundle update endpoint must be reviewed before the polling approach is adopted.
- Rego's package system does not enforce naming conventions — a convention adopted now may be violated by contributors unfamiliar with it. A CI lint step for Rego package naming may be required to make the convention enforceable.
- The MVP1 simplified bundle may have assumptions baked into the `authz.can()` helper (e.g., a hardcoded package path like `data.authz.allow`) that would require changes to the helper when the V1 namespace is adopted — these changes would affect every Z-API route using the preHandler.
- If the policy update flow requires OPA to restart to pick up new bundles, a restart window exists during which authorization decisions may be unavailable — this affects the Z-API availability SLA and must be documented.
