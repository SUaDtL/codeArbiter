# Spike 6: Pin Health Monitoring

**Time-box:** 1-2 weeks (40-80 hours)
**Owner:** [TBD — assign before sprint planning]
**Status:** Not started
**Unblocks:** V1.PIN.001 (AMI availability check pipeline); V1.PIN.002 (Container image availability check pipeline); V1.PIN.003 (Helm chart availability check pipeline); V1.PIN.004 (Pre-deploy pin verification); V1.PIN.005 (Age-tiered deployment gates); V1.PIN.006 (Broken-pin notification routing)

## Context

DECISION-0013 (PATTERN.PIN-WITH-MONITORING) adopted the pin metadata schema at MVP1: `pinned_artifacts` (JSONB), `solution_last_tested`, `solution_age_status`, and `pin_health_status` columns on the `solutions` table. The `pinned_artifacts` JSON shape includes a `pin_protocol_version` MOSA hedge to reserve the format-evolution lane. At MVP1, these columns are populated as default-unknown/default-green; the V1.PIN.* tasks that flip them to accurate states are explicitly deferred.

V1.SPIKE.005 in the task backlog calls for a spike to validate the pin-monitoring CI/CD integration before V1.PIN.* work begins. The spike must produce: a working pin check pipeline for at least one pin type (AMI, container image, or Helm chart), a validated notification flow, and an ADR documenting the credential and notification routing model. All V1.PIN.* tasks depend on this spike.

The pin-monitoring model is architecturally significant: it is FUSION's primary argument against needing a separate artifact archive. If pin checks can verify artifact availability on demand without storing artifacts locally, the archive infrastructure is unnecessary. If they cannot, the archive decision must be revisited. This spike determines whether the pin-check-without-archive model is viable.

## Questions to Answer

1. What credentials are required to check AMI availability (AWS EC2 API), container image availability (container registry API), and Helm chart availability (chart repository API), and how are these credentials sourced without storing them as static secrets?
2. What is the scheduling model for pin health checks — a Graphile Worker recurring job (per DECISION-0002's job queue adoption), a Kubernetes CronJob, or a cron expression within the FUSION backend? What is the appropriate check interval?
3. When a pin check fails (AMI deprecated, container image SHA not found, chart version yanked), what is the exact state machine transition: which `pin_health_status` enum value is set, which Z-AUDIT event is emitted, and what triggers the notification?
4. What is the notification routing model: how does FUSION know which channel to notify for a given solution's broken pin (in-app only, email, webhook, configurable per-solution)? What is the data model for notification preferences?
5. How does the pre-deploy pin verification (V1.PIN.004) integrate with the deployment dispatch flow — is it a synchronous gate in the Z-API route handler, or an asynchronous pre-flight check that blocks the Z-WORKER job submission?
6. What is the `pin_protocol_version` evolution story: when a new artifact kind or new pinned field needs to be added, how does the `pinned_artifacts` JSONB shape extend, and how does the pin check pipeline handle entries with different protocol versions in the same `pinned_artifacts` array?
7. Is the pin-check-without-archive model viable for all supported artifact kinds, or are there artifact types (e.g., custom AMIs that may be deregistered without notice) where the model breaks down and archive infrastructure becomes necessary?
8. What is the age-tier computation model (V1.PIN.005) — is `solution_age_status` computed at query time from `solution_last_tested`, updated by a background job, or stored as a materialized column updated on write?

## Success Criteria

By the end of this spike:

- A working pin check pipeline exists for at least one artifact kind (AMI, container image, or Helm chart) that reads the `pinned_artifacts` column, queries the relevant registry or API, and updates `pin_health_status`.
- The notification routing flow is validated end-to-end: a broken pin triggers an in-app notification (at minimum) and the Z-AUDIT event is confirmed to contain the required fields.
- The credential sourcing model for registry checks is documented and reviewed against FUSION secrets requirements.
- The `pin_protocol_version` evolution scenario is documented: what a `pin_protocol_version: 2` entry looks like and how the pipeline handles mixed-version arrays.
- An ADR is drafted covering: scheduling model, credential sourcing, state machine transitions, notification routing, pre-deploy gate integration, and the pin-check-without-archive viability assessment.

## Suggested Approach

1. Review the `pinned_artifacts` Zod schema in `backend/src/db/types/pinned-artifacts.ts` (authored per DECISION-0013). Confirm the `pin_protocol_version` field is present and understand the current artifact kind enumeration.
2. Choose one artifact kind for the prototype. AMI is recommended: AWS EC2 `describe-images` API call is simple, the response is deterministic, and the credential model (IAM role on the EC2 instance) is already in scope for FUSION's hosting model.
3. Author a Graphile Worker job that: (a) queries `solutions` for rows where `pinned_artifacts` contains an entry of the chosen kind, (b) calls the relevant registry API, (c) updates `pin_health_status` to `degraded` if any artifact is unavailable, and (d) emits a Z-AUDIT event per the spec.
4. Confirm the IAM credential model: the FUSION EC2 instance role should have `ec2:DescribeImages` permission. If it does not, document the required IAM policy addition and test with a mock that simulates the API response.
5. Implement the notification path for a broken pin: update the `pin_health_status` column and confirm that the in-app notification mechanism (V1.UI.004 WebSocket push, if available, or a polling fallback) surfaces the change to the solution owner.
6. Prototype a `pin_protocol_version: 2` test entry with an additional field (e.g., `provenance_attestation_uri`). Confirm the pipeline handles it without failing on `pin_protocol_version: 1` entries in the same array.
7. Prototype the pre-deploy pin gate: add a synchronous check in the deployment dispatch path that reads `pin_health_status` and returns a 409 or equivalent error if any pin is `degraded`. Confirm the error message reaches the frontend deployment log.
8. Assess the archive viability question: are there artifact kinds in the current backlog where pin-check-without-archive would fail? Document findings in the ADR.

## Expected Output

- A working pin check pipeline for one artifact kind (spike branch, not production-merged) that populates `pin_health_status` from real registry data and emits a Z-AUDIT event.
- A validated notification flow: broken pin -> Z-AUDIT event -> in-app notification (or documented substitute).
- An ADR covering: scheduling model, credential sourcing, state machine transitions, notification routing, pre-deploy gate integration approach, `pin_protocol_version` evolution model, and archive viability assessment.
- Refined effort estimates for V1.PIN.001-006 based on prototype learnings.

## Risks

- AWS IAM permissions in the Cove.GDIT lab environment may not include the registry-query permissions needed for the prototype (e.g., `ec2:DescribeImages`, `ecr:DescribeImages`). If the instance role lacks these permissions, the prototype must use mocks, which reduces confidence in the credential model.
- Container registry pin checks against external registries (Docker Hub, Quay.io) may require credentials even for public images — this would introduce an external credential dependency not currently modeled in the FUSION secrets architecture.
- The `pin_health_status` state machine has only three states (`healthy | degraded | unknown`) at MVP1. If the spike reveals that more granular states are needed (e.g., distinguishing `not-found` from `network-error`), a schema migration would be required — retroactively changing the enum at V1 affects existing rows.
- The notification routing model (how FUSION knows which channel to notify for a given solution) requires a notification preferences data model that has not been designed. If V1.UI.004 (WebSocket push) is not complete when this spike runs, the notification path cannot be fully validated.
- If the archive viability assessment concludes that archive infrastructure is necessary for some artifact kinds, the V1.PIN.* scope expands significantly — V1.PIN tasks would need to be re-estimated and the archive infrastructure would need to be added to the V1 backlog.
