# FUSION Arbiter — Decision Log

This file is the persistent, strictly append-only record of arbitration decisions made during reconciliation between the FUSION architectural artifacts and the project scaffold.

**Append-only with no exceptions.** Prior entries are never edited. To supersede a prior decision, append a new entry whose `Supersedes:` field references the prior entry. Forward traversal from old to new entries is the only supported lookup pattern.

**Maintained by:** the `fusion-arbiter` skill, in collaboration with the user.

---

## DECISION-0001 — STACK.BACKEND.VALIDATION — Register Zod schemas on every Fastify route (close F-019)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.BACKEND.VALIDATION
**Artifact-section-hash:** 69536e272ba5e292d9283216486705b665174b706df5fb5e3761b4f99f894745

### Variance summary

- **Artifact position:** Every route must register Zod schemas for both request body AND response (Doc 1 §3.2 / F-019); without this, Fastify's `fast-json-stringify` does not strip undeclared response fields.
- **Scaffold position:** Routes use manual `safeParse`/`parse` inside handlers (`solutions.ts`, `deployments.ts`) but no route registers `schema:` on its Fastify route definition; F-019 still flagged in CHANGELOG `[Unreleased]`.
- **Status type:** divergent

### Decision

Adopt the artifact position. Sweep all backend routes to register `schema: { body, response }` using Zod-derived JSON Schema. Add a CI gate (tracked separately as `CI.ZOD-ROUTE-COVERAGE`) that fails PRs which add a route handler without registered schemas. Close F-019 in CHANGELOG `[Unreleased]` once the sweep lands.

### SMARTS rationale

Maintainable, Reliable, and Securable all favor the artifact position strongly. Single-source schema registration eliminates the drift risk between manual `parse` and decorator-style validation, closes the response-leak path that `fast-json-stringify` would otherwise mask, and satisfies SI-10 and SC-8 expectations for ATO posture. CLAUDE.md §0 places security-compliance (level 1) above ergonomics (level 5), which breaks the tie against the hybrid response-only option.

### Implementation implication

Sweep `backend/src/routes/*.ts` to add Fastify `schema:` options on every route definition. Wire `zod-to-json-schema` (or equivalent) so JSON Schema is derived from existing Zod schemas without duplication. Add a Semgrep or vitest-based gate enforcing route-schema coverage; CI gate work is captured as `CI.ZOD-ROUTE-COVERAGE` (a separate variance pending arbitration). Update CHANGELOG `[Unreleased]` to record F-019 closure when the sweep lands.

---

## DECISION-0002 — STACK.JOB-QUEUE — Adopt Graphile Worker for Z-WORKER

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.JOB-QUEUE
**Artifact-section-hash:** cd0cdb9409cbbfe346c4dfdc8fa5990fd05ae0a1a61b4d68bafb65bf7479b809

### Variance summary

- **Artifact position:** Graphile Worker — Postgres-backed job queue, no extra infrastructure (Doc 1 §3.4 + §5 LOCKED; Task Backlog MVP1.DB.012).
- **Scaffold position:** Silent — no `graphile-worker` dependency, no Z-WORKER service, no job table.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position. Add `graphile-worker` to the backend dependencies, run its migration to create the `graphile_worker.*` schema in the bundled Postgres, and scaffold the Z-WORKER service skeleton so deployment dispatch (MVP1.API.011) and output streaming (MVP1.API.013) are unblocked.

### SMARTS rationale

Maintainable, Available, Reliable, and Testable all favor building over deferring. Graphile Worker reuses the bundled Postgres, preserving the self-contained mandate; ACID job state under Postgres availability gives deterministic retries; Testcontainers makes the integration testable without new infrastructure. The artifact evaluated no alternative because the choice is structurally tied to Postgres bundling.

### Implementation implication

Add `graphile-worker` dependency (vet via dependency-reviewer subagent and `make license-scan`). Add the migration to `backend/drizzle/migrations/` with classification tagging per CLAUDE.md §10 — note this directory has Edit-deny in `.claude/settings.json`, so the migration commit goes through CODEOWNERS. Build a thin `Z-WORKER` service module under `backend/src/worker/` exposing `enqueue(taskName, payload)` and a small worker bootstrap. Update Helm chart (DEPLOY.HELM-CHART) to include the worker process when that variance is arbitrated.

---

## DECISION-0003 — STACK.LIBRARY.GIT — Bundle Gitea with configurable connection target, plus evolvability groundwork

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.LIBRARY.GIT
**Artifact-section-hash:** b765a638b595403d42b8085e54410042513d591610479212fc13905b7612ca33

### Variance summary

- **Artifact position:** Gitea bundled — self-hostable, MIT, used as the runtime library backing for nodes, adapters, policies, schemas, and per-solution repos (Doc 1 §3.7 + §5 LOCKED; Task Backlog MVP1.LIB.001).
- **Scaffold position:** `.gitea/workflows/ci-linux.yml` exists for CI but Gitea is not deployed as a runtime bundled service; no `helm/fusion/gitea/` chart, no container reference, no DB sync wiring.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with a configurable connection target. FUSION's Helm chart bundles a Gitea instance as the default; the FUSION application accepts `GIT_URL` and `GIT_TOKEN` (and provider-tag `GIT_PROVIDER=gitea`) so the same FUSION deployment can point at the bundled Gitea, an externally-deployed Gitea instance, or — once `STACK.LIBRARY.GIT-PROVIDER-ABSTRACTION` is decided — a different provider entirely. The bundled Gitea remains the only supported provider in MVP1.

To preserve evolvability without committing to a multi-provider abstraction, the implementation MUST also adopt these five evolvability-groundwork conventions from day 1:

1. **Single-module Gitea client.** All HTTP calls to Gitea live in one module (`backend/src/library/git-client.ts` or equivalent). No Gitea API calls in route handlers, services, or sync logic.
2. **Semantic domain types at the service boundary.** Service layer returns FUSION domain types (`Repository`, `Branch`, `PullRequest`, `Commit`), not Gitea-shaped response types. Gitea-specific types stay inside the client module.
3. **Webhook normalization at the edge.** Inbound Gitea webhooks normalize into domain events (`PullRequestMerged`, `BranchPushed`, etc.) at the request handler. Downstream sync logic operates on domain events, never on raw provider payloads.
4. **Provider-neutral env-var naming.** `GIT_PROVIDER`, `GIT_URL`, `GIT_TOKEN` (and any later additions). No `GITEA_*` operator-facing config.
5. **Audit provider tag.** Every Z-AUDIT event that references a Git operation includes `git.provider: "gitea"` (or future provider value) per `docs/audit-spec.md` extension rules.

### SMARTS rationale

Reliable and Securable favor adopting the artifact position: branch protection at Gitea API level, webhook-driven DB cache, and Git-authoritative source-of-truth contract are preserved. The configurable-target enhancement (vs. hardcoded localhost) has zero SMARTS cost — same provider, same API, just a deployment-shape question. The five groundwork conventions trade ~50–100 lines of types and one normalization function (small Maintainable cost today) for substantial Maintainable + Scalable leverage later: the future cost of evaluating GitHub Enterprise / GitLab support shrinks from "rewrite consumers across the codebase" to "replace one client module + add a webhook normalizer." None of the groundwork introduces new auth boundaries, crypto, or trust-zone crossings — Securable posture is unchanged.

### Implementation implication

- Add `helm/fusion/gitea/` subchart bundling Gitea with persistent volume; default values bring up an instance during `helm install`.
- Under `backend/src/library/`, create `git-client.ts` (encapsulates Gitea HTTP API), `types.ts` (FUSION domain types: `Repository`, `Branch`, `PullRequest`, `Commit`, `Webhook`), and `webhook-normalize.ts` (Gitea payload → domain event).
- Update `backend/src/config.ts` (or equivalent) to source `GIT_PROVIDER`, `GIT_URL`, `GIT_TOKEN` from env. Default `GIT_URL` to the bundled Gitea service DNS when running under Helm.
- Extend `docs/audit-spec.md` to register `git.provider` as an optional field on all library-related audit events.
- Update Helm chart (DEPLOY.HELM-CHART, when arbitrated) to wire the `GIT_URL` to the bundled service by default, with override capability via Helm values.
- DB sync wiring (`STATE.DB-GIT-SYNC`) consumes the normalized domain events, not raw Gitea webhook payloads.

---

## DECISION-0004 — STACK.LIBRARY.GIT-PROVIDER-ABSTRACTION — Defer multi-provider abstraction; revisit at Stage 2 or first non-Gitea customer

**Date:** 2026-05-07
**Status:** deferred
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.LIBRARY.GIT-PROVIDER-ABSTRACTION
**Artifact-section-hash:** n/a

### Variance summary

- **Artifact position:** None. Architecture Breakdown §3.7 + §5 LOCKED Gitea as the bundled provider; the artifact does not contemplate multi-provider support.
- **Scaffold position:** None — scaffold has no Git provider integration at all yet.
- **Status type:** artifact-silent (raised by user during arbitration as forward-looking concern: customer adoption patterns include teams with existing GitHub Enterprise / GitLab / Bitbucket deployments).

### Decision

Defer. Do not build a `GitProvider` interface, multi-provider adapters, or provider-selection UI in MVP1. Reasons: (a) scaffold has no second provider to validate the abstraction shape, (b) the abstraction would force defense-grade webhook signature verification, audit normalization, and branch-protection contract unification across heterogeneous provider APIs — substantial Securable/Reliable work that competes with MVP1 closure, (c) the LOCKED Gitea choice in the artifact reflects the MVP1 scope mandate (internal team, single bundled provider). The five evolvability-groundwork conventions adopted in DECISION-0003 are sufficient to make this future decision tractable without committing to its shape now.

### SMARTS rationale

Securable and Reliable strongly oppose building a multi-provider abstraction now: each provider has its own webhook signature scheme (Gitea shared-secret header vs. GitHub HMAC-SHA-256 vs. GitLab token header), branch protection contract (Gitea API vs. GitHub branch-protection rules vs. GitLab merge-request approvals), and audit-event payload shape — normalizing these without a second concrete implementation guarantees the abstraction will be wrong. Maintainable also opposes premature abstraction (interface-against-one-example anti-pattern). Scalable is the only lens that mildly favors building now (adoption flexibility); CLAUDE.md §0 places maintainability and securability above developer/customer ergonomics. The groundwork conventions adopted in DECISION-0003 capture the cheap optionality without the cost.

### Implementation implication

No scaffold change required. The five groundwork conventions in DECISION-0003 are the implementation hedge against this future decision. When the trigger fires, the arbiter re-opens this decision with full SMARTS analysis, evaluates the second concrete provider against the groundwork-shaped seams, and either (a) replaces DECISION-0003's single-provider scope or (b) augments the implementation with a second provider adapter.

### Re-evaluation trigger

Either of the following events triggers a re-evaluation of this decision:

1. **Customer signal:** First customer engagement where the customer requires FUSION to integrate with a non-Gitea Git provider (GitHub Enterprise, GitLab, Bitbucket Server, or other) as the library backing.
2. **Stage promotion:** Stage 2 promotion review — at Stage 2 (Internal MVP, first non-team GDIT user), evaluate whether the customer/user surface area still tolerates Gitea-only.

Either event causes the arbiter to surface this entry for re-evaluation in the next arbitration session.

---

## DECISION-0005 — STACK.IAC.INFRASTRUCTURE — Defer OpenTofu provider declaration until first node authoring

**Date:** 2026-05-07
**Status:** deferred
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.IAC.INFRASTRUCTURE
**Artifact-section-hash:** fb346f0c8c23f4389aa0430beb8b164652eda259696ba62acbcc40c8a5211f44

### Variance summary

- **Artifact position:** OpenTofu (MPL 2.0) is the LOCKED IaC tool for AWS provisioning (Doc 1 §5).
- **Scaffold position:** `terraform/main.tf` exists but defines no resources; no provider configuration; `Makefile` references `tofu` CLI in `deploy-stage`/`deploy-prod` targets (not yet wired).
- **Status type:** scaffold-silent

### Decision

Defer scaffold population. The OpenTofu tool/language choice is already locked by the artifact and is not at issue; the only open question is *when* to populate `terraform/main.tf` with provider configuration. A bare AWS provider block at the root before any node exists is bookkeeping with no architectural value — the real provider/module shape comes from the first FUSION node's IaC contract. No scaffold change today.

### SMARTS rationale

Every lens is Indifferent or Adequate in either direction. Maintainable slightly favors deferral because populating before having a concrete consumer risks committing to a root-level structure that the first real node makes obviously wrong. Testable slightly favors building (`tofu init` could validate sooner), but the gain is minimal at Stage 1. The choice is sequencing, not architecture, so the deferral is genuine — there is nothing to arbitrate today.

### Implementation implication

No scaffold change required now. When the first node-authoring task fires the re-evaluation trigger, evaluate the IaC structure against MOSA principles per `feedback_mosa_evolvability.md`: each fusion-node likely owns its own `main.tf`, with the FUSION root holding only minimal orchestration (provider versions, shared backend config). Pre-baking the modular boundary at first-node time is preferable to retrofitting a centralized root-level structure later.

### Re-evaluation trigger

Either of the following events triggers a re-evaluation of this decision:

1. **First node authoring:** Start of work on `MVP1.DEMO.001` or any task that authors a FUSION node with `main.tf` content. The arbiter re-opens this entry to capture the chosen IaC structure (root vs. node-level encapsulation).
2. **Deployment-target work:** Start of work on any task under MVP1.EXEC.004 or DEPLOY.AWS-TARGET that requires AWS provider configuration to be live.

Either event surfaces this entry for re-evaluation in the next arbitration session.

---

## DECISION-0006 — STACK.IAC.K8S-DEPLOY — Author MOSA-shaped Helm chart skeleton with subchart-per-bundled-service

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.IAC.K8S-DEPLOY
**Artifact-section-hash:** fb346f0c8c23f4389aa0430beb8b164652eda259696ba62acbcc40c8a5211f44

### Variance summary

- **Artifact position:** Helm is the LOCKED Kubernetes-native packaging tool; a single Helm chart bundles entire FUSION (Doc 1 §5; Task Backlog MVP1.DEPLOY.001).
- **Scaffold position:** No `helm/` directory; `Makefile` references `helm` CLI but no chart authored.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with a MOSA-shaped skeleton. Author `helm/fusion/` as the umbrella chart with subcharts per bundled service: `fusion-app`, `gitea`, `postgres`, `keycloak`, `opa`, `worker`. Each subchart's `values.yaml` exposes a `bundled.enabled` flag and external-connection overrides (URL, token, secret references) so customers can disable the subchart and supply their own deployed instance — consistent with DECISION-0003's bundled-default / configurable-target pattern. The skeleton lands ahead of the per-service bundling decisions; each downstream variance (DEPLOY.HELM-CHART subdecisions) populates its own subchart.

### SMARTS rationale

All six SMARTS lenses favor adoption of the artifact position. The MOSA-shaped subchart structure adds Maintainable + Scalable + Securable benefit at near-zero cost beyond the base skeleton: subchart boundaries align with FUSION's bundled-service taxonomy, customer-side opt-outs become a `--set <service>.bundled.enabled=false` flag rather than a chart fork, and per-service NetworkPolicy templates fit naturally inside subchart `templates/`. Reliable benefit comes from `helm template` validation in CI catching shape regressions before merge. Zero Securable cost — the bundled-default mode preserves FUSION's owned-surface posture; the override mode shifts trust to customer-managed services and is documented as such in DECISION-0003.

### Implementation implication

- Author `helm/fusion/Chart.yaml` (umbrella, declares dependencies on subcharts).
- Author subchart skeletons under `helm/fusion/charts/`: `fusion-app/`, `gitea/`, `postgres/`, `keycloak/`, `opa/`, `worker/`. Each contains `Chart.yaml`, `values.yaml`, `templates/` directory.
- In each subchart's `values.yaml`, establish the convention:
  ```yaml
  bundled:
    enabled: true     # customer opt-out via --set <service>.bundled.enabled=false
  external:
    url: ""           # required when bundled.enabled is false
    secretRef: ""     # references existing Kubernetes Secret with credentials
  ```
- Author `helm/fusion/templates/_helpers.tpl` with shared label/name helpers.
- Wire `make deploy-stage` / `make deploy-prod` Makefile targets to call `helm install` against the umbrella chart.
- Add `helm template` and `helm lint` to CI pipeline (Stage 4 in `make ci`).
- Document the bundled-default / external-override pattern in `docs/deploy-guide.md` (or equivalent) so each subchart's authoring doesn't redebate the convention.

---

## DECISION-0007 — STACK.AUTH.AUTHORIZATION — Bundle OPA with phased policy build and MOSA hedges (engine isolation, allow+deny audit)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.AUTH.AUTHORIZATION
**Artifact-section-hash:** 80b48226fa205e96b44883da14c13d30a963ecfa79ac7154a8e7bc559c32eb3e

### Variance summary

- **Artifact position:** OPA bundled, owns all authorization decisions. Every authorized action calls an `authz.can(user, action, resource)` helper backed by Rego policies sourced from a `fusion-policies` Gitea repo (Doc 1 §3.6 + §5 LOCKED; Task Backlog MVP1.AUTH.006–008).
- **Scaffold position:** Silent — no OPA client, no Rego policies, no `fusion-policies` repo, no `authz.*` helper. Routes have authentication via `backend/src/middleware/auth.ts` but no authorization gate beyond authentication.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with a phased build and two MOSA evolvability hedges. MVP1 scope:

1. Bundle OPA as a subchart inside the umbrella Helm chart (per DECISION-0006's MOSA-shaped subchart structure). Use OPA's bundled mode with policy data sourced from the bundled Gitea (per DECISION-0003).
2. Scaffold a starter `fusion-policies` Gitea repo with a simplified pre-Spike-4 bundle structure per MVP1.AUTH.007.
3. Implement an `authz.can(user, action, resource)` helper in `backend/src/middleware/authz.ts` (or equivalent). Helper signature is engine-neutral; OPA-specific code (Rego compilation, bundle fetching, decision evaluation) stays inside the helper module and is not exposed to callers.
4. Instrument every authorized route to call `authz.can(...)` after authentication. Default-deny on missing policy.
5. **MOSA hedge — engine isolation:** No OPA-specific imports outside the `authz/*` module. Future engine swaps (Cedar, custom Rego runner) replace internals only, not call sites.
6. **MOSA hedge — audit every decision:** Emit a Z-AUDIT event for every authorization decision (allow AND deny) from day 1, including policy name, decision, and inputs. Required by CLAUDE.md §3 anyway; also enables future-engine equivalence validation by replay.

Full OPA bundle structure (multi-bundle, signed bundles, etc.) is deferred until Spike 4 completes.

### SMARTS rationale

All six lenses favor adoption: Scalable (sub-millisecond policy decisions), Maintainable (policy-as-code in Rego), Available (bundled, no external dependency), Reliable (default-deny on policy failure), Testable (`opa test` is first-class), and Securable (CLAUDE.md §3 ZT alignment is a Stage-2 entry blocker — failure to implement now creates a hard gate later). The two MOSA hedges add ~one audit emit per authorized action and the discipline of a clean module boundary; both have near-zero cost today and substantially reduce future re-architecture risk if OPA is later swapped (per the same reasoning as DECISION-0003 for Git provider).

### Implementation implication

- Add `helm/fusion/charts/opa/` subchart per DECISION-0006 conventions; bundled-default with `external.url` override for customer-managed OPA.
- Create `fusion-policies` Gitea repo (in the bundled Gitea per DECISION-0003) with starter Rego: at minimum `package fusion.authz; default allow = false; allow { ... }` for each MVP1 action category.
- Add `backend/src/middleware/authz.ts` exposing `authz.can(user, action, resource): Promise<{allow: boolean, policy: string, reason?: string}>`. Use OPA's `data` API or compile-and-evaluate via `@open-policy-agent/opa-wasm` (vet via dependency-reviewer).
- Wire every route in `backend/src/routes/*.ts` (currently `solutions.ts`, `deployments.ts`) to call `authz.can(...)` after authentication; deny on missing/error policies.
- Extend Z-AUDIT schema with `authz.decision`, `authz.policy`, `authz.inputs` fields per `docs/audit-spec.md`. Emit on every `authz.can()` call in both allow and deny paths. Required for CLAUDE.md §3 + future engine-swap equivalence replay.
- Add tests: `backend/src/__tests__/authz.test.ts` covering allow path, deny path, missing-policy default-deny, audit-emit on both outcomes (per CLAUDE.md §9 TDD obligations).
- Spike 4 (OPA Policy Bundle Structure) remains required before expanding the bundle shape; track separately via the spikes index.

---

## DECISION-0008 — STACK.HOSTING — MVP1 delivers airgap deployment mode (K3s on Cove.GDIT lab EC2); chart accommodates enterprise K8s as a future-supported mode

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.HOSTING
**Artifact-section-hash:** fb346f0c8c23f4389aa0430beb8b164652eda259696ba62acbcc40c8a5211f44

### Variance summary

- **Artifact position:** "K3s on EC2 in Cove.GDIT for FUSION's own hosting" (Doc 1 §5; Task Backlog MVP1.DEPLOY.009).
- **Scaffold position:** Silent — `terraform/main.tf` empty, no K3s install playbook, FUSION not deployed anywhere.
- **Status type:** scaffold-silent
- **Scope correction at decision time:** The artifact text reads as if K3s-on-EC2 is FUSION's only supported hosting model. User clarified during arbitration that this is in fact the airgap-deployment mode validated in the Cove.GDIT lab. FUSION supports multiple hosting profiles: enterprise K8s/EKS for GDIT-internal production, and K3s-on-EC2 (or other constrained K8s) for airgap/customer-self-managed deployments. MVP1 specifically validates the airgap mode end-to-end as the most-constrained profile that exercises self-contained packaging. The decision below is recorded against this corrected scope.

### Decision

Adopt the artifact position with explicit scope correction. MVP1 delivers the **airgap deployment mode** by deploying FUSION's umbrella Helm chart (per DECISION-0006) to a K3s instance running on a single EC2 host in the Cove.GDIT lab domain (`cove.gdit/sa-huffb` admin account). The umbrella chart remains hosting-mode-agnostic per DECISION-0006's MOSA-shaped subchart structure; per-mode Helm values overrides for storage class, LoadBalancer type, FIPS provider variant, and ingress are added now (`values-airgap-k3s.yaml`, `values-enterprise-eks.yaml`) as cheap MOSA hedge so future EKS or other-K8s deployment is mechanical when its work is taken up. The K3s install role is parameterized so it remains reusable for customer-airgap targets beyond the lab.

### SMARTS rationale

All six lenses favor adoption: Scalable (K3s on single EC2 sufficient at S1, EKS profile available later for V1+), Maintainable (single chart, profile values), Available (K3s embedded etcd or SQLite is sufficient at MVP1 scale), Reliable (Helm idempotency), Testable (local k3d for dev iteration mirrors production K3s), Securable (UBI9 FIPS supports STIG hardening for the airgap profile; same chart with EKS-FIPS values supports enterprise STIG hardening). The MOSA hedge of authoring per-mode values files now adds ~50 YAML lines today and saves a non-trivial refactor when EKS hosting is taken up — consistent with `feedback_mosa_evolvability.md` and the same pattern as DECISION-0003.

### Implementation implication

- **Terraform/OpenTofu:** Author EC2 + VPC declarations targeting Cove.GDIT lab account (`cove.gdit/sa-huffb`). This is the first concrete `tofu` consumer and triggers DECISION-0005's re-evaluation per its Trigger #2.
- **K3s install:** Parameterized Ansible role `roles/k3s-install/` accepting variables for cluster name, K3s version, FIPS toggle, etcd-vs-SQLite backend, datastore-endpoint override (for HA setups). Reusable for customer-airgap targets beyond the lab.
- **Helm values profiles:**
  - `helm/fusion/values-airgap-k3s.yaml` — local-path-provisioner storage class, K3s servicelb, Flannel CNI, embedded etcd, UBI9 FIPS images.
  - `helm/fusion/values-enterprise-eks.yaml` — gp3 storage class, AWS NLB, VPC CNI, external etcd or RDS where applicable, FIPS-validated EKS AMI variant.
- **CI:** Add `helm template -f values-airgap-k3s.yaml` and `helm template -f values-enterprise-eks.yaml` to CI to catch shape regressions in either profile (consistent with DECISION-0006).
- **Documentation:** Update `docs/deploy-guide.md` (or equivalent) to enumerate the two supported deployment modes, their target users, and which `values-*.yaml` to use.
- **Audit-trail rule:** every audit event emitted from a deployed FUSION instance includes a `deployment.mode` field (`airgap-k3s` | `enterprise-eks` | future modes) per the same MOSA pattern as DECISION-0003's `git.provider` tag.

### Resolves same-level conflict between (when applicable)

n/a (no same-level conflict in source documents; the user's clarification corrected an arbiter-side scope misreading rather than a conflict between authority sources).

---

## DECISION-0009 — STACK.OBSERVABILITY.METRICS — Wire OpenTelemetry SDK at MVP1 with /metrics endpoint and audit-trace correlation

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STACK.OBSERVABILITY.METRICS
**Artifact-section-hash:** fb346f0c8c23f4389aa0430beb8b164652eda259696ba62acbcc40c8a5211f44

### Variance summary

- **Artifact position:** OpenTelemetry SDK at all stages; Loki/Prometheus bundled at V1+; MVP1 boundary line is "logs to stdout, exposes OTel metrics endpoint without scraper" (Doc 1 §5 + Doc 2 MVP1 §11 deferral list).
- **Scaffold position:** Silent — no `@opentelemetry/*` dependency, no `/metrics` endpoint, no SDK instrumentation.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with one MOSA-aligned enhancement. Add `@opentelemetry/sdk-node` (and necessary auto-instrumentation packages for Fastify and Postgres/Drizzle) to the backend, initialize the SDK at process start, and expose a `/metrics` endpoint per Doc 2's MVP1 boundary. Bundled Loki/Prometheus remain deferred to V1+. The MOSA enhancement: plumb the active OTel `trace_id` and `span_id` into every Z-AUDIT event from day 1, so audit records are correlated with traces for free debuggability and so the V1 transition to a real APM backend is mechanical.

### SMARTS rationale

Maintainable and Testable favor adoption: the wire-up is small (~half-day) when added before features mature, and the `/metrics` endpoint exposes baseline counts that V1 instrumentation work builds on rather than starting from zero. The audit-trace correlation hedge has near-zero cost (the OTel SDK exposes the active span as global state; one helper picks `trace_id`/`span_id` and adds them to the audit emit envelope) and substantially improves debuggability when an audit event references a request flow. SC-39 / AU-3 audit posture benefits when audit records can be cross-referenced with traces. No Securable cost — OTel data stays in-process at MVP1 (no scraper, no exporter to external systems) so no new trust-zone crossing is introduced.

### Implementation implication

- Add backend dependencies: `@opentelemetry/sdk-node`, `@opentelemetry/auto-instrumentations-node` (or a curated subset to avoid pulling unintended exporters). Vet via dependency-reviewer subagent.
- Initialize the SDK at the top of `backend/src/server.ts` (or equivalent process entry) before Fastify is constructed, so auto-instrumentation wraps the HTTP server.
- Add a `/metrics` Fastify route exposing the OTel meter provider's metrics in OpenMetrics/Prometheus text format (via `@opentelemetry/exporter-prometheus` or equivalent). Route is unauthenticated at MVP1 (internal team only at S1) but flagged for authentication review at Stage 2 promotion.
- Update `backend/src/lib/audit/emit.ts` (or wherever Z-AUDIT events are constructed) to include `trace.id` and `trace.span_id` fields when an active span exists. Both fields are optional in the audit schema; absent when no span is active.
- Extend `docs/audit-spec.md` to register `trace.id` and `trace.span_id` as optional standard fields on all audit events.
- Add tests: `backend/src/__tests__/observability.test.ts` covering SDK initialization, `/metrics` endpoint shape, and audit-trace correlation (per CLAUDE.md §9 TDD obligations).
- Update CHANGELOG `[Unreleased]`.

---

## DECISION-0010 — PATTERN.WORKER-ABSTRACTION — Define ExecutionWorker interface upstream with MockWorker as the second concrete consumer

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.WORKER-ABSTRACTION
**Artifact-section-hash:** 4d47a9c3dcae9fee6f0ac5e4058386908122bf9c694e242cb1179e541a858504

### Variance summary

- **Artifact position:** Z-WORKER calls an abstract execution-worker interface; today Ansible-based and swap-friendly so solution manifests, node definitions, and Z-WORKER orchestration code are unaffected by implementation choice (Doc 1 §3.3 + §6.1 LOCKED; Task Backlog MVP1.EXEC.001).
- **Scaffold position:** Silent — no Z-WORKER service, no abstraction interface, no worker implementations.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position. Define an `ExecutionWorker` interface in shared backend types under `backend/src/worker/types.ts` (or equivalent) BEFORE the first FUSION node is authored, per MVP1.EXEC.001. The interface captures only the operations Z-WORKER calls: `execute(plan): WorkerHandle`, `cancel(handle)`, `streamOutput(handle): AsyncIterable<OutputChunk>`, plus capability discovery (`supportedNodeKinds`, `supportedAdapterKinds`). Concrete implementations (`AnsibleWorker` for production, `MockWorker` for tests) live under `backend/src/worker/impl/`.

To validate the interface is not Ansible-shaped, the implementation MUST include a `MockWorker` test implementation as a second concrete consumer of the interface from day 1. The `MockWorker` is exercised by Z-WORKER unit tests (and by future end-to-end test fixtures) and serves as the lightweight cross-check that catches the "interface-against-one-example" anti-pattern surfaced in `feedback_mosa_evolvability.md`. Adding it costs ~30 lines of test code; skipping it makes the abstraction's MOSA value unverifiable.

### SMARTS rationale

Maintainable lens dominates: the pattern's whole purpose is to prevent retroactive abstraction debt and insulate downstream code from any Ansible/Pyinfra/Salt swap forced by R-01 (Ansible GPL licensing risk). Scalable favors adoption (one interface across worker count and worker types). Testable favors adoption strongly (MockWorker enables hermetic tests of Z-WORKER orchestration without invoking real Ansible). The MockWorker hedge has near-zero today-cost and substantially de-risks the interface shape — a "second concrete consumer" is the validating force per `feedback_mosa_evolvability.md`. Securable is unaffected (interface boundary doesn't change auth or trust-zone semantics). The decision compounds with future decisions: STACK.IAC.CONFIG-MGMT (Ansible vs Pyinfra vs Salt, currently a known open decision) becomes a worker-implementation swap rather than a codebase rewrite.

### Implementation implication

- Author `backend/src/worker/types.ts` exporting:
  - `ExecutionWorker` interface (operations Z-WORKER calls).
  - `WorkerHandle`, `OutputChunk`, `WorkerCapabilities` domain types.
- Author `backend/src/worker/impl/mock.ts` (`MockWorker`) — used by all Z-WORKER unit tests as the default worker. Exercises every interface method.
- Author `backend/src/worker/impl/ansible.ts` (`AnsibleWorker`) skeleton — populated in MVP1.EXEC.* tasks; calls Ansible runner via subprocess (per CLAUDE.md §3 hard rules: NEVER `shell: true`, only argv-array invocations).
- Z-WORKER service (`backend/src/worker/service.ts`) holds a single `ExecutionWorker` instance selected by config (`WORKER_IMPL=ansible|mock`).
- Add tests in `backend/src/__tests__/worker.test.ts` exercising MockWorker against the full interface and confirming Z-WORKER dispatch works against any `ExecutionWorker` (parametric tests).
- Update `docs/architecture/` (or equivalent) with a one-paragraph note describing the interface contract and the MockWorker validation pattern.
- The interface forms the seam against which `STACK.IAC.CONFIG-MGMT` (Ansible vs alternatives) is evaluated when that open question is resolved.

---

## DECISION-0011 — PATTERN.MULTI-TENANT-RETROFIT — tenant_id on every solution-related table from MVP1 via standardized withTenant() helper

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.MULTI-TENANT-RETROFIT
**Artifact-section-hash:** d38b6326cfb803c4819af58209c753885551ef57beb037befe8d9e2a7fb503e8

### Variance summary

- **Artifact position:** Every solution-related table includes a `tenant_id` column from MVP1 defaulting to a single `'gdit'` tenant; zero functional change at MVP1, but eliminates the multi-tenant migration when SaaS ships (Doc 1 §6.2 LOCKED).
- **Scaffold position:** `solutions` and `deployments` tables in `backend/src/db/schema.ts` have no `tenant_id` column; future solution-related tables (env profiles, deployment receipts, audit policies, etc.) don't exist yet but inherit this omission by default.
- **Status type:** divergent

### Decision

Adopt the artifact position with a standardized helper. Add `tenant_id` (UUID or text, defaulted to `'gdit'`) to `solutions`, `deployments`, and every future solution-related table via a single Drizzle helper `withTenant(table)` that consistently adds the column, the FK to a future `tenants` table, and a composite index `(tenant_id, id)` (or per-table appropriate sort key). Every query that touches solution-related tables MUST scope by `tenant_id`. The helper is the canonical pattern; bypassing it on a new table is a CI-detectable convention violation.

### SMARTS rationale

Scalable, Maintainable, Reliable, and Securable all strongly favor adoption: SaaS-ready data model from day one, single pattern across all tables, no retrofit migration risk on populated tables, tenant isolation enforceable at the query layer (which compounds with DECISION-0007's OPA authorization layer — without `tenant_id` now, every authorized query is implicitly cross-tenant and must be revisited for compliance review when SaaS ships). The standardized `withTenant()` helper is the MOSA hedge that prevents drift across tables: without it, the eighth table author forgets the index or the FK, and the convention degrades over time. Cost today is one helper file (~30 lines); savings compound across every future solution-related table.

### Implementation implication

- Add `backend/src/db/helpers/with-tenant.ts` exposing `withTenant(table, opts?)` — Drizzle table-builder helper that adds:
  - `tenant_id` column (text or UUID, default `'gdit'`, NOT NULL, FK to `tenants.id` once that table exists)
  - composite index on `(tenant_id, <primary key>)` for query scoping
  - convention metadata for static analysis (so `make ci` can detect tables that bypass the helper)
- Add Drizzle migration to `backend/drizzle/migrations/` adding `tenant_id` columns to existing `solutions` and `deployments` tables (per CLAUDE.md §10 migration-reviewer protocol — Edit-deny on this directory means the migration commit goes through CODEOWNERS).
- Update query layer: every `db.select()` / `db.insert()` / `db.update()` / `db.delete()` against solution-related tables MUST include `WHERE tenant_id = :tenant_id` (insert: explicit tenant_id binding). Add a Drizzle query helper or repository pattern to centralize this — TBD as implementation detail.
- Update `docs/data-model.md` and `docs/data-classification.md` to register the convention.
- Add Semgrep or ESLint rule that flags any direct table reference in `backend/src/routes/*.ts` not going through a tenant-scoped repository helper.
- The seam compounds with DECISION-0007: every OPA `authz.can()` decision input MUST include `tenant_id`; OPA policies are tenant-scoped from day 1.
- Future `tenants` table itself is out of scope for this decision; for MVP1 the `tenant_id` value `'gdit'` is the only valid value (validated by check constraint or app-layer enum until the tenants table arrives).

---

## DECISION-0012 — PATTERN.REVERSAL-TIERS — Three-tier teardown_capability enum on node and adapter schemas, plus deployment-receipt records tier-at-deploy

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.REVERSAL-TIERS
**Artifact-section-hash:** ee1938a8d0020a882313e92fdf11f182270767dc3c8132fbb72172332fa9ae94

### Variance summary

- **Artifact position:** Every node and adapter declares its teardown capability as one of `clean | partial | manual`; the publication gate blocks merge without teardown declaration; brownfield deployments with `manual` reversal require elevated permission (Doc 1 §6.4 LOCKED).
- **Scaffold position:** `schemas/node.schema.json` requires `teardown_procedure` as a free-form `string` (`minLength: 1`), not a tiered enum; `schemas/adapter.schema.json` does not declare teardown at all; `docs/domain.md` describes only `teardown_procedure`, agreeing with scaffold.
- **Status type:** divergent

### Decision

Adopt the artifact position. Add a `teardown_capability` enum field of values `clean | partial | manual` to both `schemas/node.schema.json` and `schemas/adapter.schema.json`. Both `teardown_capability` AND `teardown_procedure` are required fields — the enum classifies the operational tier, the procedure documents the steps. Update `docs/domain.md` so the prose definition of node and adapter agrees with the schemas. Wire the publication-gate check (in `make validate-definitions` and the corresponding CI step) to enforce both presence and the elevated-permission requirement when `teardown_capability == "manual"`.

Adopt the receipt-records-tier hedge: every deployment receipt MUST record `teardown_capability_at_deploy_time` for both the node and any adapters used. If a node's capability later improves from `manual` to `clean` after automation work, the historical receipt still reflects the tier in force at deploy time. This is one extra field per receipt at near-zero today-cost and substantial audit-traceability value.

### SMARTS rationale

Scalable, Maintainable, Reliable, Testable, and Securable all favor adoption. The enum makes the publication-gate enforceable (the artifact's pattern collapses without it); JSON Schema validation catches missing tiers at authoring time; the elevated-permission requirement for `manual` becomes a programmatic check rather than a prose hope. The receipt-records-tier hedge addresses a defense-grade audit concern: when reviewers later examine a deployment, they need to know what tier was committed at deploy time, not what the current node author claims. This decision also resolves a latent same-level conflict between Doc 1 §6.4 (asserts tiered enum) and `docs/domain.md` (describes free-form prose) — the conflict was a documentation lag rather than a deliberate alternative; updating `docs/domain.md` to match the artifact removes the conflict surface.

### Implementation implication

- Update `schemas/node.schema.json`:
  - Add required field `teardown_capability` of type `string`, `enum: ["clean", "partial", "manual"]`.
  - Keep `teardown_procedure` required.
- Update `schemas/adapter.schema.json`:
  - Add required field `teardown_capability` (same enum).
  - Add required field `teardown_procedure` if not present.
- Update `docs/domain.md` — replace prose discussion of teardown with the tiered model; cross-reference Doc 1 §6.4.
- Update `make validate-definitions` (and the CI workflow step) to enforce:
  - Schema validation of both fields on every `definition.yaml`.
  - Elevated-permission requirement when `teardown_capability == "manual"` (CODEOWNERS-style check on the publication PR).
- Update deployment-receipt schema (when `STATE.DEPLOYMENT-RECEIPT` is arbitrated, currently a downstream variance) to include `teardown_capability_at_deploy.node` and `teardown_capability_at_deploy.adapters[]` fields. Capture them on the deploy emit.
- Add Z-AUDIT field `deployment.teardown_capability` to the audit-spec, populated when a deployment is recorded.
- Add tests: `backend/src/__tests__/definitions.test.ts` (or equivalent) covering schema validation of all three tier values plus rejection of arbitrary strings.

### Resolves same-level conflict between (when applicable)

Resolves a same-level conflict between **Doc 1 §6.4 — `[PATTERN.REVERSAL-TIERS]` LOCKED** (asserts tiered enum + publication-gate enforcement + elevated-permission rule) and **`docs/domain.md`** (describes only free-form `teardown_procedure`). User decision: update `docs/domain.md` to align with Doc 1 §6.4. The conflict was a documentation lag, not a deliberate alternative architecture.

---

## DECISION-0013 — PATTERN.PIN-WITH-MONITORING — Add pin metadata columns at MVP1; defer V1.PIN.* CI; include pin_protocol_version MOSA hedge

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.PIN-WITH-MONITORING
**Artifact-section-hash:** b5aa468150b3d2f6059d4073c7862f67d7cd80cbe0426b9b42e7e04979ad9cda

### Variance summary

- **Artifact position:** FUSION supports two redeployment modes — logical reproduction (default, latest artifacts) and pinned reproduction (explicit artifact versions, monitored via CI). Solution age tiers green/yellow/red. Doc 2 §3 schema additions on `solutions`: `pinned_artifacts`, `solution_last_tested`, `solution_age_status`, `pin_health_status`. (Doc 1 §6.5 LOCKED.)
- **Scaffold position:** `backend/src/db/schema.ts` has no pin model; `solutions.graph` is opaque JSONB; no `git_sha` column on solution; none of the locked-in fields exist on `solutions` or `deployments`.
- **Status type:** divergent

### Decision

Adopt the artifact's schema additions at MVP1, defer the V1.PIN.* CI work, and add a `pin_protocol_version` MOSA hedge inside the `pinned_artifacts` JSON shape.

MVP1 schema work:
- Add columns to `solutions`: `pinned_artifacts` (JSONB), `solution_last_tested` (timestamptz), `solution_age_status` (enum: `green | yellow | red`), `pin_health_status` (enum: `healthy | degraded | unknown`).
- Inside the `pinned_artifacts` JSONB schema, every artifact entry MUST include a `pin_protocol_version` integer (start at `1`). This reserves the format-evolution lane: when pin shape needs to extend (e.g., to add provenance attestations or to support new artifact kinds), V2 protocol entries coexist with V1 entries instead of forcing a full-table migration.

V1 deferred:
- The pin-monitoring CI (V1.PIN.*) that flips `pin_health_status` to `degraded` and computes `solution_age_status` is a V1 deliverable. MVP1 leaves these fields default-unknown / default-green and populates them when V1 lands.

### SMARTS rationale

Scalable, Maintainable, Reliable lenses all favor the hybrid path strongly. The schema-now / CI-later split is exactly the cheap-MOSA-hedge shape (same as DECISION-0011 for tenant_id): columns are virtually free at MVP1, and skipping them forces a future migration of every existing solution row plus a contentious decision about whether MVP1-era deployments are reproducible at all. The `pin_protocol_version` hedge reserves the schema-evolution lane and matches the `feedback_mosa_evolvability.md` pattern of preserving optionality without committing to its shape. Architectural significance: pin-with-monitoring is the structural argument against an artifact archive — skipping the metadata implicitly votes for the archive infrastructure later. Securable is unaffected (no new auth or trust-zone surface). Testable is adequate (column population can be unit-tested even before CI exists).

### Implementation implication

- Add Drizzle migration to `backend/drizzle/migrations/` extending `solutions` with the four columns. Migration goes through CODEOWNERS per CLAUDE.md §10 (Edit-deny on `backend/drizzle/migrations/`).
- Define the `pinned_artifacts` JSONB shape as a Zod schema (`backend/src/db/types/pinned-artifacts.ts`):
  ```ts
  z.object({
    pin_protocol_version: z.literal(1),
    artifacts: z.array(z.object({
      kind: z.enum(['package', 'container', 'helm-chart', 'git-ref']),
      name: z.string(),
      pinned_value: z.string(),  // version, sha256, git sha, etc.
      // ...kind-specific extensions allowed via discriminated union later
    })),
  });
  ```
- Add tests in `backend/src/__tests__/pin-schema.test.ts` covering schema parse on each artifact kind plus rejection of unknown protocol version.
- Update `docs/data-model.md` to document the four columns and the protocol-version convention.
- The DEPLOYMENT-RECEIPT decision (downstream variance) consumes the `pinned_artifacts` JSON at deploy time and snapshots it into the receipt.
- V1 backlog adds the pin-monitoring CI tasks; track via the existing V1.PIN.* task IDs without duplicating in this decision log.

---

## DECISION-0014 — PATTERN.BROWNFIELD-DEPENDENCY — Solution-manifest external_dependencies[] with check_tier + pre-flight wizard + receipt snapshot

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.BROWNFIELD-DEPENDENCY
**Artifact-section-hash:** 1ce4aece02529ce76177f126bd19e1397e74db91eb1b510be7d2c54b3a139626

### Variance summary

- **Artifact position:** Solutions declare external dependencies (existing tools, service accounts, network access, pre-conditions) in their manifest. A pre-flight wizard guides satisfaction; each dependency declares check tier `required | recommended | skip-in-airgap` (Doc 1 §6.7 LOCKED; Task Backlog MVP1.UI.009 + Doc 2 §5).
- **Scaffold position:** Silent — no solution manifest schema yet, no pre-flight wizard, no dependency-check infrastructure.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with a receipt-snapshot hedge. Add an `external_dependencies[]` array to the solution-manifest JSON Schema, where each entry declares `name`, `kind` (e.g., `service-account`, `network-egress`, `pre-installed-tool`), `description`, `check_tier` (`required | recommended | skip-in-airgap`), and an optional structured `check_spec` (machine-readable form of the satisfaction criterion, e.g., a hostname:port reachability spec for network-egress kind, a service-account name for service-account kind). Build the pre-flight wizard step per MVP1.UI.009 to render these dependencies, run the structured checks where possible, and let users mark unstructured dependencies as satisfied with a free-text justification.

Adopt the receipt-snapshot hedge: every deployment receipt MUST capture the dependency-check outcomes at deploy time. Each entry records `name`, `check_tier`, outcome (`passed | skipped-airgap | failed | acknowledged-unstructured`), and any operator-supplied justification. This becomes the audit trail when a deployment succeeds in the Cove.GDIT lab and later fails at a customer site due to an undeclared/unchecked dependency.

### SMARTS rationale

Scalable lens favors strongly: a generic dependency model handles defense-customer brownfield variation without per-solution code changes. Maintainable favors strongly: schema-driven UI keeps the wizard from accreting solution-specific hacks. Reliable benefits adequately: pre-flight checks reduce surprise mid-deploy failures, the most common deployment-failure class in brownfield environments. Securable benefits adequately: service-account requirements become explicit in the manifest rather than tribal knowledge in operator's heads. The receipt-snapshot hedge converts the audit-trail "did the operator actually check what they claimed?" question into a recorded answer instead of a forensic investigation. Cost is real (schema + wizard step + receipt extension is non-trivial MVP1 work), but offsets the OCTO funding-gate credibility risk: the brownfield pattern is FUSION's headline differentiator from competitors that assume greenfield deploys.

### Implementation implication

- Update solution-manifest JSON Schema (`schemas/solution.schema.json` once authored, or create with this addition) to require `external_dependencies` (default `[]`).
- Each dependency entry's structure:
  ```json
  {
    "name": "string",
    "kind": "service-account|network-egress|pre-installed-tool|customer-policy-acknowledgement|other",
    "description": "string",
    "check_tier": "required|recommended|skip-in-airgap",
    "check_spec": { "...kind-specific..." }
  }
  ```
- Frontend: implement wizard step 3 per MVP1.UI.009. Render dependency list with check-tier badge, run structured checks where `check_spec` is present, allow free-text acknowledgement with operator justification for unstructured cases, gate "next step" on all `required` dependencies being satisfied.
- Backend: add a dependency-check executor module (`backend/src/preflight/check.ts` or equivalent) that dispatches by `kind`. Pre-flight checks should be cancellable, time-bounded, and emit Z-AUDIT events on each check (per CLAUDE.md §3 and DECISION-0007's audit-every-decision pattern adapted to dependency checks).
- Deployment receipt schema (when STATE.DEPLOYMENT-RECEIPT is arbitrated) MUST include `dependency_check_results[]` capturing the outcome of each declared dependency check at deploy time.
- Z-AUDIT schema extension: register `preflight.dependency_check` event type with fields `dependency.name`, `dependency.kind`, `check.tier`, `check.outcome`, `operator.justification` (optional).
- Tests: schema validation of every example dependency kind; wizard component tests for required-blocking and skip-in-airgap behavior; backend pre-flight check tests covering each `kind` dispatch; receipt-snapshot tests asserting dependency outcomes are captured.
- Documentation: update `docs/runbook.md` (or equivalent) describing the wizard flow, the four dependency `kind` values, and operator-justification expectations.

---

## DECISION-0015 — PATTERN.CHANGE-TRIGGER-POLICY — Fold Doc 1 §6.8 trigger list into docs/risks.md review cadence

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** PATTERN.CHANGE-TRIGGER-POLICY
**Artifact-section-hash:** 385e725041faf3773b53055634b61d8347f653c2d2a467693e17f920a5033ae1

### Variance summary

- **Artifact position:** Defined triggers for stop-and-review: license/policy denials, dependency relicensing, customer pull, ATO/FedRAMP/IL mandates, spike findings, technical impossibility (Doc 1 §6.8 LOCKED).
- **Scaffold position:** CLAUDE.md §0 conflict-resolution hierarchy overlaps in spirit but covers a different concern (priority resolution between rule classes, not review triggers); no formal change-trigger policy document exists.
- **Status type:** scaffold-silent

### Decision

Adopt the hybrid: fold Doc 1 §6.8's trigger list into `docs/risks.md` as a new "Architecture Change Triggers" section. Cross-reference CLAUDE.md §0 from that section to clarify the distinction (CLAUDE.md §0 = priority resolution between rule classes; the new section = events that trigger stop-and-review process). The existing review cadence on `docs/risks.md` (every 12 weeks + Stage promotion per CLAUDE.md §6) inherits the trigger-policy review cadence with no new machinery.

### SMARTS rationale

Maintainable lens dominantly favors the hybrid: one document instead of two; existing review cadence absorbs the new content. Securable adequately favors any of the documented options because surfacing compliance-driven triggers (ATO/FedRAMP/IL mandates) is what matters; the home document is incidental. Other lenses are indifferent — this is process discipline, not a code or runtime concern. The scaffold-only option (declare CLAUDE.md §0 sufficient) loses the trigger semantics that are genuinely distinct from priority resolution; the new-doc option is correct but adds a maintenance surface for content that fits cleanly inside an existing reviewed document.

### Implementation implication

- Update `docs/risks.md`:
  - Add new top-level section "Architecture Change Triggers" capturing Doc 1 §6.8 verbatim or near-verbatim.
  - Each trigger gets a one-paragraph elaboration: what the trigger looks like in practice, who notices first, what stop-and-review entails.
  - Cross-reference CLAUDE.md §0 with a one-sentence "this is review triggers, not priority resolution; for priority between rule classes see CLAUDE.md §0" note.
- Update CLAUDE.md §6 (Decision Log review cadence) to reference the trigger list explicitly.
- No code change. No schema change. No CI change. This is process documentation only.
- The existing `docs/risks.md` review cadence (12-week + Stage-promotion) carries this content forward; no new review process is introduced.

---

## DECISION-0016 — STATE.DB-GIT-SYNC — Basic Gitea→DB sync at MVP1 with idempotent handler MOSA hedge

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STATE.DB-GIT-SYNC
**Artifact-section-hash:** 6c799ea9922a4c9e5c3b41d0e2c27c9ad264cb9b61f222c35456bf9854dc798b

### Variance summary

- **Artifact position:** Z-DB is the read cache for Gitea; webhook-driven sync; every cached entity carries `git_sha`. Spike 1 is the highest-priority spike before V1 commitment to full multi-user library workflow; MVP1 ships basic sync (Doc 1 §3.4 + §3.7 + §4.2; Task Backlog MVP1.LIB.006-007).
- **Scaffold position:** Silent — no webhook receiver, no sync handler, no `git_sha` columns on any of the registry tables.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with one MOSA hedge: implement basic Gitea→DB sync per MVP1.LIB.007, with the sync handler designed to be **idempotent from day 1** even though MVP1 only runs a single FUSION instance.

Sync wiring (consistent with DECISION-0003):
- Inbound Gitea webhook hits `backend/src/library/webhook-receive.ts` (signature-verifies the payload using Gitea's shared-secret header pattern).
- Webhook-normalize.ts (already established by DECISION-0003) converts the Gitea-shaped payload into a domain event (`RepositoryUpdated`, `PullRequestMerged`, `BranchPushed`).
- Sync handler (`backend/src/library/sync-handler.ts`) consumes domain events and upserts into the registry tables (`nodes`, `adapters`, `policies`, etc.) scoped by `tenant_id` per DECISION-0011.

Idempotency hedge:
- Every domain event carries a stable `event_id` derived from `(commit_sha, ref, repo)`. Sync handler maintains an `processed_events` table; replaying an already-processed event is a no-op. Cost today: one small table + one row-write per event. Future benefit: Spike 1's multi-instance V1 case (where the same webhook may arrive at multiple FUSION replicas) becomes a config change rather than a sync-handler rewrite. Same MOSA pattern as `feedback_mosa_evolvability.md`.

### SMARTS rationale

Maintainable favors adoption: pattern is established before complications accrue at V1. Reliable favors adoption with idempotency: webhook delivery has at-least-once semantics from the Gitea side; idempotent handlers are the standard pattern that survives that contract. Testable favors adoption: webhook payloads are mockable end-to-end via the normalize seam established in DECISION-0003. Scalable benefits when V1 introduces multiple FUSION instances — the idempotent sync handler is the same sync handler, just running on more nodes. Securable benefits adequately from webhook signature verification (Gitea's shared-secret HMAC). The idempotency hedge is the cheap-now / load-bearing-later MOSA pattern that prevents a sync-handler rewrite at V1.

### Implementation implication

- Author `backend/src/library/webhook-receive.ts` — Fastify route receiving Gitea webhooks; verifies signature; passes payload to webhook-normalize.ts.
- Idempotency table migration: `processed_events (event_id PRIMARY KEY, event_kind, source, received_at, processed_at)`. Add to `backend/drizzle/migrations/` per CLAUDE.md §10 CODEOWNERS protocol.
- Author `backend/src/library/sync-handler.ts` consuming domain events. Each handler:
  1. Computes the deterministic `event_id`.
  2. Inserts into `processed_events` with `ON CONFLICT DO NOTHING` (or equivalent). If conflict, return early — already processed.
  3. Otherwise upsert the registry row(s) scoped by `tenant_id`.
  4. Update `processed_events.processed_at`.
  5. Emit Z-AUDIT event for the sync action (`library.sync.completed` / `.failed`).
- Bind the webhook receive route to the bundled Gitea instance (per DECISION-0003) — Helm values configure the webhook endpoint URL on the Gitea side.
- Tests: idempotency (replay produces no double-write); signature verification (rejects unsigned payloads); domain-event normalization (raw Gitea payload → `RepositoryUpdated` shape); tenant-scoping (sync writes go to `tenant_id = 'gdit'` per DECISION-0011).
- The Spike 1 work (V1 multi-instance sync mechanics) consumes this seam without changing it.

---

## DECISION-0017 — STATE.GITSHA-PINNING — Relational split of solutions.graph into solution_nodes + solution_edges with stable position_id

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STATE.GITSHA-PINNING
**Artifact-section-hash:** b5aa468150b3d2f6059d4073c7862f67d7cd80cbe0426b9b42e7e04979ad9cda

### Variance summary

- **Artifact position:** Solutions MUST pin `git_sha` for every node and adapter at save time (Doc 1 §3.4, §6.5; Doc 2 §3 schema additions; `docs/domain.md`). Schema additions explicitly include `git_sha` columns on `solution_nodes`, `solution_edges`, etc.
- **Scaffold position:** `solutions.graph` is opaque JSONB typed loosely as `{ nodes: unknown[]; adapters: unknown[] }`; no `git_sha` column anywhere; no `solution_nodes` or `solution_edges` junction tables.
- **Status type:** divergent

### Decision

Adopt the artifact position with relational split and a stable position_id pattern. Replace the opaque `solutions.graph` JSONB with two relational tables:

- `solution_nodes(solution_id, position_id UUID, node_kind, node_git_sha, node_config_jsonb, tenant_id)` with composite primary key `(solution_id, position_id)` plus the `withTenant()` helper from DECISION-0011.
- `solution_edges(solution_id, position_id UUID, source_position UUID, target_position UUID, adapter_kind, adapter_git_sha, adapter_config_jsonb, tenant_id)` with the same key shape.

The `position_id` is generated at save time (UUID v4) and is **stable across node renames or kind changes**. The React Flow canvas references nodes by `position_id`, not by name or kind — so renaming a `dc-windows` node to `dc-windows-fips` doesn't break canvas state, deployment receipts, or audit references. Both tables FK to a future `node_versions` / `adapter_versions` table on the `(node_kind, git_sha)` and `(adapter_kind, git_sha)` composite keys respectively, ensuring the DB itself enforces that pinned versions exist.

`solutions.graph` JSONB column is retired in this migration; the rendered React Flow graph is reconstructed from the two relational tables on read.

### SMARTS rationale

Scalable, Maintainable, Reliable, Securable, and Testable all favor the relational split. Indexed lookups by `(node_kind, git_sha)` enable receipt query patterns the JSONB approach cannot reach without full scans. NOT NULL `git_sha` columns and FK references to `node_versions` enforce the pinning contract at the DB layer — defense-grade audit posture wants the DB enforcing the contract because application-layer Zod is bypassable by direct DB writes from migrations, admin tools, or future microservices. The `position_id` pattern is a small but load-bearing MOSA hedge per `feedback_mosa_evolvability.md`: it preserves canvas continuity through future node-kind renames, schema migrations, and audit-trail integrity, all at near-zero today-cost (one UUID per row at save time). Decision compounds with DECISION-0013 (pin metadata), DECISION-0011 (tenant scoping), DECISION-0014 (brownfield dependency receipts), and the upcoming STATE.DEPLOYMENT-RECEIPT decision — receipts capture `position_id` plus `git_sha` plus `kind` for every node/adapter at deploy time.

### Implementation implication

- Drizzle migration to `backend/drizzle/migrations/` (CODEOWNERS protocol per CLAUDE.md §10):
  - Drop `solutions.graph` column (after backfill is N/A — no production data exists yet at S1).
  - Create `solution_nodes` and `solution_edges` per the schema above; both go through `withTenant()` from DECISION-0011.
  - Reserve `node_versions(kind, git_sha, manifest_jsonb)` and `adapter_versions(kind, git_sha, manifest_jsonb)` tables (separate decision: SCHEMA.NODE-DEFINITION / SCHEMA.ADAPTER-DEFINITION downstream); FKs from `solution_nodes`/`solution_edges` reference these.
- Update Drizzle schema (`backend/src/db/schema.ts`) to export the new tables and retire `solutions.graph`.
- Rewrite `backend/src/routes/solutions.ts` save handler:
  - On save, persist nodes and edges to the relational tables with newly-generated `position_id` UUIDs (or preserve client-supplied UUIDs if present).
  - On read, reconstruct the React Flow graph shape from joins of `solution_nodes` and `solution_edges`.
- Frontend (`frontend/src/components/SolutionCanvas` or equivalent) updated so React Flow node IDs are the server-supplied `position_id` UUIDs throughout, not derived from node kind or label.
- Z-AUDIT extension: `solution.save` audit events include the count of nodes and adapters and a hash of the position_id set, enabling change-detection across saves without leaking solution content into audit.
- Tests covering: save-then-read round-trip preserves graph; rename of node kind preserves position_id; deletion of an edge does not orphan a node; FK enforcement rejects an unknown `(node_kind, git_sha)` reference; `withTenant()` scoping applies (no cross-tenant leakage in queries).

---

## DECISION-0018 — STATE.DEPLOYMENT-RECEIPT — Rename deployments → deployment_receipts; consolidate snapshot fields from upstream decisions

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STATE.DEPLOYMENT-RECEIPT
**Artifact-section-hash:** cd0cdb9409cbbfe346c4dfdc8fa5990fd05ae0a1a61b4d68bafb65bf7479b809

### Variance summary

- **Artifact position:** `deployment_receipts` table with `id`, `solution_id`, `environment_id`, `started_at`, `completed_at`, `status`, `pinned_artifacts` (JSONB), `solution_last_tested`, `solution_age_status`, `pin_health_status`, `final_logs_ref`. Point-in-time snapshot, never expires (Doc 1 §3.4; Doc 2 §3; Task Backlog MVP1.DB.009).
- **Scaffold position:** `deployments` table has minimal fields: `id`, `solutionId`, `solutionName`, `status`, `actorSub`, `classification`, `replicaCount`, `createdAt`, `updatedAt`. None of the artifact-listed locked-in fields exist.
- **Status type:** divergent

### Decision

Adopt the artifact position fully, including the table rename from `deployments` to `deployment_receipts`. The rename emphasizes the receipt semantics (point-in-time snapshot, audit artifact) that the bare `deployments` name does not convey. ~2 routes plus tests need to be updated to reference the new table name; that churn is small at S1 with no production data and is preferable to a permanent name-vs-semantics mismatch.

The renamed table consolidates fields from this decision's artifact requirements **and** from the upstream receipt-snapshot obligations established by earlier decisions:

- Artifact-required fields (Doc 2 §3): `id`, `solution_id`, `environment_id`, `started_at`, `completed_at`, `status`, `pinned_artifacts` (JSONB), `solution_last_tested`, `solution_age_status`, `pin_health_status`, `final_logs_ref`.
- Tenant scoping (DECISION-0011): `tenant_id` via `withTenant()` helper.
- Pin metadata (DECISION-0013): `pinned_artifacts` JSONB shape MUST include `pin_protocol_version` per the Zod schema.
- Reversal capability (DECISION-0012): `teardown_capability_at_deploy_node` (enum), `teardown_capability_at_deploy_adapters_jsonb` (per-adapter capture).
- Brownfield dependency outcomes (DECISION-0014): `dependency_check_results` JSONB capturing each declared dependency's name, kind, check_tier, outcome, and operator justification at deploy time.
- Position pinning (DECISION-0017): `pinned_positions_jsonb` capturing `{position_id, kind, git_sha}` for every node and adapter referenced by the solution at deploy time.
- Hosting mode (DECISION-0008): `deployment.mode` field already established; persisted on the receipt as well.
- Existing scaffold fields preserved: `actor_sub`, `classification`, `replica_count`.

The "never expires" semantic from the artifact is operationalized as: this table is **append-only by convention** (no UPDATE or DELETE in application code paths). Audit-immutability enforcement (DB-level constraint, row-level policy, or table-level WORM lock) is deferred to the COMPLIANCE area arbitration where AU-9 (audit append-only) is explicitly addressed and the right enforcement mechanism is selected.

### SMARTS rationale

Scalable, Maintainable, and Reliable lenses favor the rename + full field set strongly. Receipt query patterns (e.g., "find every deployment of solution X with `pin_health_status = degraded`") are first-class queryable fields rather than JSONB scans. Maintainable benefits from one migration vs. two (today's rename + Doc 2 fields, vs. a future receipt-table-split). Reliable benefits from NOT NULL pinned_artifacts and NOT NULL pinned_positions_jsonb — a deployment cannot be recorded without the reproducibility metadata. Securable benefits from receipts being audit-adjacent and explicitly named as such; the future audit-immutability enforcement (deferred to COMPLIANCE area) has a clearer target. The rename churn is small at S1 (no production data; ~2 route handlers; ~3 test files) and preferable to a permanent name-vs-semantics drift.

### Implementation implication

- Drizzle migration to `backend/drizzle/migrations/` (CODEOWNERS protocol):
  - Rename table `deployments` → `deployment_receipts`.
  - Add the artifact-required fields and the upstream-decision-obligated fields listed in the Decision section.
  - Apply `withTenant()` per DECISION-0011.
  - Indices: `(tenant_id, solution_id)`, `(tenant_id, status)`, `(tenant_id, pin_health_status)`, `(tenant_id, completed_at DESC)` for receipt queries.
- Update Drizzle schema (`backend/src/db/schema.ts`) — export `deploymentReceipts` table; remove `deployments`.
- Update routes:
  - `backend/src/routes/deployments.ts` → rename to `deployment-receipts.ts`; URL paths likewise (`/api/deployments` → `/api/deployment-receipts`). Frontend consumers updated in lockstep.
  - All handler logic now writes the full receipt schema; populating fields is handler-by-handler responsibility.
- Update frontend:
  - Loaders, components, and types referencing `deployment` rename to `deploymentReceipt` (or keep `deployment` semantically if UI vocabulary doesn't match server vocabulary, but cite the mismatch in code comments — preferred not to drift).
- Application-layer rule: this table is append-only. Add a Semgrep or vitest static check that fails any `db.update(deploymentReceipts)` or `db.delete(deploymentReceipts)` call in `backend/src/`. The exception is the deploy-progression handler that mutates `status` from `pending` → `running` → `completed` / `failed` until the receipt is finalized; that path uses an explicitly allowlisted helper.
- Z-AUDIT extension: every receipt insert and finalization emits a `deployment.receipt.recorded` audit event with the full receipt JSON. Audit-spec.md updated.
- Tests: receipt round-trip (insert + read preserves all snapshot fields); append-only enforcement (update on a finalized receipt rejected); FK integrity with `solution_id` and `environment_id`; tenant scoping; receipt-snapshot consolidation (each upstream-decision field is captured at deploy time, not derived later).

---

## DECISION-0019 — STATE.ENVIRONMENT-PROFILE — Build environments + env_variables tables with value/secret_ref constraint and variables_schema versioning hedge

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STATE.ENVIRONMENT-PROFILE
**Artifact-section-hash:** cd0cdb9409cbbfe346c4dfdc8fa5990fd05ae0a1a61b4d68bafb65bf7479b809

### Variance summary

- **Artifact position:** `environments` table with `id`, `tenant_id`, `name`, `target_type` (enum `aws | vmware | baremetal | hybrid`), `variables_schema` (JSONB), `trusted_for_active_checks` (boolean). `env_variables` table with the constraint that exactly one of `value` or `secret_ref` is set per row (Doc 1 §3.4; Doc 2 §3; Task Backlog MVP1.DB.007-008).
- **Scaffold position:** Silent — no `environments` table, no `env_variables` table.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position with a variables_schema versioning MOSA hedge.

`environments` table (per artifact + DECISION-0011 tenant scoping):
- Columns: `id` (UUID PK), `tenant_id` (via `withTenant()`), `name`, `target_type` (enum), `variables_schema` (JSONB), `trusted_for_active_checks` (BOOLEAN DEFAULT FALSE).
- The `variables_schema` JSONB shape MUST include a top-level `schema_version` integer (start at `1`) reserving the format-evolution lane — same pattern as DECISION-0013's `pin_protocol_version`. When variables_schema needs to grow new variable kinds (typed enums, validation rules, default-value resolution), V2 schemas coexist with V1 instead of forcing a rewrite.

`env_variables` table:
- Columns: `id` (UUID PK), `environment_id` (FK), `tenant_id` (via `withTenant()`), `name`, `value` (TEXT NULLABLE), `secret_ref` (TEXT NULLABLE), `value_kind` (enum `plain | reference | masked-default`).
- DB CHECK constraint: `(value IS NOT NULL) <> (secret_ref IS NOT NULL)` — exactly one of the two set.
- `secret_ref` semantics: until OpenBao is bundled (V1+ per `STACK.SECRETS.V1`), `secret_ref` points at an AWS Secrets Manager ARN per CLAUDE.md §3 + `docs/secrets-and-keys.md`. After OpenBao, the ref shape may extend; the abstract `secret_ref` resolver lives behind a small interface (per the same MOSA pattern as DECISION-0010's worker abstraction).

### SMARTS rationale

Maintainable, Reliable, and Securable lenses favor adoption strongly. The `exactly one of value or secret_ref` constraint is defense-grade: secrets cannot accidentally be stored as plaintext in the `value` column because the DB rejects rows where both are set, and the application path for "this is a secret" routes through `secret_ref` resolution (which logs to Z-AUDIT per CLAUDE.md §3). The variables_schema versioning hedge follows the established `feedback_mosa_evolvability.md` pattern — one extra integer field today reserves a future evolution lane that would otherwise require migrating every environment row when variables_schema needs to grow. The decision compounds with DECISION-0007 (OPA decisions can include environment-scoped attributes), DECISION-0014 (pre-flight wizard binds solution to environment, so env tables are a hard prerequisite), DECISION-0018 (deployment receipts FK to environment_id).

### Implementation implication

- Drizzle migration to `backend/drizzle/migrations/` (CODEOWNERS protocol):
  - `environments` table per columns above; `withTenant()` from DECISION-0011.
  - `env_variables` table per columns above with DB CHECK constraint.
  - Indices: `environments(tenant_id, name)` UNIQUE; `env_variables(environment_id)`; `env_variables(tenant_id, environment_id, name)` UNIQUE.
- Define the `variables_schema` JSONB Zod shape in `backend/src/db/types/variables-schema.ts`:
  ```ts
  z.object({
    schema_version: z.literal(1),
    variables: z.record(z.object({
      kind: z.enum(['string', 'integer', 'secret', 'boolean']),
      required: z.boolean(),
      default: z.unknown().optional(),
    })),
  });
  ```
- Add `backend/src/secrets/resolver.ts` exposing `resolveSecretRef(ref: string): Promise<string>` — returns the resolved secret value. Implementation today calls AWS Secrets Manager; future OpenBao implementation swaps the body. Every call emits a Z-AUDIT `secret.resolved` event per CLAUDE.md §3 + `docs/audit-spec.md`. NEVER log the value itself.
- Routes for environments (`backend/src/routes/environments.ts`): create/list/update/delete env profiles; never returns `secret_ref` resolved values in API responses (only the ref itself).
- Frontend wizard step 2 (environment selection) consumes the `environments` table; per-variable input uses the `variables_schema` shape to render typed inputs.
- Tests: CHECK constraint rejects rows with both value and secret_ref; both-null rejected; schema_version validation on variables_schema; secret_ref resolver returns value (mocked) and emits audit event; tenant scoping on all queries.

---

## DECISION-0020 — STATE.AUDIT-TRANSPORT — Close OPEN decision: ship MVP1 at S1 (HTTP→Postgres) with append-only audit_events and S2 transition gated on Stage 2 entry

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** STATE.AUDIT-TRANSPORT
**Artifact-section-hash:** 4dac308794a95cc875470eda4148155ea2660baab6ff8f9c9ecbd101c4edf03a

### Variance summary

- **Artifact position:** OPEN — Doc 1 §3.8 + §8.2 explicitly defer the MVP1 audit transport choice to arbitration. Architecture supports either S1 (HTTP POST direct sink) or S2 (NATS JetStream persistent stream) per ADR-0003; the abstract `audit.emit()` interface makes the transition mechanical.
- **Scaffold position:** `backend/src/lib/audit/index.ts` implements S1 — `httpPost(sinkUrl, event)` to env-configured `AUDIT_SINK_URL`. No NATS dependency.
- **Status type:** open-decision-closure (per `references/known-open-decisions.md` standardized handling — scaffold implements an artifact-listed alternative).

### Decision

Close the open decision in favor of S1 (HTTP→Postgres direct sink) for MVP1. The scaffold's existing implementation stands; no transport rewrite is required. S2 (NATS JetStream) transition is **gated on Stage 2 entry** per CLAUDE.md §1's stage-promotion criteria.

Implementation tightening at MVP1:

- The Postgres sink table `audit_events` MUST be tenant-scoped via the `withTenant()` helper from DECISION-0011. Every audit event carries `tenant_id`.
- The table is **append-only**. Same convention pattern as `deployment_receipts` from DECISION-0018: a Semgrep or vitest static check fails any `db.update(auditEvents)` or `db.delete(auditEvents)` call. DB-level enforcement (row-level policy, table-level WORM lock, or triggers blocking UPDATE/DELETE) is selected and applied during the COMPLIANCE area arbitration where AU-9 enforcement is explicitly addressed.
- The `audit.emit()` interface in `backend/src/lib/audit/index.ts` remains abstract; the `httpPost` implementation is the S1 transport. No caller in `backend/src/` may import HTTP transport details directly.
- `docs/audit-spec.md` is updated to record:
  - Current transport: S1 (HTTP→Postgres direct sink).
  - S2 transition trigger: Stage 2 promotion entry (first non-team GDIT user OR codebase >15K LOC OR >5 contributors per CLAUDE.md §1). At Stage 2 entry, the abstract `audit.emit()` body swaps to NATS JetStream publish; callers do not change.

### SMARTS rationale

Maintainable, Reliable, and Testable favor S1 closure at MVP1. NATS JetStream's at-least-once delivery and persistent-stream semantics solve scaling problems FUSION does not have at S1 (5 internal users, single FUSION instance, $300K MVP1 budget, 6-week window). Adding NATS now adds ~2 days of operational standup with no S1-user benefit and no architectural correctness gain — ADR-0003 already documents the architecture as transport-agnostic. The MOSA structure is preserved by the existing `audit.emit()` interface: the S2 transition becomes a one-file swap of the transport implementation, not a caller-side rewrite. Reliable favors S1 because synchronous-write-to-Postgres failure modes are well-understood and inherited from the bundled DB; NATS would surface at-least-once duplicate-handling bugs early when there are no real audit consumers stressing the system. Securable is adequate for both options at MVP1; Postgres trigger-based append-only enforcement satisfies AU-9 at S1 and is replaced by the S2 NATS KV ordering guarantees at promotion. CLAUDE.md §0 hierarchy: ergonomics-velocity (level 5) yields to security-compliance (level 1), but level 1 is satisfied by either option, so level 4 (performance) and level 5 (velocity) settle the choice in favor of S1 at this stage.

### Implementation implication

- Drizzle migration to `backend/drizzle/migrations/` (CODEOWNERS protocol):
  - `audit_events` table with `tenant_id` (via `withTenant()`), `event_id` (UUID PK, deterministic where applicable per DECISION-0016 idempotency pattern), `event_kind`, `event_time` (timestamptz), `actor_id`, `outcome`, `event_payload` (JSONB), `received_at` (timestamptz default now()).
  - Indices: `(tenant_id, event_time DESC)`, `(tenant_id, event_kind, event_time DESC)`.
- Update `backend/src/lib/audit/index.ts`:
  - `audit.emit()` continues to dispatch to `httpPost` for the S1 transport, OR (preferred for MVP1 simplicity) writes directly to the bundled Postgres `audit_events` table via the same Drizzle connection. The "HTTP POST to AUDIT_SINK_URL" indirection is retained as a configurable transport, but the default value of `AUDIT_SINK_URL` is set such that the bundled FUSION app's own `/internal/audit-sink` route receives and persists.
  - Add `tenant_id` to every emitted event (sourced from request context).
- Add Semgrep rule `javascript.lang.security.audit.no-update-audit-events` failing any `update(auditEvents)` or `delete(auditEvents)` call.
- Update `docs/audit-spec.md` with the S1 transport documentation and the S2 transition trigger language.
- Tests: append-only enforcement (update/delete on auditEvents rejected); tenant scoping on emit; round-trip emit→read; `audit.emit()` abstract interface contract test exercising the transport-agnostic shape (so the S2 NATS swap is testable when it lands).
- ADR-0003 status updated to reflect that MVP1 ships at S1 by this decision; ADR remains accepted in its architectural posture.

---

## DECISION-0021 — SCHEMA.SOLUTION-MANIFEST — Author schemas/solution.schema.json now matching MVP1.LIB.008

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** SCHEMA.SOLUTION-MANIFEST
**Artifact-section-hash:** b765a638b595403d42b8085e54410042513d591610479212fc13905b7612ca33

### Variance summary

- **Artifact position:** Solution composition format with pinned `node_git_sha`, `adapter_git_sha`, environment binding, project metadata, sub-solution composition references — formal JSON Schema deliverable per Doc 1 §3.7 + Task Backlog MVP1.LIB.008.
- **Scaffold position:** No `schemas/solution.schema.json`; `solutions.graph` is JSONB at the application layer, typed loosely.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position. Author `schemas/solution.schema.json` now, co-located with the existing `schemas/node.schema.json` and `schemas/adapter.schema.json`. The schema MUST encode the relational shape produced by DECISION-0017's split (`solution_nodes` + `solution_edges` with stable `position_id`), the `tenant_id` discriminator from DECISION-0011, the `environment_id` FK from DECISION-0019, and the `external_dependencies[]` array from DECISION-0014. The schema becomes the single validation source for the per-solution Gitea repo manifest, the deploy-worker loader, the UI loader, and any future SBOM/receipt exporter.

### SMARTS rationale

Maintainable, Reliable, and Testable favor adoption strongly. A formal JSON Schema means every consumer (UI loader, deploy worker, SBOM exporter, audit query path) validates the manifest against the same definition rather than implementing its own ad-hoc parser — eliminating the drift surface that JSONB-typed-loosely creates. Reliable benefits because manifest validity is caught at parse time at every consumer, not at the first downstream operation that depends on a missing field. Testable benefits because JSON Schema fixtures are first-class in vitest and the existing `make validate-definitions` invocation is a one-line addition. Securable is adequate at MVP1 (manifest contents are not secrets) but the schema also encodes the `tenant_id` requirement that supports future row-level security work. The Defer option carries no SMARTS upside that is not strictly negative-leverage given DECISION-0017 has already split the relational shape.

### Implementation implication

- Author `schemas/solution.schema.json` matching MVP1.LIB.008 deliverable. Include: `name`, `version`, `tenant_id`, `git_sha` (commit-pinned), `deployment_target` enum, `environment_id`, `nodes[]` (each with `node_id`, `node_git_sha`, `position_id`, `position_x`, `position_y`, `variables_ref`), `edges[]` (each with `source_position_id`, `target_position_id`, `adapter_id`, `adapter_git_sha`), `external_dependencies[]` (per DECISION-0014: `kind`, `check_tier`, `endpoint`, `expected_state`), `sub_solutions[]` (per copy-on-import pattern §6.3), `classification` enum, `metadata.schema_version`.
- Wire schema into `make validate-definitions` (already invokes `node.schema.json` and `adapter.schema.json` per CLAUDE.md §9). The script-shape ADR-0004 violation (inline Python in Makefile, F-007) is addressed in a separate downstream variance (CI.* area); this decision adds the schema file regardless of which language hosts the validator.
- Add `backend/src/__tests__/solution-schema.test.ts` asserting valid fixtures pass and invalid fixtures (missing required field, malformed git_sha, unknown classification) fail with parse-time errors.
- The frontend `solutionLoader.ts` and `DeployWizardLoader.ts` swap their loose `as SolutionType` casts for schema-driven Zod parses (cascades from F-018 closure).
- Co-located validators: backend uses `ajv` per ADR-0004's already-decided JSON Schema validation library posture (Z-API consumer); frontend imports the same `.schema.json` and parses via `zod-from-json-schema` or equivalent for shared single-source semantics.
- CHANGELOG `[Unreleased]` records the new schema authoring; F-019 cascade closure tracking continues separately.

---

## DECISION-0022 — SCHEMA.NODE-DEFINITION — Add required teardown_capability enum to schemas/node.schema.json (cascade from D12)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** SCHEMA.NODE-DEFINITION
**Artifact-section-hash:** ee1938a8d0020a882313e92fdf11f182270767dc3c8132fbb72172332fa9ae94

### Variance summary

- **Artifact position:** `definition.yaml` MUST declare `variables_schema`, `valid_connections`, `criticality`, `teardown_procedure` AND `teardown_capability` enum (`clean | partial | manual`) per Doc 1 §6.4 reversal-tier discriminator.
- **Scaffold position:** `schemas/node.schema.json` has all listed fields except `teardown_capability` enum.
- **Status type:** divergent

### Decision

Adopt the artifact position. Add `teardown_capability` as a required string enum (`clean | partial | manual`) to `schemas/node.schema.json`. The enum value flows into the publication gate (nodes with `manual` require elevated permission per §6.4) and into deployment-receipt records (per DECISION-0012's tier-at-deploy capture). Update `docs/domain.md` to list `teardown_capability` as a fifth required field on the node directory contract.

### SMARTS rationale

This decision is the schema-layer cascade of DECISION-0012 (PATTERN.REVERSAL-TIERS). The same SMARTS dynamic applies: Maintainable, Reliable, Testable, and Securable all favor the enum strongly because it is the single discriminator the publication gate, deploy worker, and deployment-receipt all branch on. The hybrid option (optional with default `partial`) was rejected because it allows a node author to silently slip a manual-teardown node past the gate by omitting the field — defeating the §6.4 "elevated permission required" enforcement at its source. The Defer/scaffold option leaves D12 functionally unimplemented at the schema layer.

### Implementation implication

- Edit `schemas/node.schema.json`: add `teardown_capability` to `required[]` and to `properties` as `{ "type": "string", "enum": ["clean", "partial", "manual"] }`.
- Edit `docs/domain.md`: extend the node `definition.yaml` field list to include `teardown_capability`.
- `make validate-definitions` will start failing on existing node definition.yaml files that lack the field — but no node files exist yet (`fusion-nodes/` is absent per CLAUDE.md §8 and checkpoint F-046), so there is no migration burden at MVP1.
- Add `backend/src/__tests__/definitions.test.ts` cases (file is absent per F-007; this decision adds one of the test cases that file must contain when authored): valid node fixture with each enum value passes; node fixture missing `teardown_capability` fails parse; node fixture with unknown enum value (e.g., `irreversible`) fails parse.
- Publication-gate scaffold (Spike 6 in Doc 2 §9) will branch on this enum once the gate is built; record the cascade in the spike's prerequisites.
- Deploy-worker (per D10 ExecutionWorker interface) records the enum value into `deployment_receipts.teardown_tier_at_deploy` per D12's capture obligation.

---

## DECISION-0023 — SCHEMA.ADAPTER-DEFINITION — Hybrid: add cascade fields (criticality, teardown_capability); defer adapter_kind until samples exist

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** SCHEMA.ADAPTER-DEFINITION
**Artifact-section-hash:** ee1938a8d0020a882313e92fdf11f182270767dc3c8132fbb72172332fa9ae94

### Variance summary

- **Artifact position:** Adapter definition with `source_type`, `target_type`, `adapter_kind` (Doc 2 §3 discriminator), `tier`/`priority_tier`, `criticality`, `teardown_capability`, `variables_schema`.
- **Scaffold position:** `schemas/adapter.schema.json` has `kind, name, version, source_type, target_type, variables_schema, priority_tier`; lacks `adapter_kind`, `criticality`, `teardown_capability`.
- **Status type:** divergent

### Decision

Hybrid resolution. Add `criticality` and `teardown_capability` (both required string enums, mirroring the node schema decision in DECISION-0022) as a direct cascade from DECISION-0012 (PATTERN.REVERSAL-TIERS). Defer `adapter_kind` until at least three real adapter implementations exist in `fusion-adapters/` OR until V1 planning, whichever arrives first — at which point the enum is designed once against actual samples rather than predicted. Document `adapter_kind` in a follow-up decision when the deferral trigger fires.

### SMARTS rationale

Maintainable and Reliable favor the cascade fields strongly for the same reasons recorded in DECISION-0022 — the publication gate, deploy worker, and deployment-receipt all branch on these enums and prose-only is unfit for branching. `adapter_kind` carries a different SMARTS profile: the marginal Maintainable benefit of having it now is overwhelmed by the migration cost asymmetry. Adding `adapter_kind` later is a non-breaking additive optional field; shipping it now and then renaming or restructuring its enum (when real samples reveal the wrong cuts) requires migrating every adapter file in every solution-repo. With `fusion-adapters/` empty (CLAUDE.md §8, F-046) there is zero implementation evidence to design the enum against. Securable is satisfied by the cascade fields alone — `adapter_kind` does not directly serve an audit class. The deferral preserves all future options at almost zero cost.

### Implementation implication

- Edit `schemas/adapter.schema.json`: add `criticality` (`{ "type": "string", "enum": ["critical_path", "non_critical"] }`) and `teardown_capability` (`{ "type": "string", "enum": ["clean", "partial", "manual"] }`) to `required[]` and `properties`.
- `make validate-definitions` will start failing on any adapter definition.yaml lacking these fields — but `fusion-adapters/` is absent at MVP1 so there is no migration burden.
- Add `backend/src/__tests__/definitions.test.ts` cases for the adapter schema mirroring the node tests from DECISION-0022.
- Record a deferred follow-up: when the third adapter lands in `fusion-adapters/` OR V1 planning begins, re-arbitrate `SCHEMA.ADAPTER-KIND-ENUM` against the accumulated samples. Until then, the field is intentionally absent from the schema.
- Update `docs/domain.md` to list `criticality` and `teardown_capability` on the adapter directory contract; explicitly note that `adapter_kind` is reserved for future use.
- Cascade traceability: this decision references the same `Artifact-section-hash` as DECISION-0012 and DECISION-0022 because the `teardown_capability` enum's authoritative definitional section is Doc 1 §6.4. The `adapter_kind` portion of the original variance is intentionally not adopted by this decision; its eventual decision will hash a different section once the artifact is updated to specify the enum values.

---

## DECISION-0024 — SCHEMA.ENVIRONMENT-PROFILE — Author schemas/environment-profile.schema.json now (cascade from D19)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** SCHEMA.ENVIRONMENT-PROFILE
**Artifact-section-hash:** f2af8e1564215f2253418a7effffd7eb65696b95347def819caa59f705cf6878

### Variance summary

- **Artifact position:** `environments` schema with `target_type` enum (`aws | vmware | baremetal | hybrid`), `variables_schema` (JSONB), `trusted_for_active_checks` flag, plus the `withTenant()` and `value` XOR `secret_ref` invariants from DECISION-0019.
- **Scaffold position:** No environment schema (DB or JSON Schema).
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position. Author `schemas/environment-profile.schema.json` co-located with `node`, `adapter`, and `solution` schemas. The schema encodes the full DECISION-0019 design — `id`, `tenant_id`, `name`, `target_type` enum, `variables_schema` (with `schema_version` integer per the MOSA hedge), `trusted_for_active_checks` boolean — plus the `env_variables` sub-resource shape that enforces the `value` XOR `secret_ref` invariant at the application layer in addition to the Postgres CHECK constraint. The schema is consumed by the deploy-wizard pre-flight step (per DECISION-0014's pre-flight wizard), the deploy worker's variable resolver, and any future env-profile import/export tool.

### SMARTS rationale

Maintainable and Reliable favor adoption strongly for the same cascade reason as DECISION-0021 (SCHEMA.SOLUTION-MANIFEST) — multiple consumers (deploy-wizard, deploy-worker, future import/export) need a single shape definition rather than each re-implementing the env-profile parser. Securable adds a defense-in-depth dimension here: encoding the `value` XOR `secret_ref` invariant in the JSON Schema means the application catches the violation before the row reaches Postgres, and the Postgres CHECK constraint catches anything that bypasses the application layer. Two independent enforcement points for one invariant at the cost of one schema definition. Testable benefits from fixture-based testing of every enum value and the XOR invariant edge cases. The Defer option carries no SMARTS upside given DECISION-0019 has already designed the table shape — the schema is mechanical follow-through.

### Implementation implication

- Author `schemas/environment-profile.schema.json`. Top-level definition: `Environment` with required `id`, `tenant_id`, `name`, `target_type` (enum), `variables_schema` (referencing the existing JSONB shape from DECISION-0019), `trusted_for_active_checks`. Nested definition: `EnvironmentVariable` with required `env_id`, `name`, `value_kind` (enum: `plain | reference | masked-default`), and a oneOf constraint encoding `value XOR secret_ref`.
- Wire the schema into `make validate-definitions` alongside `node` and `adapter`.
- Add `backend/src/__tests__/environment-schema.test.ts` cases: valid env with each `target_type`; XOR invariant rejects rows with both `value` and `secret_ref`; XOR invariant rejects rows with neither; unknown `target_type` enum value rejected; `schema_version` mismatch rejected per DECISION-0019.
- Frontend `DeployWizardLoader.ts` step 2 (environment selection) imports `schemas/environment-profile.schema.json` and parses via `zod-from-json-schema` for shared single-source semantics — same pattern as DECISION-0021's solution-manifest consumers.
- Update `docs/data-model.md` to reference the JSON Schema as the application-layer source of truth alongside the Drizzle schema definition.
- CHANGELOG `[Unreleased]` records the new schema authoring.

---

## DECISION-0025 — SCHEMA.DEPLOYMENT-RECEIPT — Author schemas/deployment-receipt.schema.json now (cascade from D18)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** SCHEMA.DEPLOYMENT-RECEIPT
**Artifact-section-hash:** f2af8e1564215f2253418a7effffd7eb65696b95347def819caa59f705cf6878

### Variance summary

- **Artifact position:** Deployment-receipt JSON Schema mirroring the table structure consolidated in DECISION-0018 (rename `deployments` → `deployment_receipts`; consolidated snapshot fields; signed; immutable) plus DECISION-0012's `teardown_tier_at_deploy` capture and DECISION-0013's `pin_health_status` / `solution_age_status` columns.
- **Scaffold position:** No JSON Schema for the receipt structure. Drizzle schema in `backend/src/db/schema.ts` is the only definition.
- **Status type:** divergent (per variance report; effectively scaffold-silent at the JSON Schema layer)

### Decision

Adopt the artifact position. Author `schemas/deployment-receipt.schema.json` co-located with the other MVP1 schemas. Required fields: `id`, `tenant_id`, `solution_id`, `solution_git_sha` (40-char hex), `environment_id` (FK per DECISION-0019), `started_at`, `completed_at`, `status` enum, `pinned_artifacts` (JSONB shape per DECISION-0013), `solution_last_tested`, `solution_age_status`, `pin_health_status`, `teardown_tier_at_deploy` enum (per DECISION-0012), `snapshot_sha256` (64-char hex), `snapshot_signature` (cosign signature), `snapshot_blob_ref` (S3 ARN @S3+; local path @S1), `final_logs_ref`, `classification`, `metadata.schema_version`. The schema becomes the portable contract that external SBOM/audit tooling parses against and that the cosign signature verification step uses to reproduce the canonical-form bytes.

### SMARTS rationale

Securable carries the strongest weight here, distinct from the other SCHEMA-area decisions: receipts are signed (per `docs/data-model.md` — cosign over the receipt; SHA-256 stored in row), and a portable JSON Schema lets an external verifier (ATO assessor, auditor, customer compliance pipeline) reproduce the signature check without owning the FUSION TypeScript types. Maintainable favors adoption alongside the other four MVP1 schemas because batching the schemas now amortizes the validation infrastructure (`make validate-definitions`, fixture conventions) over five files instead of one. Reliable benefits because receipt-emission code can validate the receipt against the schema before computing the signature — preventing the class of bug where a malformed receipt is signed and then fails downstream verification. Testable benefits from fixture-based testing of every status enum and every snapshot variant. Defer was rejected because adding the schema later means refactoring receipt-emission and signature-canonicalization code paths; the cost of doing it now is small.

### Implementation implication

- Author `schemas/deployment-receipt.schema.json`. Include the consolidated fields from D12, D13, D14, D17, D18, D19. Encode the immutability invariant as documentation in the schema description (immutability is enforced at the Postgres trigger layer per `docs/data-model.md`, not at the schema layer).
- Wire schema into `make validate-definitions`.
- Add `backend/src/__tests__/deployment-receipt-schema.test.ts` cases: valid receipts with each status; missing `solution_git_sha` rejected; malformed `snapshot_sha256` (not 64-char hex) rejected; unknown `teardown_tier_at_deploy` enum rejected; `metadata.schema_version` mismatch rejected.
- Update receipt-emission code path (post-deploy worker step, currently absent — gated behind D10 worker abstraction) to validate the receipt against the schema before computing `snapshot_sha256` and signing. The validation MUST happen on the canonical-form bytes that get signed — otherwise signature verification by an external party diverges from emitter-side validation.
- Update `docs/data-model.md` to reference `schemas/deployment-receipt.schema.json` as the portable artifact alongside the Drizzle schema and the immutability trigger contract.
- CHANGELOG `[Unreleased]`: record the new schema authoring; note that this completes the SCHEMA-area cascade closure for D12, D13, D14, D17, D18, D19.

---

## DECISION-0026 — API.AUTHZ.OPA-CALL — Build authz.can() helper + Fastify preHandler on every write route (cascade from D7)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** API.AUTHZ.OPA-CALL
**Artifact-section-hash:** 80b48226fa205e96b44883da14c13d30a963ecfa79ac7154a8e7bc559c32eb3e

### Variance summary

- **Artifact position:** `authz.can(user, action, resource)` calls OPA on every authorized action; every POST/PUT/DELETE calls `authz.can()` before proceeding (Doc 1 §3.6 + Doc 2 §6 + Task Backlog MVP1.AUTH.008 + MVP1.API.014).
- **Scaffold position:** No OPA client; no `authz.*` helper; routes (`solutions.ts`, `deployments.ts`) have no authorization check beyond authentication.
- **Status type:** scaffold-silent

### Decision

Adopt the artifact position. Build `backend/src/lib/authz/index.ts` exposing `authz.can(user, action, resource): Promise<{ allowed: boolean; reason?: string }>`. The helper calls the bundled OPA HTTP endpoint (per DECISION-0007's bundled-OPA + engine-isolation hedge), composes the OPA input from `(user, action, resource)`, and emits both `authz.allowed` and `authz.denied` events to Z-AUDIT per DECISION-0007's allow+deny audit hedge. Wire `authz.can()` as a Fastify `preHandler` on every POST/PUT/DELETE route in `backend/src/routes/`. Pre-flight failure (OPA unreachable) follows DECISION-0007's fail-closed posture: the route returns 503 and emits a `authz.denied` event with `reason=engine_unreachable`.

### SMARTS rationale

Securable carries the strongest weight: AC-3 (RBAC at the API layer with deny-by-default, per `docs/security-controls.md`) is unenforced at the implementation layer until this decision lands, even though DECISION-0007 has already chosen the engine. Maintainable favors a single helper + uniform `preHandler` registration over per-route ad-hoc checks because future audit-rule additions (e.g., AREA 9 COMPLIANCE arbitration may add deny-class severity escalations) become a one-file edit. Reliable benefits from the deny-by-default semantics — a route that forgets to register the `preHandler` fails the existing CI gate (DECISION-0001's CI.ZOD-ROUTE-COVERAGE follow-on can be extended to enforce `preHandler: [requireAuthz(action, resource)]` coverage). Testable benefits because `authz.can()` is mockable in route tests with a fake OPA decision. The Defer option carries a real AC-3 enforcement gap that grows in cost the longer routes accumulate.

### Implementation implication

- Author `backend/src/lib/authz/index.ts` exposing `authz.can(user, action, resource)`. Implementation calls the bundled OPA `POST /v1/data/<package>/allow` per the package layout decided in DECISION-0007's phased policy build. Returns `{ allowed: boolean; reason?: string }`.
- Author `backend/src/lib/authz/preHandler.ts` exposing `requireAuthz(action: string, resourceFn: (req) => Resource)` factory that returns a Fastify preHandler. The factory binds the action statically and lets the resource be derived from the request (e.g., `(req) => ({ kind: 'solution', id: req.params.id })`).
- Wire the preHandler on every POST/PUT/DELETE route in `backend/src/routes/{solutions,deployments,environments}.ts`. GET routes skip the preHandler at MVP1 (read-side authorization can be added in V1 if needed; the OPA package can already handle it).
- Both allow and deny outcomes emit to Z-AUDIT via `audit.emit()` per DECISION-0007's allow+deny hedge. Allow events use `action=authz.allowed` (severity_id=1, class_uid=3002); deny events use existing `authz.denied` (severity_id=3, class_uid=3002 per `docs/audit-spec.md` action registry).
- OPA unreachable → fail closed: route returns 503; emit `authz.denied` with `reason=engine_unreachable`. This matches DECISION-0007's fail-closed posture and `docs/failure-handling.md` AuthZ-deny semantics.
- Test obligations per CLAUDE.md §9: `backend/src/__tests__/authz.test.ts` covers happy-path allow, happy-path deny, OPA unreachable fail-closed, audit-emit assertion (both outcomes), and the preHandler unit. Each route's existing test file gains an "unauthorized request returns 403" case asserting `authz.denied` was emitted.
- F-019 cascade tracking: this decision is *adjacent* to but distinct from DECISION-0001's Zod-route schema sweep — both touch the same routes, but the Zod sweep registers `schema:` while this decision registers `preHandler:`. The two should land in coordinated PRs to avoid touching the same files twice.
- Post-MVP1 evolvability: DECISION-0007's engine-isolation MOSA hedge means the `authz.can()` helper is the single seam if OPA is later swapped for Cedar or another engine. Routes do not import OPA-specific types — only the abstract `{ allowed, reason }` shape.

---

## DECISION-0027 — API.VALIDATION.ZOD-ROUTES — Execute the route sweep at MVP1 (cascade from D1; closes F-019)

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** API.VALIDATION.ZOD-ROUTES
**Artifact-section-hash:** 69536e272ba5e292d9283216486705b665174b706df5fb5e3761b4f99f894745

### Variance summary

- **Artifact position:** Every backend route registers `schema: { body, response }` using Zod-derived JSON Schema, per Doc 1 §3.2 + DECISION-0001's policy decision and the F-019 closure commitment in CHANGELOG `[Unreleased]`.
- **Scaffold position:** Routes (`solutions.ts:11,23`; `deployments.ts:21,47`) use manual `safeParse`/`parse` inside handlers; no route registers `schema:` on its Fastify route definition.
- **Status type:** divergent

### Decision

Adopt the artifact position with execution scheduled at MVP1, not deferred. Sweep all current backend routes (`backend/src/routes/{solutions,deployments,health}.ts`, plus the new `environments.ts` route added per DECISION-0019, plus any routes added by DECISION-0026's authz preHandler work) to register `schema: { body, response }` using JSON Schema derived from existing Zod schemas via `zod-to-json-schema`. Drop the manual `safeParse`/`parse` calls inside handlers — Fastify's per-route validation runs the schema before the handler executes, eliminating the duplicate validation surface. Land the sweep in coordination with DECISION-0026's preHandler sweep so both route-modifying changes touch each file once.

### SMARTS rationale

Maintainable, Reliable, and Securable all favor execution at MVP1 strongly for the same reasons documented in DECISION-0001. The marginal-cost argument tightens the case: every new route added without `schema:` registered enlarges the future sweep, and DECISION-0026 is itself a route-modifying change landing imminently. Performing both sweeps together means each route file is opened once and exits the PR with `schema:`, `preHandler:[requireAuthz]`, and audit instrumentation all wired. Deferring leaves F-019 open and creates a CI-gate impedance mismatch when AREA 8's `CI.ZOD-ROUTE-COVERAGE` arbitration lands — the gate would go red against accumulated debt on day one rather than catching new violations going forward. Testable benefits because route tests can assert that bad inputs produce the Fastify-emitted 400/422 with schema-conformant error bodies, rather than relying on manual `safeParse` test paths.

### Implementation implication

- Add `zod-to-json-schema` to `backend/package.json` (vet via `dependency-reviewer` per CLAUDE.md §6 + `docs/dependency-policy.md`; license is MIT).
- Sweep `backend/src/routes/solutions.ts`, `deployments.ts`, `health.ts` to add `schema: { body, response }` derived from the existing Zod schemas in `backend/src/schemas/`.
- Add the new `environments.ts` route per DECISION-0019 with `schema:` registered from day one.
- Drop the manual `safeParse`/`parse` calls inside route handlers — Fastify's per-route validation runs first, and request payloads are already typed against the Zod-derived schema.
- Coordinate the merge with DECISION-0026's preHandler sweep: target a single bundled PR that closes F-019 + lands the OPA preHandler + adds the environments route. The PR description cites both DECISION-0026 and DECISION-0027.
- Test obligations per CLAUDE.md §9: each route's existing test file gains a "malformed body returns 400 with schema-conformant error" case and an "undeclared response field stripped" case. The latter exercises `fast-json-stringify`'s response-stripping behavior and is the regression-prevention test for the original F-019 finding.
- CHANGELOG `[Unreleased]`: record the sweep + F-019 closure when the bundled PR lands.
- Future CI gate: `CI.ZOD-ROUTE-COVERAGE` (DECISION-0001's follow-on, pending arbitration in AREA 8) becomes green on first run because every route now satisfies it.

---

## DECISION-0028 — API.WEBSOCKET.OUTPUT-STREAM — Adopt SSE (Server-Sent Events) for live deployment output streaming; diverge from artifact's WebSocket mention

**Date:** 2026-05-07
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** API.WEBSOCKET.OUTPUT-STREAM
**Artifact-section-hash:** 69536e272ba5e292d9283216486705b665174b706df5fb5e3761b4f99f894745

### Variance summary

- **Artifact position:** `WS /api/deployments/:id/stream` streams stdout/stderr from Z-WORKER to frontend (Doc 1 §3.2 + §3.3 + §4.1; Doc 2 §3.3 line 109; Task Backlog MVP1.API.013, MVP1.EXEC.007, V1.LIB.002, V1.UI.004). Doc 1 §3.3 hedges to "WebSocket or pubsub" between Z-WORKER and Z-API; Z-API ↔ Z-FRONTEND is named without hedge.
- **Scaffold position:** No streaming endpoint of any kind. No WebSocket plugin (`@fastify/websocket`). No SSE handler.
- **Status type:** scaffold-silent (variance state at evidence collection time)

### Decision

Diverge from the artifact's WebSocket protocol choice. Adopt **Server-Sent Events (SSE)** as the live deployment output streaming protocol at MVP1 and forward. Implement `GET /api/deployments/:id/stream` returning `Content-Type: text/event-stream`; the handler streams stdout/stderr lines from Z-WORKER as `data: <line>\n\n` events on Fastify's `reply.raw` (or `reply.hijack()`), with an `event: status` channel for terminal job-state transitions. Frontend consumes via the native browser `EventSource` API (auto-reconnects via the spec) or a fetch-based polyfill that supports custom headers (so the existing OIDC `Authorization: Bearer <token>` flow works unmodified — no query-string token workaround). Amend the cited artifact sections to record SSE as the protocol; the Doc 1 §3.3 "WebSocket or pubsub" hedge is replaced with "SSE; pubsub between Z-WORKER and Z-API permitted at S2+ if required for fan-out."

### SMARTS rationale

This decision overrides the variance report's original "Adopt artifact, moderate" recommendation because deep-dive evidence surfaced facts the artifact author had not factored: (a) no rationale for WebSocket exists in any artifact, ADR, or decision document — the choice propagated as an unevaluated default; (b) the workspace-to-target deployment posture (cove@emergelabs VPC1 → cove.gdit VPC3 with corporate proxies) penalizes WebSocket disproportionately because many corporate proxies do not handle the upgrade negotiation cleanly while passing plain HTTP `text/event-stream` traffic without issue; (c) browser WebSocket auth-header support is awkward (no `Authorization` header during upgrade negotiation), forcing query-string-token workarounds that complicate audit-event correlation — SSE uses standard headers natively; (d) `@fastify/websocket` is a new dependency requiring vetting per CLAUDE.md §6 + `docs/dependency-policy.md`, while SSE requires zero new dependencies; (e) SSE has built-in reconnect via the `EventSource` spec; WebSocket reconnect must be hand-rolled. The SMARTS table evaluation favors SSE on Maintainable, Available, Reliable, Testable, and Securable; WebSocket and SSE tie on Scalable. A search of all artifacts for true bidirectional features returned zero — every "WebSocket push" reference in the artifacts is server-to-client only, which SSE handles natively. The Pushback Is Permitted principle in the arbiter skill explicitly enables this divergence when scaffold/evidence-side context surfaces what the artifact missed; the missed context here is concrete and material.

### Implementation implication

- Author `backend/src/routes/deployments-stream.ts` exposing `GET /api/deployments/:id/stream`. Handler validates the `:id` parameter (Zod), checks `authz.can(user, 'read', { kind: 'deployment', id })` per DECISION-0026, sets `Content-Type: text/event-stream`, `Cache-Control: no-cache`, `Connection: keep-alive` (the last has no semantic on HTTP/2 but is harmless and aids HTTP/1.1 proxies), then writes `data: <line>\n\n` for each output line and `event: status\ndata: <state-json>\n\n` for terminal job-state transitions.
- Source the output stream from the Postgres-backed pub/sub or Redis stream produced by Z-WORKER per Task Backlog MVP1.EXEC.007 (decision still pending in AREA 7 DEPLOY/EXEC; this decision uses whatever transport AREA 7 chooses for Worker → API).
- Frontend `frontend/src/loaders/deploymentStreamLoader.ts` consumes via `new EventSource('/api/deployments/<id>/stream')` for the simple case OR via a fetch-based polyfill (e.g., the `@microsoft/fetch-event-source` library — vet license/maintenance per dep-policy if adopted) when custom headers are needed for the Bearer token flow. The polyfill choice is deferred to the frontend-author at implementation time; both approaches are SSE-compliant.
- Step4Monitor.tsx (frontend deploy wizard) consumes the stream and renders per Task Backlog MVP1.UI.004; the rendering layer is protocol-agnostic and unaffected by the SSE-vs-WebSocket choice.
- **Artifact amendments required** (the user implements; this skill cannot modify the read-only artifacts per its What-It-Does-Not-Own contract):
  - Doc 1 §3.2: change "All HTTP and WebSocket endpoints" → "All HTTP endpoints, including SSE for live output streaming"; change "WebSocket relay between Z-WORKER output and Z-FRONTEND" → "SSE relay between Z-WORKER output and Z-FRONTEND".
  - Doc 1 §3.3: change "via WebSocket or pubsub" → "via pubsub at MVP1 (Z-API forwards as SSE to Z-FRONTEND); direct SSE permitted at V1+ if Z-WORKER is co-located with Z-API".
  - Doc 1 §4.1: rewrite the two "opens WebSocket" / "WebSocket URL" lines to "opens SSE stream" / "SSE URL".
  - Doc 1 §3.1: update the frontend "WebSocket consumption for live deployment output" to "SSE consumption for live deployment output".
  - Doc 2 line 109: change "Output streaming via WebSocket from worker → API → frontend" → "Output streaming via SSE from API → frontend (worker → API transport per AREA 7 decision)".
  - Doc 3 MVP1.API.013: rename the deliverable to "Implement SSE endpoint for live deployment output"; change `WS /api/deployments/:id/stream` → `GET /api/deployments/:id/stream` (text/event-stream).
  - Doc 3 MVP1.EXEC.007: change "Z-API forwards to WebSocket" → "Z-API forwards as SSE".
  - Doc 3 V1.LIB.002 (stale canvas push) and V1.UI.004 (platform notifications): change "WebSocket push" → "SSE push" — these are server→client features that SSE handles natively.
- **Out-of-scope for this decision but noted:** if a true bidirectional feature is identified at V1+ (e.g., user cancellation pushed mid-deployment, real-time collaborative canvas editing), that feature can introduce WebSocket alongside SSE without disturbing this decision — they are not mutually exclusive at the protocol layer. The decision to adopt WebSocket would be its own ADR + arbiter entry.
- **Stale-detection note for future runs:** this decision's `Artifact-section-hash` anchors to Doc 1 §3.2 (the primary deviated-from section). When the user amends Doc 1 §3.2 to record the SSE choice per the bullet above, §3.2's content changes and Stage 1.5 of a future arbiter run will flag this entry for re-evaluation. The expected resolution is "Keep as-is" — the decision still applies; the artifact has merely caught up to it. The arbiter user updates the recorded hash to the new §3.2 content per the Stage 1.5 protocol.
- Test obligations per CLAUDE.md §9: `backend/src/__tests__/deployments-stream.test.ts` covers happy-path multi-line streaming (asserts `data: <line>\n\n` framing), terminal state event emission, unauthorized request → 403 + audit `authz.denied`, malformed `:id` → 400, and a backpressure smoke test (stream survives a slow consumer). Frontend `Step4Monitor.test.tsx` adds an EventSource mock that asserts the wizard renders incremental output and transitions to terminal state on the `status` event channel.
- CHANGELOG `[Unreleased]`: record the SSE adoption + the divergence-with-evidence; cite the arbiter decision ID.

---

## DECISION-0029 — META.STALE-ARTIFACT-RESOLUTION — Bulk keep-as-is: re-calibrate artifact-section hashes for DECISION-0001 through DECISION-0028

**Date:** 2026-05-08
**Status:** accepted
**Supersedes:** none
**Decided by:** user during arbitration session
**Decision category:** META.STALE-ARTIFACT-RESOLUTION
**Artifact-section-hash:** n/a

### Variance summary

- **Artifact position:** n/a (META decision — no artifact position involved)
- **Scaffold position:** n/a
- **Status type:** open-decision-closure

### Decision

On the 2026-05-08 arbitration session, Stage 1.5 stale-artifact detection flagged all 12 artifact-section-hash entries from DECISION-0001 through DECISION-0028 as mismatched. Investigation confirmed the three artifact files have a single git commit (`6acabca`) and have never been modified since initial project setup. The mismatches are caused by the prior arbiter sessions (Areas 1–5, 2026-05-07) using a different section-extraction algorithm (different boundary conditions) than the current session's implementation.

User chose **bulk Keep as-is**: all prior decisions remain in force. No decision content has been invalidated. The re-calibrated hashes below replace the stored values for future stale detection — any future arbiter run that re-computes using the same boundary algorithm will match these values.

### Re-calibrated hashes (current algorithm: section heading to next same-level or higher heading, HTML-comments stripped, UTF-8 SHA-256)

| Section | Re-calibrated hash | Affects decisions |
|---|---|---|
| Doc 1 §3.2 | `287a21735bc17487fc6702fbc9a6cf416deb4772dc169c920ca0ed47a2bfe2cf` | D1, D27, D28 |
| Doc 1 §3.3 | `0ab17d206081639e0ee3da19b47c3da72a60d197bd5e1c1048cf22872c20be11` | D10 |
| Doc 1 §3.4 | `f02e4e851c9d1a05aabc9dfb8b6026ee5f9e39d613baa484ca98bdfab1f50c26` | D2, D18, D19 |
| Doc 1 §3.6 | `a4164cb5fed19241dbd0588fefc2dc95c1236374b0a49d3f18d79af7fd35cf63` | D7, D26 |
| Doc 1 §3.7 | `7802551c6e89d76ff0d9bfa018ab8d7caf048c5bb4a83253e13cc93d37b2eeee` | D3, D21 |
| Doc 1 §5   | `9417a81351dce653bc1336efa6dba58414a62e95a29e11061cec7931ebb4256c` | D5, D6, D8, D9 |
| Doc 1 §6.2 | `02071bdff59162da5c1928b39ed9e7b976d26831e1a3c54df887630e91762461` | D11 |
| Doc 1 §6.4 | `7a48872ca4ce2af21f4f173cc58beaaccca2ecc8c194c196718e0f6ebfb9ac4a` | D12, D22, D23 |
| Doc 1 §6.5 | `c67d5295a85f923456fb44c6b5fa1bf0fe9fd8a8c1311fd6201a4431fdf05972` | D13, D17 |
| Doc 1 §6.7 | `8e265657489c318ddbb08405d47f75ffca8f3e6882c901546bf09dfc4f80e021` | D14 |
| Doc 1 §6.8 | `5acf48d459939dfb0435e231f26b0b4fbc2612692558e7835b2141edd935951a` | D15 |
| Doc 1 §8.2 | `af1a46e411526e3a57dc3a82c636abd4d424b6e6cf4ca663fcf6ff809f1e69df` | D20 |

### SMARTS rationale

This is a process-maintenance decision, not an architectural one. Bulk keep-as-is is the correct call: no artifact content changed, no decision was invalidated, and creating 12 individual re-evaluation entries would produce pure overhead with no architectural value. Recording the re-calibrated hashes now prevents the same false-positive triggering on the next run.

### Implementation implication

Future arbiter runs use the hashes in this entry as the authoritative current values for the listed sections. No scaffold change. No artifact change.

---

## DECISION-0030

| Field | Value |
|---|---|
| Decision ID | DECISION-0030 |
| Category | REPO.GITEA.ORG + REPO.GITEA.NODES + REPO.GITEA.ADAPTERS + REPO.GITEA.POLICIES |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent (clustered) |
| Option chosen | Defer to Gitea provisioning sprint |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `7802551c6e89d76ff0d9bfa018ab8d7caf048c5bb4a83253e13cc93d37b2eeee` (Doc 1 §3.7) |
| Related decisions | DECISION-0013 (GITSHA-PINNING — no backing store until this is resolved) |

### Decision

Defer provisioning of `FUSION_ORG`, `fusion-nodes`, `fusion-adapters`, and `fusion-policies` in Gitea until the dedicated Gitea infrastructure sprint. Accepted as a known pre-MVP1 gap.

### Rationale

No nodes or adapters have been authored yet; the repos have no immediate consumers. The current scaffold is in the app-level phase, not the infra provisioning phase. This is expected Doc 2 Phase 1 sequencing, not a design disagreement.

### Implementation implication

Tag as BLOCKS_S2. Must be completed before Stage 2 promotion. Bundle with DECISION-0031 (schemas) and DECISION-0032 (branch protection) in the same Gitea sprint. Ticket: provision `FUSION_ORG` org + three repos + access tokens + initial branch protection in `docker-compose.yml` (dev) and OpenTofu (prod).

---

## DECISION-0031

| Field | Value |
|---|---|
| Decision ID | DECISION-0031 |
| Category | REPO.GITEA.SCHEMAS |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent |
| Option chosen | Hybrid/Defer — keep schemas in monorepo for MVP1; migrate to standalone `fusion-schemas` Gitea repo when triggered by first `solution-*` repo needing independent schema reference |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `7802551c6e89d76ff0d9bfa018ab8d7caf048c5bb4a83253e13cc93d37b2eeee` (Doc 1 §3.7) |
| Related decisions | DECISION-0030 (Gitea provisioning sprint) |

### Decision

`schemas/` stays in the monorepo for MVP1. The migration to a standalone `fusion-schemas` Gitea repo is deferred until the first `solution-*` repo in a separate Gitea org needs to reference schemas independently. Add a `# MIGRATE-TO-fusion-schemas` comment to `schemas/` README documenting the trigger condition.

### Rationale

No external consumers of these schemas exist at Stage 1. Maintaining a separate repo adds overhead with no current beneficiary. Version coupling is acceptable while all code lives in the monorepo. The MOSA evolvability hedge is satisfied by documenting the migration trigger explicitly rather than acting prematurely.

### Implementation implication

Add `# MIGRATE-TO-fusion-schemas: trigger = first solution-* repo that needs independent schema pin` to `schemas/README.md` or equivalent. No other scaffold change. Revisit at Stage 2 promotion if solution repos exist.

---

## DECISION-0032

| Field | Value |
|---|---|
| Decision ID | DECISION-0032 |
| Category | REPO.BRANCH-PROTECTION |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent |
| Option chosen | Defer API-level enforcement to Gitea provisioning sprint; basic protection on main acknowledged as existing but not robust |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `7802551c6e89d76ff0d9bfa018ab8d7caf048c5bb4a83253e13cc93d37b2eeee` (Doc 1 §3.7) |
| Related decisions | DECISION-0030 (Gitea provisioning sprint — must bundle) |

### Decision

Defer Gitea API-level branch protection configuration to the Gitea provisioning sprint. Basic protection on main is acknowledged as already present. Full CM-3-demonstrable API enforcement (no force-push, PR-required, CODEOWNERS enforcement) is a MUST-DO item in the same sprint as DECISION-0030 — not indefinitely deferred.

### Rationale

Gitea doesn't exist as a provisioned service yet; API configuration cannot precede the service. Basic main branch protection provides a floor. The gap is bounded to the Stage 1 team-only period where bypass risk is low. This MUST be resolved before any external contributors or Stage 2 promotion.

### Implementation implication

Tag as BLOCKS_S2. Bundle with DECISION-0030 Gitea provisioning sprint. Add Gitea branch protection API calls (no-force-push + require-PR + CODEOWNERS) to bootstrap scripts. Test: assert `git push --force` returns 403 after provisioning.

---

## DECISION-0044

| Field | Value |
|---|---|
| Decision ID | DECISION-0044 |
| Category | ARTIFACT-SILENT.UI-TO-AUDIT-DIRECT-PATH |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | artifact-silent (trust-zone violation) |
| Option chosen | Close the violation — remove direct audit emit from `frontend/src/lib/audit/index.ts`; rely on Z-API server-side audit for all user actions |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `0bbd2aafbec3a25fcc2571ee39662b94a7c54a7dccdd22fffef244475a5b268b` (scaffold — `frontend/src/lib/audit/` combined; artifact-silent, no artifact section to hash) |
| Related decisions | DECISION-0025 (API.AUDIT.EMIT), DECISION-0041 (COMPLIANCE.ZERO-TRUST) |

### Decision

Remove the direct `fetch(VITE_AUDIT_SINK_URL, ...)` call from `frontend/src/lib/audit/index.ts`. The frontend emits no audit events directly. All user-initiated actions (deploy, configure, navigate with side effects) are audited at the Z-API layer when the corresponding API request is processed. The `emit()` function becomes a no-op or is removed entirely.

### Rationale

`frontend/src/lib/audit/index.ts:11` posts directly to the audit sink from the browser — Z-UI to Z-AUDIT, bypassing Z-API. Any browser with `VITE_AUDIT_SINK_URL` can inject arbitrary audit events. This violates AU-9 (audit trail integrity) and AU-10 (non-repudiation) and is an ATO blocker. Frontend user actions are already captured server-side when Z-API processes the request; a separate client-side path adds integrity risk with no coverage benefit.

### Implementation implication

1. Replace `frontend/src/lib/audit/index.ts` emit logic with a no-op (preserve the type exports for any callers that need `AuditEvent` type)
2. Remove `VITE_AUDIT_SINK_URL` from frontend env config
3. Update `frontend/src/__tests__/auditEmit.test.ts` — tests should assert the no-op behavior, not the old HTTP call
4. `security-reviewer` subagent must verify the fix and confirm no other frontend→audit-sink paths exist
5. Update `docs/architecture/trust-zones.md` to close the "open question for Stage 2 decision" note — this is now resolved as "Z-UI does not emit to Z-AUDIT directly"

---

## DECISION-0045

| Field | Value |
|---|---|
| Decision ID | DECISION-0045 |
| Category | ARTIFACT-SILENT.AUTH-BYPASS-FLAG |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | artifact-silent |
| Option chosen | Keep `DEV_AUTH_BYPASS` flag; add prominent runtime warning when flag is active; open CONFIRM-11 for Stage 2 keep/remove decision |
| Recommendation alignment | Modified from arbiter recommendation — arbiter suggested document policy; user adds build-time warning and formal open decision |
| Artifact-section-hash | `0707e2b49c996c07122ff2cfa73ef0c6b4fad5b724a1dabfe97c376dbd977205` (scaffold — `backend/src/middleware/auth.ts`; artifact-silent) |
| Related decisions | DECISION-0041 (COMPLIANCE.ZERO-TRUST — Keycloak wiring adds real alternative to bypass) |

### Decision

Retain `DEV_AUTH_BYPASS` flag at Stage 1. Add a prominent startup warning (both `console.warn` and Pino logger at `warn` level) whenever the flag is active — visible at server startup and on every bypassed request. Add a CI assertion that the flag is absent from any non-development environment config. Open CONFIRM-11 in `docs/open-questions.md` to formally decide keep/remove when moving to Stage 2 — there may still be a legitimate dev/debug need for some form of auth bypass even after Keycloak is running locally.

### Rationale

The flag is a real tool during development and debugging, especially while Keycloak (DECISION-0041) is being wired up. Removing it now would create friction with no compensating benefit at Stage 1 where the team is small and controlled. The warning makes the flag's presence impossible to overlook accidentally. CONFIRM-11 ensures the decision gets proper analysis at the Stage 2 inflection when the threat model changes (more contributors, external users possible).

### Implementation implication

1. Add to `backend/src/middleware/auth.ts` startup path: `if (process.env.DEV_AUTH_BYPASS) { logger.warn('DEV_AUTH_BYPASS is active — all authentication is bypassed. NEVER deploy with this flag set.') }`
2. Log the same warning at `warn` level on every request that bypasses auth
3. Add CI assertion in `ci-linux.yml` that `DEV_AUTH_BYPASS` is absent from any deployed config
4. CONFIRM-11 added to `docs/open-questions.md` — blocks Stage 2 promotion until resolved

---

## DECISION-0046

| Field | Value |
|---|---|
| Decision ID | DECISION-0046 |
| Category | ARTIFACT-SILENT.DEPLOYMENT-CLASSIFICATION-FIELD |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | artifact-silent |
| Option chosen | Open as CONFIRM-12 — defer schema shape decision; the `classification` column was provisional scaffolding, not a decided design; proper analysis required before committing |
| Recommendation alignment | DIVERGES from arbiter recommendation (arbiter suggested document inline) — user correctly identifies this as requiring full analysis, not a snap judgment |
| Artifact-section-hash | `a9d09a9281a20ffb003d9b102ce2b90397666871a27f73844bbc1f418d1a5968` (scaffold — `backend/src/db/schema.ts`; artifact-silent) |
| Related decisions | DECISION-0018 (SCHEMA.SOLUTION-MANIFEST), CONFIRM-02 (FIPS 199 categorization), CONFIRM-03 (CUI categories) |

### Decision

The `classification` column in the `deployments` table was provisional scaffolding — placeholder work to unblock planning, not a decided schema choice. Treat it as undecided. Open CONFIRM-12 in `docs/open-questions.md` to formally analyze: what classification metadata (if any) belongs on deployment records, what shape it should take, and how it interacts with CONFIRM-02 (FIPS 199 categorization) and CONFIRM-03 (CUI categories in scope). No inline comment, no backfill — the field deserves the same rigor as any other schema decision.

### Rationale (user-stated)

The scaffolding was never intended to be decisional — it was meant to get something in place to facilitate planning. Snap-judging DB shape without proper analysis is exactly the mistake that creates schema debt. This parallels the MkDocs judgment: don't commit to a structural decision without the analysis it deserves.

### Implementation implication

1. Add CONFIRM-12 to `docs/open-questions.md` with full context (what the field currently is, what decisions it depends on, what the analysis needs to cover)
2. The `classification` column in `backend/src/db/schema.ts` is acknowledged as provisional — do not build features on top of it until CONFIRM-12 is resolved
3. CONFIRM-12 blocks Stage 2 promotion — classification metadata on deployments is a CUI-adjacent concern and must be decided before CUI enters scope

---

## DECISION-0033

| Field | Value |
|---|---|
| Decision ID | DECISION-0033 |
| Category | DEPLOY.HELM-CHART + DEPLOY.K3S-HOSTING |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent (clustered) |
| Option chosen | Defer to dedicated Helm/infra sprint |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `9417a81351dce653bc1336efa6dba58414a62e95a29e11061cec7931ebb4256c` (Doc 1 §5) |
| Related decisions | DECISION-0030 (Gitea sprint — may co-schedule) |

### Decision

Defer Helm chart skeleton and Terraform K3s module to the deployment infrastructure sprint. Accepted as a known pre-MVP1 gap consistent with Doc 2 Phase 1 sequencing.

### Rationale

App scaffold is not yet complete. Helm chart authoring is sequenced after core application features are stable per the phased build plan. No end-to-end deployment is required at Stage 1.

### Implementation implication

Tag as BLOCKS_S2. Sprint work items: (1) `helm/fusion/Chart.yaml` skeleton, (2) OpenTofu K3s EC2 module in `terraform/`, (3) `helm lint` + `helm template` smoke tests in CI. Must be complete before Stage 2 promotion demo.

---

## DECISION-0034

| Field | Value |
|---|---|
| Decision ID | DECISION-0034 |
| Category | DEPLOY.SUBPROCESS-SANDBOX |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent |
| Option chosen | Adopt artifact position — write ADR capturing staged sandbox model before first worker implementation; no scaffold change now |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `0ab17d206081639e0ee3da19b47c3da72a60d197bd5e1c1048cf22872c20be11` (Doc 1 §3.3) |
| Related decisions | DECISION-0010 (PATTERN.WORKER-ABSTRACTION) |

### Decision

Author ADR-0005 (or next available number) capturing the staged subprocess sandbox model: restricted env (MVP1) → K8s Job (V1). ADR must explicitly state the `shell: true` prohibition (reinforcing CLAUDE.md §3 SI-10 rule) and the V1 graduation trigger. No code change required now.

### Rationale

The sandbox model shapes every future worker implementation. Writing the ADR before first worker implementation anchors the security posture as an auditable decision rather than a commit-message assumption. CLAUDE.md §3 hard rule covers the worst case; the ADR documents the intended progression.

### Implementation implication

Write `docs/decisions/0005-subprocess-sandbox-model.md` (ADR format) before the first worker implementation ticket begins. ADR must cover: (1) MVP1 restricted-env model with no `shell: true`, (2) V1 K8s Job graduation trigger, (3) SI-10 control mapping. No scaffold change until worker implementation sprint.

---

## DECISION-0035

| Field | Value |
|---|---|
| Decision ID | DECISION-0035 |
| Category | CI.HUSKY-PRECOMMIT + CI.LINT-STAGED |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent (clustered) |
| Option chosen | Adopt artifact position — remove `.pre-commit-config.yaml`; install Husky + lint-staged as devDependencies; wire `prepare` script in `package.json` |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `24d18294096a40fe84aa091853d24c8f706cac9cab7da2d94ba8df23c94043cf` (Doc 3 §MVP1.CI) |
| Related decisions | DECISION-0036, DECISION-0037, DECISION-0038 |

### Decision

Replace `.pre-commit-config.yaml` (Python pre-commit framework) with Husky + lint-staged. Add `husky` and `lint-staged` as devDependencies in `backend/package.json` (and `frontend/package.json` as applicable). Wire the `prepare` script so `npm install` configures hooks automatically.

### Rationale

FUSION is a pure TypeScript/Node.js project. Husky + lint-staged require zero extra runtime dependencies beyond the existing npm ecosystem. The Python pre-commit framework adds an implicit Python runtime requirement for contributors. `npm install` as the single dev-setup command is simpler to document and maintain.

### Implementation implication

1. Remove `.pre-commit-config.yaml`
2. `npm install --save-dev husky lint-staged` in `backend/` (and `frontend/` if applicable)
3. Add `"prepare": "husky install"` to `package.json` scripts
4. Add `.husky/pre-commit` hook running `npx lint-staged`
5. Add `lint-staged` config covering `*.ts`, `*.tsx` with `eslint --fix` and `tsc --noEmit`
6. Update `Makefile` `install-hooks` target to reflect Husky

---

## DECISION-0036

| Field | Value |
|---|---|
| Decision ID | DECISION-0036 |
| Category | CI.DRIZZLE-MIGRATIONS |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent |
| Option chosen | Adopt artifact position — run `drizzle-kit generate` now; commit the initial migration; add CI gate |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `24d18294096a40fe84aa091853d24c8f706cac9cab7da2d94ba8df23c94043cf` (Doc 3 §MVP1.CI) |
| Related decisions | DECISION-0018 (SCHEMA.SOLUTION-MANIFEST), DECISION-0019 (SCHEMA.NODE-DEFINITION) |

### Decision

Generate the initial Drizzle migration from the current `backend/src/db/schema.ts`. Commit the resulting `backend/drizzle/` directory. Add a CI gate (`drizzle-kit check`) that blocks PRs which modify the schema without a corresponding migration. This triggers the `migration-reviewer` subagent review per CLAUDE.md §5.

### Rationale

Migration history is the source of truth for DB state evolution. `drizzle-kit push` (destructive) is not acceptable for a production-path deployment. Generating the first migration now is low-risk — the schema is stable enough for a baseline — and establishes the discipline for all future schema changes. The migration-reviewer subagent provides CM-3 review coverage.

### Implementation implication

1. Run `npx drizzle-kit generate` against `backend/src/db/schema.ts`
2. Commit resulting `backend/drizzle/migrations/` directory (triggers `migration-reviewer` subagent)
3. Add `npx drizzle-kit check` step to `ci-linux.yml` validate job
4. Update `Makefile` with `db:check` target

---

## DECISION-0037

| Field | Value |
|---|---|
| Decision ID | DECISION-0037 |
| Category | CI.OCSF-AUDIT-VALIDATION |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent |
| Option chosen | Adopt artifact position — add `make validate-audit-events` target and wire into `ci-linux.yml` |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `ac588a24616c01ea00fd9ac3892a8b55c9cddfd0f892031f4819428235435156` (Doc 1 §3.8) |
| Related decisions | DECISION-0024 (SCHEMA.AUDIT-EVENT), DECISION-0016 (STATE.AUDIT-TRANSPORT) |

### Decision

Add a CI gate that validates emitted audit events against `schemas/audit-event.schema.json`. Wire as a new step in the `validate` job of `.gitea/workflows/ci-linux.yml`. Add a `validate-audit-events` Makefile target. The validator runs against audit event fixtures in test output or a dedicated fixtures directory.

### Rationale

`schemas/audit-event.schema.json` already exists (DECISION-0024). The CI gate is the only thing missing. AU-9 (protection of audit information) requires demonstrable schema discipline — a schema with no enforcement gate is documentation, not control. Low implementation effort; high compliance return.

### Implementation implication

1. Add `make validate-audit-events` target using `ajv-cli` or equivalent JSON Schema validator against `schemas/audit-event.schema.json`
2. Add audit event fixtures to `backend/src/__tests__/fixtures/audit-events/` for validation
3. Wire into `ci-linux.yml` validate job step
4. `audit-emitter` subagent (CLAUDE.md §5) must verify compliance when first real audit events are emitted

---

## DECISION-0038

| Field | Value |
|---|---|
| Decision ID | DECISION-0038 |
| Category | CI.SEMGREP-AUDIT-EMIT |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent |
| Option chosen | Hybrid — targeted Semgrep rule covering highest-risk entry points (`routes/deployments.ts`, `routes/auth.ts`, `lib/secrets.ts`); refine to full coverage at Stage 2 |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `ac588a24616c01ea00fd9ac3892a8b55c9cddfd0f892031f4819428235435156` (Doc 1 §3.8) |
| Related decisions | DECISION-0037 (OCSF audit validation), DECISION-0025 (API.AUDIT.EMIT) |

### Decision

Write `.semgrep/audit-emit.yml` as a targeted rule covering the three highest-risk entry points: `routes/deployments.ts`, `routes/auth.ts`, and `lib/secrets.ts`. The rule asserts that handler functions in these files call `audit.emit(...)` before returning. Wire into the existing `sast` job in `ci-linux.yml`. Expand to full route coverage at Stage 2.

### Rationale

A broad audit-emit rule at Stage 1 risks false positives on helper functions, middleware, and utility code — eroding CI trust when contributors see unexplained failures. A targeted rule covering the three highest-risk paths gives real AU-2/AU-3 coverage with minimal false-positive surface. Stage 2 expansion is the natural inflection when route count grows and the rule patterns are validated.

### Implementation implication

1. Write `.semgrep/audit-emit.yml` targeting `routes/deployments.ts`, `routes/auth.ts`, `lib/secrets.ts`
2. Rule pattern: flag handler functions that do not call `audit.emit(` before `reply.send(` or `return`
3. Add Semgrep rule unit tests (`.semgrep/tests/audit-emit/`) per Semgrep test framework
4. Wire into `sast` job in `ci-linux.yml` — already runs Semgrep, just add the rule path
5. DECISION note for Stage 2: expand rule to cover all `routes/*.ts` files

---

## DECISION-0039

| Field | Value |
|---|---|
| Decision ID | DECISION-0039 |
| Category | COMPLIANCE.FIPS-CAPABLE |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent |
| Option chosen | Hybrid — warn in `NODE_ENV=development`; throw in all other environments if `require('crypto').getFips() !== 1` |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `9417a81351dce653bc1336efa6dba58414a62e95a29e11061cec7931ebb4256c` (Doc 1 §5) |
| Related decisions | DECISION-0001 (Keycloak OIDC — same FIPS posture) |

### Decision

Add a FIPS startup assertion to `backend/src/main.ts`. In `NODE_ENV=development`, log a warning if FIPS is not active. In all other environments (`NODE_ENV=production`, `staging`, etc.), throw and refuse to start if `require('crypto').getFips() !== 1`.

### Rationale

CI gate alone (current state) catches FIPS misconfig only on the CI host — not on deployment hosts. SC-13 requires runtime enforcement. Dev machines commonly lack FIPS-enabled OpenSSL; hard-failing in dev blocks contributors unnecessarily. The env-gated approach protects prod/staging while keeping dev workable.

### Implementation implication

Add to `backend/src/main.ts` before server start:
```typescript
const fipsActive = require('crypto').getFips() === 1;
if (!fipsActive) {
  if (process.env.NODE_ENV === 'development') {
    logger.warn('FIPS mode not active — acceptable in development only');
  } else {
    throw new Error('FIPS mode required in non-development environments (SC-13)');
  }
}
```
Add test asserting behavior under both env values. `security-reviewer` subagent must verify implementation per CLAUDE.md §5.

---

## DECISION-0040

| Field | Value |
|---|---|
| Decision ID | DECISION-0040 |
| Category | COMPLIANCE.STIG-IMAGES |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent |
| Option chosen | Defer — no nodes exist; record as required pre-work before first node authoring sprint; tag BLOCKS_S2 |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `9417a81351dce653bc1336efa6dba58414a62e95a29e11061cec7931ebb4256c` (Doc 1 §5) |
| Related decisions | DECISION-0030 (REPO.GITEA.NODES — also deferred until node sprint) |

### Decision

Defer STIG base image selection until the first node authoring sprint. No Dockerfiles exist to apply it to. The selection (IronBank UBI9, Registry1, or custom hardened image) must be an ADR-level decision made before the first `fusion-nodes/` Dockerfile is written.

### Rationale

Stage 1 has no nodes. The base image decision constrains every future node Dockerfile — it must be made deliberately before authoring begins, not ad-hoc mid-sprint. Deferring now with an explicit pre-condition prevents both premature commitment and accidental omission.

### Implementation implication

Tag as BLOCKS_S2. Pre-work before node authoring sprint: (1) evaluate IronBank UBI9 vs Registry1 vs custom hardened image against DISA STIG compliance, (2) write ADR capturing selection with rationale, (3) document the bootstrap process for pulling STIG images in a Cove.GDIT environment.

---

## DECISION-0042

| Field | Value |
|---|---|
| Decision ID | DECISION-0042 |
| Category | DOCS.NODE-AUTHORING-GUIDE + DOCS.ADAPTER-AUTHORING-GUIDE |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | scaffold-silent (clustered) |
| Option chosen | Hybrid — create stub guides now with required sections identified; flesh out during first node/adapter authoring sprint |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `fbab368ba84fd834dcdb4a0101fcc74a16717259ab983c2f1f5dc0b96793298f` (Doc 3 §MVP1.DOCS) |
| Related decisions | DECISION-0030 (REPO.GITEA.NODES/ADAPTERS — deferred to Gitea sprint) |

### Decision

Create `docs/contribution/node-authoring-guide.md` and `docs/contribution/adapter-authoring-guide.md` as stubs. Each stub identifies the required sections (schema requirements, CI validation obligations, deployment expectations, test obligations, ADR references) with `TODO: flesh out during first node/adapter sprint` markers. Full content authored when `fusion-nodes/` and `fusion-adapters/` directories are created.

### Rationale

Authoring guides make the contribution process discoverable even before the first node/adapter exists. A stub with the required sections prevents ad-hoc first-node decisions from becoming implicit standards. Deferring full content until authoring begins aligns effort with the moment it's needed.

### Implementation implication

Create `docs/contribution/` directory. Write both stubs covering: (1) schema conformance requirements (linking to `schemas/node.schema.json` / `adapter.schema.json`), (2) CI validation steps (`make validate-definitions`), (3) test obligations per CLAUDE.md §9, (4) deployment expectations (STIG image TBD per DECISION-0040), (5) ADR cross-references. No source code change.

---

## DECISION-0043

| Field | Value |
|---|---|
| Decision ID | DECISION-0043 |
| Category | DOCS.RUNBOOKS |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent |
| Option chosen | Accept gap explicitly — remove CODEOWNERS references to non-existent playbook paths; add WIP marker to `docs/runbook.md`; defer runbook content until infra exists |
| Recommendation alignment | Aligns with arbiter recommendation |
| Artifact-section-hash | `fbab368ba84fd834dcdb4a0101fcc74a16717259ab983c2f1f5dc0b96793298f` (Doc 3 §MVP1.DOCS) |
| Related decisions | DECISION-0033 (DEPLOY.HELM-CHART — deferred infra sprint) |

### Decision

Remove phantom `CODEOWNERS` entries for Ansible playbook paths that don't exist (`deploy/playbooks/pre-check.yml`, `main.yml`, `verify.yml`). Add an explicit `# WIP: pending infra sprint — no playbooks authored yet` comment to `docs/runbook.md`. Full runbook authoring deferred until Helm + K3s + Ansible infrastructure sprint (bundled with DECISION-0033).

### Rationale

Phantom `CODEOWNERS` entries create false coverage signals — a code reviewer or security assessor sees CODEOWNERS coverage for paths that don't exist and cannot be reviewed. Explicitly removing them is more honest than leaving them as aspirational placeholders. Runbook content requires operational infrastructure to describe; authoring now would be speculation.

### Implementation implication

1. Edit `CODEOWNERS` to remove references to `deploy/playbooks/*.yml` paths
2. Add WIP comment to `docs/runbook.md`
3. Tag runbook authoring as BLOCKS_S2 — must be complete and accurate before Stage 2 promotion (first external user needs operational documentation)

---

## DECISION-0041

| Field | Value |
|---|---|
| Decision ID | DECISION-0041 |
| Category | COMPLIANCE.ZERO-TRUST |
| Date | 2026-05-08 |
| Decided by | Brennon Huff |
| Variance status | divergent |
| Option chosen | Adopt artifact position — add Keycloak and OPA to `docker-compose.yml` now; prioritized as a key ZT win; identity management and data protection/governance are strategic priorities |
| Recommendation alignment | DIVERGES from arbiter recommendation (arbiter recommended defer to infra sprint) |
| Artifact-section-hash | `a4164cb5fed19241dbd0588fefc2dc95c1236374b0a49d3f18d79af7fd35cf63` (Doc 1 §3.6) |
| Related decisions | DECISION-0001 (Keycloak OIDC), DECISION-0005 (OPA authorization), DECISION-0025 (API.AUDIT.EMIT) |

### Decision

Add Keycloak and OPA services to `docker-compose.yml`. Configure a FUSION development OIDC realm in Keycloak with bootstrap seed data. Remove `DEV_AUTH_BYPASS` as a default-on path — require real OIDC tokens in dev. This is a strategic priority: identity is the first ZT control plane; getting it right early anchors the entire ZT story and ensures audit events carry real identity metadata from the start.

### Rationale (user-stated)

Getting auth right early is an important win in the ZT story. Identity management is the primary hot area. Data protection and governance are the adjacent priorities that depend on correct identity wiring. If Keycloak is deferred, the auth middleware is never locally exercised, audit ZT fields (`credential_id`, `trust_zone`, `policy_decision`) never carry real values, and the ZT posture is hollow until late in the development cycle. The arbiter recommendation to defer was based on implementation complexity — the user judges that strategic value outweighs that cost.

### Implementation implication

1. Add `keycloak` service to `docker-compose.yml` (Keycloak 24+ image; development realm config via env or JSON import)
2. Add `opa` service to `docker-compose.yml` (OPA 0.x; initial `fusion-policies/` bundle path wired)
3. Create `docker/keycloak/` bootstrap: realm export JSON with FUSION client, roles (Solutions Engineer, Admin), and one dev user
4. Update `backend/src/middleware/auth.ts` to remove or gate `DEV_AUTH_BYPASS` per DECISION-ARTIFACT-SILENT.AUTH-BYPASS-FLAG (Area 11)
5. Update `make up` target documentation in `Makefile`
6. `security-reviewer` subagent must verify Keycloak + OPA wiring per CLAUDE.md §5
7. Note: data protection and governance controls (AC-16, SC-28) are next-priority work once identity is wired

---
