# FUSION Arbiter — Downstream Artifact Readiness

> **ARBITER WORKING FILE** — Produced and rebuilt by the `/fusion-arbiter` skill on each
> scan. Not authoritative project documentation. For architecture decisions, cite
> `docs/fusion-arbiter-decisions.md` instead. Do not use this file as evidence in
> downstream design work.

**Generated:** 2026-05-08
**Decision basis:** DECISION-0001 through DECISION-0046 (two arbitration sessions, 2026-05-07 and 2026-05-08).
**Working file** — overwritten on every Stage 5 evaluation.

Path note: project uses `docs/decisions/` for ADRs; the catalog's `docs/adr/` criterion is treated as equivalent.

---

## Downstream Artifact Readiness

### ADR Set for MVP1 Decisions
- **Readiness:** ready
- **Why:** ADR convention is concur (existing ADRs 0001–0004 follow consistent template); 46 decisions exist in the arbiter log; ADR-0003 at `docs/decisions/0003-adopt-ocsf-audit-schema.md` confirms the format.
- **Recommendation:** produce now — highest-value immediately available artifact; converts 46 arbiter decisions into auditable, citable ADR documents

---

### Solution Manifest JSON Schema
- **Readiness:** ready
- **Why:** All five required decisions locked — SCHEMA.SOLUTION-MANIFEST (D-0018), SCHEMA.NODE-DEFINITION (D-0019), SCHEMA.ADAPTER-DEFINITION (D-0020), STATE.GITSHA-PINNING (D-0013), PATTERN.SUB-SOLUTION-COMPOSITION (D-0012).
- **Recommendation:** produce now — no blocking gaps; output is a standalone JSON Schema file usable immediately in `make validate-definitions`

---

### Drizzle Schema (Concrete Field-Level)
- **Readiness:** ready
- **Why:** All nine required decisions locked — ORM (D-0002), all six SCHEMA.* decisions (D-0018–D-0024), PATTERN.MULTI-TENANT-RETROFIT (D-0011), STATE.GITSHA-PINNING (D-0013). Drizzle implemented in scaffold.
- **What's missing (caveat):** CONFIRM-12 (deployment `classification` field shape is unresolved) — the field should be treated as provisional or excluded from the generated schema until CONFIRM-12 is resolved.
- **Recommendation:** produce now with explicit CONFIRM-12 placeholder on the `classification` column; remainder of schema is fully specified

---

### Helm Chart Skeleton
- **Readiness:** ready
- **Why:** All seven required decisions locked — DEPLOY.HELM-CHART (D-0033 deferred implementation but decision is locked), DEPLOY.SELF-CONTAINED (D-0006), STACK.HOSTING (concur), STACK.DB.ENGINE (concur), STACK.LIBRARY.GIT (D-0003), STACK.AUTH.IDENTITY (D-0001), STACK.AUTH.AUTHORIZATION (D-0005). Readiness criteria require decisions to be *locked*, not yet implemented.
- **Recommendation:** produce now — skeleton gives the Gitea/infra sprint a concrete starting point; `helm lint` feedback loop catches structural errors early

---

### Audit Event Reference
- **Readiness:** ready
- **Why:** SCHEMA.AUDIT-EVENT locked per ADR-0003 (D-0024); API.AUDIT.EMIT locked and implemented (`backend/src/lib/audit/` exists); ADR-0003 at `docs/decisions/0003-adopt-ocsf-audit-schema.md`.
- **Note:** Downstream artifact catalog references `docs/adr/` — project uses `docs/decisions/`. Criterion treated as met.
- **Recommendation:** produce now — audit event reference is valuable immediately for the `audit-emitter` subagent and for CI.OCSF-AUDIT-VALIDATION gate implementation (D-0037)

---

### Component Interface Contracts
- **Readiness:** partial
- **Why:** Most decisions locked. Missing: `STACK.BACKEND.VALIDATION = locked-and-implemented` (Zod schema registration on routes is D-0021, locked but not yet implemented — F-019 still in CHANGELOG); no single route yet demonstrates the full auth + Zod registration + OPA + audit emit pattern.
- **What's missing:**
  - Zod schema registered on at least one route (`schema: { body, response }`) — planned in next sprint per D-0021
  - One reference route showing complete auth → validation → OPA → audit flow
- **Recommendation:** produce after D-0021 (Zod route registration) is implemented and one reference route exists; estimated unblock: next backend sprint

---

### OPA Policy Bundle Skeleton
- **Readiness:** partial
- **Why:** STACK.AUTH.AUTHORIZATION locked as OPA (D-0005); API.AUTHZ.OPA-CALL locked (D-0026). Spike 4 (OPA Policy Bundle Structure) is not complete — no Spike 4 ADR exists.
- **What's missing:**
  - Spike 4 complete, OR user explicitly accepts producing a pre-spike skeleton
- **Recommendation:** produce pre-spike skeleton if user accepts — decisions are sufficient to generate a structural scaffold (`fusion-policies/` package layout, placeholder Rego, test harness); Spike 4 refines the skeleton, doesn't replace it

---

### Node Authoring Guide (Detailed)
- **Readiness:** partial
- **Why:** SCHEMA.NODE-DEFINITION locked (D-0019); PATTERN.REVERSAL-TIERS locked (D-0014); CI.PIPELINE locked-and-implemented. Missing: at least one MVP1 node implemented as a reference example.
- **What's missing:**
  - At least one `fusion-nodes/` node implemented and published as a reference
- **Note:** D-0042 created stub guides (`docs/contribution/node-authoring-guide.md`) — the detailed artifact is distinct and requires a worked example.
- **Recommendation:** produce after first reference node is authored; stub guides (D-0042) fill the gap until then

---

### Adapter Authoring Guide (Detailed)
- **Readiness:** partial
- **Why:** Same as node guide — SCHEMA.ADAPTER-DEFINITION locked (D-0020); PATTERN.REVERSAL-TIERS locked (D-0014); CI.PIPELINE implemented. Missing: at least one MVP1 adapter as reference.
- **What's missing:**
  - At least one `fusion-adapters/` adapter implemented as reference
- **Recommendation:** produce after first reference adapter is authored; stub guides (D-0042) fill the gap

---

### Spike Plan Documents
- **Readiness:** partial
- **Why:** Spike scopes are clearly described in Doc 3 §V1.SPIKE. Blocked by spike ownership assignments (all listed as TBD-DARREN-REVIEW or TBD-AVAILABLE) — but this is an out-of-arbiter-scope operational decision per `references/known-open-decisions.md`.
- **What's missing:**
  - Spike owner assignments (Spikes 1–6 are TBD)
- **Note:** Spike plan documents can be drafted without owners — the plans are useful as context for whoever is assigned.
- **Recommendation:** produce now without owner fields populated — the plan content (context, questions, success criteria, approach, time-box) is fully determinable from current decisions; owner fields left blank for human assignment

---

### Cross-Context Variance Report
- **Readiness:** ready
- **Why:** All three artifacts located; scaffold accessible; Stage 1–4 completed across two sessions. This report is the variance report + decision log together — already produced.
- **Recommendation:** already produced — `docs/fusion-arbiter-variance-report.md` and `docs/fusion-arbiter-decisions.md` constitute this artifact

---

### V1 Scope Refinement Document
- **Readiness:** blocked
- **Why:** MVP1 is not complete. All MVP1 task groups (AUTH, DB, API, EXEC, AUDIT, CANVAS, UI, DEMO, DEPLOY, DOCS, OPS) have open tasks.
- **What's blocking:** MVP1 not complete.
- **Recommendation:** do not produce yet — defer until MVP1 is substantively complete

---

### Funding Gate Demo Script
- **Readiness:** blocked
- **Why:** MVP1.DEMO.011 (full end-to-end demo deployment test) is not complete.
- **What's blocking:** MVP1.DEMO.011 not complete.
- **Recommendation:** do not produce yet

---

## Summary Menu

| Artifact | Readiness | Recommendation |
|---|---|---|
| ADR Set for MVP1 Decisions | **ready** | produce now |
| Solution Manifest JSON Schema | **ready** | produce now |
| Drizzle Schema | **ready** | produce now (CONFIRM-12 caveat) |
| Helm Chart Skeleton | **ready** | produce now |
| Audit Event Reference | **ready** | produce now |
| OPA Policy Bundle Skeleton | partial | pre-spike skeleton if user accepts |
| Spike Plan Documents | partial | produce now (owner fields blank) |
| Component Interface Contracts | partial | after Zod registration implemented |
| Node Authoring Guide (Detailed) | partial | after first reference node |
| Adapter Authoring Guide (Detailed) | partial | after first reference adapter |
| Cross-Context Variance Report | ready | already produced |
| V1 Scope Refinement | blocked | after MVP1 complete |
| Funding Gate Demo Script | blocked | after MVP1.DEMO.011 complete |
