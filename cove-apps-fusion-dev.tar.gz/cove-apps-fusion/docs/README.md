# FUSION Documentation Index

> Navigation guide for humans and agents. Every file in `docs/` has a category, purpose,
> and authority level. When in doubt about where something lives — start here.
>
> **Authority order:** `CLAUDE.md` wins all conflicts. Below it: arbiter decision log,
> accepted ADRs, then these docs. See `CLAUDE.md §0` for the full hierarchy.

---

## Quick Navigation

| You are… | Start here |
|---|---|
| New engineer | `../README.md` → `domain.md` → `stack.md` → `../CLAUDE.md` |
| AI agent | `../CLAUDE.md §2` (the must-read table) → relevant category below |
| About to write code | `coding-standards.md` + `dependency-policy.md` |
| About to merge a PR | `../.gitea/pull_request_template.md` + `cicd.md` |
| Debugging a Z-AUDIT issue | `audit-spec.md` → `audit-event-reference.md` |
| Researching a past decision | `decisions/README.md` → `fusion-arbiter-decisions.md` |
| Adding a node or adapter | `domain.md` → `contribution/` (authoring guides) |

---

## Category 1 — Authority
*Read-only. Modification requires an explicit arbiter decision or explicit user instruction
citing the specific change. These files win all cross-file conflicts.*

| File | Purpose |
|---|---|
| `../CLAUDE.md` | Project contract; always-loaded hard rules; TDD + commit policy |
| `decomposition/01-architecture-breakdown.md` | Arbiter input artifact — architectural intent (READ-ONLY) |
| `decomposition/02-phased-build-plan.md` | Arbiter input artifact — phased build scope (READ-ONLY) |
| `decomposition/03-task-backlog.md` | Arbiter input artifact — task backlog (READ-ONLY) |
| `fusion-arbiter-decisions.md` | Append-only arbitration log (DECISION-0001–0046+) |

---

## Category 2 — Domain Reference
*`CLAUDE.md §2` points here. Agents MUST read these before acting in the named domain.*

| File | Domain | `CLAUDE.md §2` trigger |
|---|---|---|
| `domain.md` | Node / adapter / solution vocabulary | New node, adapter, or solution |
| `glossary.md` | Acronyms, federal/GDIT terminology | Any ambiguous term |
| `stack.md` | Pinned versions, FIPS rules, MOSA constraints | Stack or dependency changes |
| `coding-standards.md` | Lint, TypeScript, Zod, error handling | Any code change |
| `dependency-policy.md` | License allow-list, SBOM, provenance | Dependency additions |
| `open-questions.md` | CONFIRM-NN open questions blocking stage promotions | Risks or tradeoffs |
| `agent-policy.md` | Prohibited actions, verification signals | Any code change |

---

## Category 3 — Architecture
*Static structural artifacts. Describe the system's zones, interfaces, and data model.*

| File | Purpose | Key cross-references |
|---|---|---|
| `architecture/trust-zones.md` | Zone definitions, allowed callers, NetworkPolicy contract | `../CLAUDE.md §8`; `decisions/0010-*.md` |
| `diagrams/ov-1-operational-concept.md` | Leadership deck: actors, platform, mission outcomes | `project-context.md` |
| `diagrams/sv-1-system-interfaces.md` | Engineering deck: trust zones, interfaces, protocols | `architecture/trust-zones.md` |
| `data-model.md` | DB schema, table descriptions, classification tags | `decisions/0006-*.md`; `decisions/0008-*.md` |

---

## Category 4 — Decisions (ADR Log)
*Append-only. Never edit an existing ADR — supersede it with a new one.*

| File | Decision | Status |
|---|---|---|
| `decisions/README.md` | ADR index | living index |
| `decisions/0001-adopt-claude-md-contract.md` | Claude.md project contract | accepted |
| `decisions/0002-adopt-xyflow-react-v12.md` | XYFlow React v12 for canvas | accepted |
| `decisions/0003-adopt-ocsf-audit-schema.md` | OCSF audit schema | accepted |
| `decisions/0004-adopt-nodejs-typescript-backend.md` | Node.js 22 + TypeScript backend | accepted |
| `decisions/0005-worker-execution-architecture.md` | Worker sandbox + ExecutionWorker interface | accepted |
| `decisions/0006-multi-tenant-retrofit.md` | `withTenant()` helper; tenant_id on all solution tables | accepted |
| `decisions/0007-sub-solution-composition-and-gitsha-pinning.md` | Sub-solution copy-on-import; git SHA pinning | accepted |
| `decisions/0008-schema-contracts.md` | Deployment receipt, environments, audit transport schemas | accepted |
| `decisions/0009-api-enforcement-pattern.md` | Fastify schema registration; `authz.can()` preHandler | accepted |
| `decisions/0010-security-posture.md` | FIPS assertion; ZT bootstrap; Z-UI audit trust-zone closure | accepted |

---

## Category 5 — Security & Compliance
*Defense-grade posture. Agents touching auth, crypto, secrets, or audit MUST read these.*

| File | Purpose | Stage gate |
|---|---|---|
| `security-controls.md` | NIST 800-53 control family mappings | All stages |
| `secrets-and-keys.md` | Secret sourcing, rotation, redaction rules (TypeScript only — Python stack retired) | All stages |
| `data-classification.md` | Classification levels, CUI handling | S2+ |
| `audit-spec.md` | OCSF event schema, required fields, sinks, retention | All stages |
| `audit-event-reference.md` | Per-class event documentation; all events [PLANNED] at S1 | S1+ |
| `hardening-guide.md` | STIG/hardening checklist; FIPS runtime assertion implemented at S1 (DECISION-0039) | S2+ full enforcement |
| `../SECURITY.md` | Vulnerability disclosure policy | All stages |

---

## Category 6 — Development Process
*Workflow, tooling, and contribution conventions.*

| File | Purpose | Notes |
|---|---|---|
| `coding-standards.md` | ESLint, TypeScript, Zod patterns | Also Category 2 |
| `dependency-policy.md` | License allow-list, dependency vetting | Also Category 2 |
| `build-guide.md` | Dev setup, build commands, prerequisites | Some WIP sections |
| `cicd.md` | CI/CD pipeline; Make targets; stage gates | Includes `validate-audit-events`, `drizzle-kit check` |
| `failure-handling.md` | Error handling patterns, retry/circuit-breaker | |
| `../CONTRIBUTING.md` | Contribution workflow; Husky + lint-staged setup (DECISION-0035) | Not pre-commit |
| `../.gitea/pull_request_template.md` | PR checklist: TDD, CHANGELOG, subagent review, tradeoff-cited | |
| `contribution/` | Node and adapter authoring guides (stubs, per DECISION-0042) | Expand at first node sprint |

---

## Category 7 — Operations
*Running, deploying, and maintaining FUSION.*

| File | Purpose | Notes |
|---|---|---|
| `deploy-guide.md` | Helm deploy to K3s, environment profile setup | References `../helm/` |
| `runbook.md` | Operational runbooks — **WIP; playbooks not yet populated** | Ansible playbooks pending |
| `maintenance.md` | Maintenance procedures, doc review cadence | |

---

## Category 8 — Planning & Tracking
*Spikes, risk register, checkpoints, and context utilities.*

| File | Purpose | Notes |
|---|---|---|
| `risks.md` | Risk register | |
| `spikes/README.md` | Spike index with summary and status | |
| `spikes/spike-01-*.md` … `spike-06-*.md` | Investigation plans; all owners `[TBD]` | |
| `checkpoints/` | Stage-dated checkpoint records | |
| `project-context.md` | LLM-optimized context blob for external prompts | See `diagrams/ov-1-operational-concept.md` for canonical version |

---

## Category 9 — Arbiter Working Files
*Process artifacts produced by `/fusion-arbiter`. Do NOT cite these as authority for
architecture decisions — cite `fusion-arbiter-decisions.md` (Category 1) instead.*

| File | Purpose | Lifecycle |
|---|---|---|
| `fusion-arbiter-decisions.md` | **Authoritative** append-only decision log | Permanent; append-only |
| `fusion-arbiter-evidence.md` | Working evidence index | Rebuilt on each arbiter scan |
| `fusion-arbiter-variance-report.md` | Active variance analysis | Rebuilt on each arbiter scan |
| `fusion-arbiter-readiness.md` | Downstream artifact readiness report | Rebuilt on each arbiter scan |

---

## Planned but Not Yet Present

| Artifact | Reason not present | Trigger |
|---|---|---|
| `contribution/` authoring guides (full) | Stubs only at S1 (DECISION-0042) | First node/adapter authoring sprint |
| OpenTofu provider config (`../terraform/`) | No concrete node yet (DECISION-0005 deferred) | First node sprint |
| Ansible playbooks (`../ansible/`) | Pending infra sprint (DECISION-0043) | Dedicated infra sprint |
| Multi-provider Git abstraction | Deferred to S2/first non-Gitea customer (DECISION-0004) | Stage 2 or adoption trigger |
