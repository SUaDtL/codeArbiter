## Summary

<!-- What does this PR do? One paragraph is enough. -->

## Type of Change

- [ ] Feature (new functionality)
- [ ] Fix (bug fix)
- [ ] Docs (documentation only)
- [ ] Chore (dependencies, CI, lint — no functional change)
- [ ] Refactor (no functional change, improves structure)

## Checklist

- [ ] `make ci` passes locally (or `make backend-test && make backend-lint` for backend-only changes)
- [ ] **TDD contract (CLAUDE.md §9):** failing test written before feature code; happy path, invalid input, boundary, and audit-emit cases all covered
- [ ] **CHANGELOG.md updated** (`[Unreleased]` section) — required for `feat` and `fix` commits; not required for `docs`, `chore`, `test`, `refactor`, `ci`
- [ ] **Subagent review cited** — if a specialized agent (`backend-author`, `security-reviewer`, etc.) reviewed any part of this change, name it in the PR description (CLAUDE.md §5)
- [ ] **Tradeoff cited** — if a non-obvious tradeoff was made, the PR description names which CLAUDE.md §0 level it was decided at (label: `tradeoff-cited`)
- [ ] Four guide docs updated if behavior changed (build, deploy, hardening, runbook)
- [ ] No secrets, customer names, or hardcoded internal paths added

## Testing Notes

<!-- How was this tested? What environments? Anything reviewers should watch for? -->
