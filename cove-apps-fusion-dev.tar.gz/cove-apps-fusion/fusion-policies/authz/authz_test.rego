# FUSION Authorization Policy — Unit Tests
#
# PRE-SPIKE-4: These tests cover the MVP1 role matrix only.
# Expand after Spike 4 bundle structure is finalized.

package fusion.authz_test

import rego.v1

# ---------------------------------------------------------------------------
# test_default_deny_empty_roles
# A user with no roles must be denied on any action.
# ---------------------------------------------------------------------------
test_default_deny_empty_roles if {
	not allow with input as {
		"user": {"id": "test-user", "roles": []},
		"action": "solutions:read",
		"resource": {"type": "solution", "id": "res-1"},
	}
}

# ---------------------------------------------------------------------------
# test_platform_admin_allow_any_action
# platform-admin wildcard must allow arbitrary actions not in the MVP1 list.
# ---------------------------------------------------------------------------
test_platform_admin_allow_any_action if {
	allow with input as {
		"user": {"id": "test-user", "roles": ["platform-admin"]},
		"action": "policies:update",
		"resource": {"type": "policy", "id": "res-1"},
	}
}

# ---------------------------------------------------------------------------
# test_solutions_engineer_can_read_solution
# solutions-engineer is permitted solutions:read on solution resources.
# ---------------------------------------------------------------------------
test_solutions_engineer_can_read_solution if {
	allow with input as {
		"user": {"id": "test-user", "roles": ["solutions-engineer"]},
		"action": "solutions:read",
		"resource": {"type": "solution", "id": "res-1"},
	}
}

# ---------------------------------------------------------------------------
# test_solutions_engineer_can_create_deployment
# solutions-engineer is permitted deployments:create on deployment resources.
# ---------------------------------------------------------------------------
test_solutions_engineer_can_create_deployment if {
	allow with input as {
		"user": {"id": "test-user", "roles": ["solutions-engineer"]},
		"action": "deployments:create",
		"resource": {"type": "deployment", "id": "res-1"},
	}
}

# ---------------------------------------------------------------------------
# test_solutions_engineer_cannot_update_policies
# solutions-engineer must NOT be able to perform actions outside its matrix.
# ---------------------------------------------------------------------------
test_solutions_engineer_cannot_update_policies if {
	not allow with input as {
		"user": {"id": "test-user", "roles": ["solutions-engineer"]},
		"action": "policies:update",
		"resource": {"type": "policy", "id": "res-1"},
	}
}
