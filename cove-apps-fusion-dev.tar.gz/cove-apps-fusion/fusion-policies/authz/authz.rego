# FUSION Authorization Policy — MVP1 Skeleton
#
# DECISION-0007: Full OPA bundle shape deferred until Spike 4 completes.
# PRE-SPIKE-4: This file is intentionally minimal. Expand role facts, add
# resource-type guards, and introduce new sub-packages under fusion/ only
# after the Spike 4 bundle structure is finalized.
#
# MOSA hedge: engine-neutral call sites; OPA internals isolated to authz/* module.
# Callers outside this module must not depend on any internal rule signature here.
#
# Input shape:
#   {
#     "user": { "id": string, "roles": [string, ...] },
#     "action": string,          # convention: "<resource>:<verb>"
#     "resource": { "type": string, "id": string }
#   }
#
# Action strings defined at MVP1:
#   solutions:read    solutions:create    solutions:update    solutions:delete
#   deployments:read  deployments:create

package fusion.authz

import rego.v1

# ---------------------------------------------------------------------------
# Default deny — every request is denied unless an explicit rule allows it.
# ---------------------------------------------------------------------------
default allow := false

# ---------------------------------------------------------------------------
# Top-level allow rule
#
# PRE-SPIKE-4: expand bundle shape after Spike 4 completes.
# ---------------------------------------------------------------------------
allow if {
	user_has_role(input.user.roles, input.action, input.resource.type)
}

# ---------------------------------------------------------------------------
# user_has_role: returns true when any role held by the user permits
# the requested action on the given resource type.
#
# PRE-SPIKE-4: expand bundle shape after Spike 4 completes.
# ---------------------------------------------------------------------------
user_has_role(roles, action, resource_type) if {
	some role in roles
	role_allows(role, action, resource_type)
}

# ---------------------------------------------------------------------------
# role_allows facts — MVP1 role/action/resource matrix
#
# PRE-SPIKE-4: expand bundle shape after Spike 4 completes.
#
# platform-admin: unrestricted access across all actions and resource types.
# ---------------------------------------------------------------------------
role_allows("platform-admin", _, _)

# solutions-engineer: CRUD on solutions; read + create on deployments.
role_allows("solutions-engineer", "solutions:read", "solution")

role_allows("solutions-engineer", "solutions:create", "solution")

role_allows("solutions-engineer", "solutions:update", "solution")

role_allows("solutions-engineer", "solutions:delete", "solution")

role_allows("solutions-engineer", "deployments:read", "deployment")

role_allows("solutions-engineer", "deployments:create", "deployment")
