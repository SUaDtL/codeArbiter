# fusion-policies

## Purpose

OPA policy bundle for FUSION's authorization layer (DECISION-0007). Enforces a default-deny posture: every request is denied unless an explicit Rego rule permits it. Policy-as-code lives here in Rego so authorization decisions are auditable, testable, and version-controlled alongside the platform. This is a **pre-Spike-4 skeleton** — the full bundle shape is deferred until Spike 4 completes; extension points are marked `PRE-SPIKE-4` throughout.

## Bundle Structure

```
fusion-policies/
├── .manifest
└── authz/
    ├── authz.rego
    └── authz_test.rego
```

## Loading

```bash
opa run --server --bundle fusion-policies/
```

## Running Tests

```bash
opa test fusion-policies/ -v
```

## MVP1 Role Matrix

| Role | Allowed Actions | Resource Types |
|---|---|---|
| `platform-admin` | all | all |
| `solutions-engineer` | `solutions:read`, `solutions:create`, `solutions:update`, `solutions:delete`, `deployments:read`, `deployments:create` | `solution`, `deployment` |

## Extending

Expand `role_allows` facts and add new packages under `fusion/` after Spike 4 OPA bundle structure is finalized.
