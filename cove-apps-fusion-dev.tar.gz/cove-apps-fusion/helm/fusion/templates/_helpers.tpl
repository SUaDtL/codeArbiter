{{/*
_helpers.tpl — FUSION Helm chart shared template helpers.

These helpers are used across all service templates in this chart.
DECISION-0006: MOSA-shaped chart skeleton.
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "fusion.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
Truncates at 63 chars because Kubernetes name fields have this limit.
If nameOverride is supplied it is used directly, otherwise the chart name is used.
*/}}
{{- define "fusion.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "fusion.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels applied to all resources managed by this chart.
These satisfy the recommended Kubernetes label set:
  https://kubernetes.io/docs/concepts/overview/working-with-objects/common-labels/
*/}}
{{- define "fusion.labels" -}}
helm.sh/chart: {{ include "fusion.chart" . }}
{{ include "fusion.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: fusion
fusion.gdit.com/environment: {{ .Values.global.environment | quote }}
{{- end }}

{{/*
Selector labels — used in matchLabels / selector fields.
These MUST remain stable across upgrades; changing them breaks rolling updates.
*/}}
{{- define "fusion.selectorLabels" -}}
app.kubernetes.io/name: {{ include "fusion.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Per-component labels — pass a dict with "root" (.) and "component" (string).
Usage:
  {{- include "fusion.componentLabels" (dict "root" . "component" "backend") | nindent 8 }}
*/}}
{{- define "fusion.componentLabels" -}}
helm.sh/chart: {{ include "fusion.chart" .root }}
app.kubernetes.io/name: {{ printf "%s-%s" (include "fusion.name" .root) .component | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- if .root.Chart.AppVersion }}
app.kubernetes.io/version: {{ .root.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .root.Release.Service }}
app.kubernetes.io/part-of: fusion
fusion.gdit.com/environment: {{ .root.Values.global.environment | quote }}
{{- end }}

{{/*
Per-component selector labels — stable subset used in matchLabels.
Usage:
  {{- include "fusion.componentSelectorLabels" (dict "root" . "component" "backend") | nindent 6 }}
*/}}
{{- define "fusion.componentSelectorLabels" -}}
app.kubernetes.io/name: {{ printf "%s-%s" (include "fusion.name" .root) .component | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Standard service account name (shared; individual services override if needed).
*/}}
{{- define "fusion.serviceAccountName" -}}
{{- if .Values.serviceAccount }}
  {{- if .Values.serviceAccount.create }}
    {{- default (include "fusion.fullname" .) .Values.serviceAccount.name }}
  {{- else }}
    {{- default "default" .Values.serviceAccount.name }}
  {{- end }}
{{- else }}
  {{- "default" }}
{{- end }}
{{- end }}

{{/*
Namespace helper — returns the configured namespace or the release namespace.
*/}}
{{- define "fusion.namespace" -}}
{{- default .Release.Namespace .Values.global.namespace }}
{{- end }}
